package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DashboardItem {
    @SerializedName("id")
    @Expose
    protected int serviceId;

    @SerializedName("title")
    @Expose
    protected String name;

    @SerializedName("spaceuri")
    @Expose
    private String spaceuri;

    public DashboardItem(int serviceId, String name, String spaceuri) {
        this.serviceId = serviceId;
        this.name = name;
        this.spaceuri = spaceuri;
    }

    public int getServiceId() {
        return serviceId;
    }

    public String getName() {
        return name;
    }

    public String getSpaceuri() {
        return spaceuri;
    }
}
