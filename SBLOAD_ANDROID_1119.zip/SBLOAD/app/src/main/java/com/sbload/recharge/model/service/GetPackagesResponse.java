package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;

import java.util.ArrayList;

public class GetPackagesResponse extends CommonResponse {

    @SerializedName("response")
    @Expose
    public ArrayList<ServicePackage> packages;

    public ArrayList<ServicePackage> getPackages() {
        return packages;
    }
}
