package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.utility.CommonUtility;

public class ServiceRequest {
    @SerializedName("id")
    @Expose
    private Integer requestId;

    @SerializedName("cid")
    @Expose
    private Integer countryId;

    @SerializedName("oid")
    @Expose
    private Integer operatorId;

    @SerializedName("sender")
    @Expose
    private Integer sender;

    @SerializedName("receiver")
    @Expose
    private String receiver;

    @SerializedName("amount")
    @Expose
    private Integer amount;

    @SerializedName("type")
    @Expose
    private Integer type;

    @SerializedName("service_id")
    @Expose
    private Integer serviceId;

    @SerializedName("cost")
    @Expose
    private float cost;

    @SerializedName("cost2")
    @Expose
    private float cost2;

    @SerializedName("cost3")
    @Expose
    private float cost3;

    @SerializedName("cost4")
    @Expose
    private float cost4;

    @SerializedName("cost5")
    @Expose
    private float cost5;

    @SerializedName("bal")
    @Expose
    private String balance;

    @SerializedName("bal2")
    @Expose
    private String balance2;

    @SerializedName("bal3")
    @Expose
    private String balance3;

    @SerializedName("bal4")
    @Expose
    private String balance4;

    @SerializedName("bal5")
    @Expose
    private String balance5;

    @SerializedName("rs2")
    @Expose
    private int rs2;

    @SerializedName("rs3")
    @Expose
    private int rs3;

    @SerializedName("rs4")
    @Expose
    private int rs4;

    @SerializedName("rs5")
    @Expose
    private int rs5;

    @SerializedName("status")
    @Expose
    private int status;

    @SerializedName("transactionid")
    @Expose
    private String transactionId;

    @SerializedName("modem")
    @Expose
    private int modem;

    @SerializedName("api")
    @Expose
    private int api;

    @SerializedName("confirmed")
    @Expose
    private int confirmed;

    @SerializedName("token")
    @Expose
    private int token;

    @SerializedName("ip")
    @Expose
    private String ip;

    @SerializedName("last_update")
    @Expose
    private String updateDate;

    public Integer getServiceId() {
        return serviceId;
    }

    public Integer getAmount() {
        return amount;
    }

    public float getCost() {
        return cost;
    }

    public float getBalance() {
        String[] balances = balance.split(",");
        if (balances.length > 0) {
            return CommonUtility.stringToFloat(balances[0], 0.f);
        }
        return 0.f;
    }

    public String getReceiver() {
        return receiver;
    }

    public Integer getType() {
        return type;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public int getStatus() {
        return status;
    }

    public String getUpdateDate() {
        return updateDate;
    }
}
