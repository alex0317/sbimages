package com.sbload.recharge.executive.support;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.reseller.AddResellerRequest;
import com.sbload.recharge.model.account.reseller.AddResellerResponse;
import com.sbload.recharge.model.account.reseller.EditResellerRequest;
import com.sbload.recharge.model.support.OpenTicketsRequest;
import com.sbload.recharge.utility.APIUtility;
import com.sbload.recharge.utility.StringUtility;

public class OpenTicketsExecutive extends CommonExecutive {
    OpenTicketsDisplay display;

    public OpenTicketsExecutive(OpenTicketsDisplay display) {
        super(display);
        this.display = display;
    }

    public void openTickets() {
        OpenTicketsRequest request = display.getOpenTicketsRequest();
        if (request == null) {
            return;
        }

        int validateString = validateOpenTicketRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.showSuccess(R.string.open_tickets_success);
            }
        }, this);
    }

    public int validateOpenTicketRequest(OpenTicketsRequest request) {
        if (request.getSubject().isEmpty()) {
            return R.string.empty_subject;
        }
        if (request.getDetails().isEmpty()) {
            return R.string.empty_details;
        }

        return R.string.input_validate;
    }

    public interface OpenTicketsDisplay extends CommonDisplay {
        OpenTicketsRequest getOpenTicketsRequest();
    }
}
