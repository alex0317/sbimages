package com.sbload.recharge.model.payment;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.reseller.AddResellerResponse;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddPaymentRequest extends BaseRequest {

    private Integer userId;
    private Integer toUserId;
    private Float amount;
    private Integer type;
    private String pin;

    public AddPaymentRequest(Integer userId, Integer toUserId, Float amount, Integer type, String pin) {
        this.userId = userId;
        this.toUserId = toUserId;
        this.amount = amount;
        this.type = type;
        this.pin = pin;
    }

    public Float getAmount() {
        return amount;
    }

    public String getPin() {
        return pin;
    }

    public Integer getToUserId() {
        return toUserId;
    }

    public void setToUserId(Integer toUserId) {
        this.toUserId = toUserId;
    }

    public Integer getType() {
        return type;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public void post(final APIUtility.APIResponse<CommonResponse> apiResponse,
                     final CommonExecutive executive) {

        paymentService.addPayment(userId, toUserId, amount, type, pin)
                .enqueue(new Callback<CommonResponse>() {
                    @Override
                    public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                        if (!executive.validateResponse(response)) {
                            apiResponse.onResponse(null);
                            return;
                        }

                        apiResponse.onResponse(response.body());
                    }

                    @Override
                    public void onFailure(Call<CommonResponse> call, Throwable t) {
                        executive.display.showError(R.string.request_failed);
                        apiResponse.onResponse(null);
                    }
                });
    }
}
