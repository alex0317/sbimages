package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.account.reseller.GetResellersRequest;
import com.sbload.recharge.model.account.reseller.GetResellersResponse;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class ResellersListExecutive extends CommonExecutive {
    ResellersListDisplay display;

    public ResellersListExecutive(ResellersListDisplay display) {
        super(display);
        this.display = display;
    }

    public void requestGetResellers() {
        GetResellersRequest request = new GetResellersRequest(AppData.user.getUserId());

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetResellersResponse>() {
            @Override
            public void onResponse(GetResellersResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                display.onGetResellers(response.getResellers());
            }
        }, this);
    }

    public interface ResellersListDisplay extends CommonDisplay {
        public void onGetResellers(ArrayList<Reseller> resellers);
    }
}
