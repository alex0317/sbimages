package com.sbload.recharge.view.account;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;

import com.sbload.recharge.R;
import com.sbload.recharge.common.Constants;
import com.sbload.recharge.executive.account.DomainExecutive;
import com.sbload.recharge.model.account.domain.DomainRequest;
import com.sbload.recharge.view.BaseActivity;

public class DomainActivity extends BaseActivity implements View.OnClickListener, DomainExecutive.DomainDisplay {

    private DomainExecutive executive;
    private AppCompatEditText editDomain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domain);

        //
        // Bind Controls
        //

        editDomain = findViewById(R.id.edit_domain);

        //
        // Bind events
        //

        findViewById(R.id.btn_continue).setOnClickListener(this);

        executive = new DomainExecutive(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_continue:
                executive.domain();
                break;
        }
    }

    @Override
    public void domainVerified() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor =
                preferences.edit();
        editor.putInt("SBLoad_Domain_Passed", 1);
        editor.commit();

        showActivity(LoginActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, true);
    }

    @Override
    public DomainRequest getDomainRequest() {
        return new DomainRequest(editDomain.getText().toString());
    }
}
