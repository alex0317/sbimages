package com.sbload.recharge.model.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.model.account.reseller.GetResellersResponse;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetHistoriesRequest extends BaseRequest {

    private String userId;
    private String fromDate;
    private String toDate;

    public GetHistoriesRequest(String userId, String fromDate, String toDate) {
        this.userId = userId;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public String getUserId() {
        return userId;
    }

    public String getFromDate() {
        return fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void post(final APIUtility.APIResponse<GetHistoriesResponse> apiResponse,
                     final CommonExecutive executive) {

        paymentService.getServiceHistories(userId)
                .enqueue(new Callback<GetHistoriesResponse>() {
                    @Override
                    public void onResponse(Call<GetHistoriesResponse> call, Response<GetHistoriesResponse> response) {
                        if (!executive.validateResponse(response)) {
                            apiResponse.onResponse(null);
                            return;
                        }

                        apiResponse.onResponse(response.body());

                    }

                    @Override
                    public void onFailure(Call<GetHistoriesResponse> call, Throwable t) {
                        executive.display.showError(R.string.request_failed);
                        apiResponse.onResponse(null);
                    }
                });
    }
}
