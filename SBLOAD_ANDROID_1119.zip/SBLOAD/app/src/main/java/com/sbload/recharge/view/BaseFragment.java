package com.sbload.recharge.view;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.Toast;

import com.sbload.recharge.R;
import com.sbload.recharge.common.customview.LoadingDialog;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.executive.container.ContainerExecutive;

public abstract class BaseFragment extends Fragment implements CommonExecutive.CommonDisplay {
    public ContainerExecutive containerExecutive;
    LoadingDialog loadingDialog;

    public String getTagName() {
        return null;
    }

    public void placeContent(int containerId, BaseFragment fragment) {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(containerId, fragment)
                .commit();
    }

    public void popBackStack() {
        FragmentManager manager = getFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        manager.getBackStackEntryCount();
        transaction.remove(this);
        transaction.commit();
    }

    public void addContent(BaseFragment fragment) {
        fragment.containerExecutive = containerExecutive;
        getFragmentManager()
                .beginTransaction()
                .add(R.id.container, fragment)
                .addToBackStack(fragment.getTagName())
                .commit();
    }

    public void popToFragment(String fragmentTag) {
        FragmentManager fm = getFragmentManager();

        for (int index = fm.getBackStackEntryCount() - 1; index >= 0; index--) {
            String currentFragmentTag = fm.getBackStackEntryAt(index).getName();
            if (!currentFragmentTag.equalsIgnoreCase(fragmentTag)) {
                fm.popBackStack();
            }
        }
    }

    @Override
    public void showLoading(boolean isShow) {
        if (loadingDialog != null) {
            loadingDialog.dismiss();
            loadingDialog = null;
        }
        if (isShow) {

            loadingDialog = new LoadingDialog(getActivity(), getActivity().getResources().getString(R.string.loading));
            loadingDialog.show();
        }
    }

    @Override
    public void showError(String message) {
        try {
            Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
        }
    }

    @Override
    public void showError(int message) {
        try {
            Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
        }
    }

    @Override
    public void showSuccess(int message) {
        try {
            Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
        }
    }
}
