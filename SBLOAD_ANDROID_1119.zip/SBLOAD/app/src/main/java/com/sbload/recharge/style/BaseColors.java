package com.sbload.recharge.style;

import android.graphics.Color;

public class BaseColors {
    public static final int SBL_WHITE = Color.parseColor("#FFFFFF");
    public static final int SBL_BLACK = Color.BLACK;
    public static final int SBL_CLEAR = Color.TRANSPARENT;
    public static final int SBL_BLUE1 = Color.parseColor("#0645AD");
    public static final int SBL_BLUE2 = Color.parseColor("#0089FF");
    public static final int SBL_BLUE3 = Color.parseColor("#0089FF");
    public static final int SBL_GRAY1 = Color.parseColor("#FAFAFA");
    public static final int SBL_GRAY2 = Color.parseColor("#EEEEEE");
    public static final int SBL_GRAY3 = Color.parseColor("#C8C8C8");
    public static final int SBL_GRAY4 = Color.parseColor("#646C77");
}
