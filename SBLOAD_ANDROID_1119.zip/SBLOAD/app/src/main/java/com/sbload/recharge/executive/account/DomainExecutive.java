package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.domain.DomainRequest;
import com.sbload.recharge.utility.APIUtility;

public class DomainExecutive extends CommonExecutive {
    DomainDisplay display;

    public DomainExecutive(DomainDisplay display) {
        super(display);
        this.display = display;
    }

    public void domain() {
        DomainRequest request = display.getDomainRequest();
        if (request == null) {
            return;
        }

        int validateString = validateDomainRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.domainVerified();
            }
        }, this);
    }

    public int validateDomainRequest(DomainRequest request) {
        if (request.getDomain().isEmpty()) {
            return R.string.empty_domain;
        }

        return R.string.input_validate;
    }

    public interface DomainDisplay extends CommonExecutive.CommonDisplay {
        public void domainVerified();
        public DomainRequest getDomainRequest();
    }
}
