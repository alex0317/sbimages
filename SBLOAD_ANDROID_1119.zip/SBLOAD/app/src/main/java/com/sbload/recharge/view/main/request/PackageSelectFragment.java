package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.service.PackageSelectExecutive;
import com.sbload.recharge.model.service.PackageOperator;
import com.sbload.recharge.model.service.ServicePackage;
import com.sbload.recharge.view.BaseFragment;
import com.sbload.recharge.view.main.PackagesRecyclerViewAdapter;

import java.util.ArrayList;

public class PackageSelectFragment extends BaseFragment implements View.OnClickListener, PackagesRecyclerViewAdapter.PackagesRecyclerItemEventListener, PackageSelectExecutive.PackageSelectDisplay {
    private RecyclerView packagesRecyclerView;
    private PackagesRecyclerViewAdapter packagesAdapter;
    private final int recyclerSpans = 2;

    private AppCompatTextView operatorTextView;

    public PackageOperator packageOperator;
    private PackageSelectExecutive executive;

    public PackageSelectFragment() {
    }

    @Override
    public String getTagName() {
        return PackageSelectFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_package_select, container, false);

        //
        // Bind Controls
        //

        operatorTextView = view.findViewById(R.id.txt_operator);
        operatorTextView.setText(packageOperator.getTitle() + "-> Choose Package");

        packagesRecyclerView = view.findViewById(R.id.recycler_packages);
        packagesRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), recyclerSpans));
        packagesAdapter = new PackagesRecyclerViewAdapter(getActivity(), this);
        packagesRecyclerView.setAdapter(packagesAdapter);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        executive = new PackageSelectExecutive(this);
        executive.getPackages(packageOperator.getOperatorId());

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }

    @Override
    public void didClickPackageItem(ServicePackage servicePackage, int position) {
        PackageRequestFragment requestFragment = new PackageRequestFragment();
        requestFragment.servicePackage = servicePackage;
        requestFragment.packageOperator = packageOperator;
        addContent(requestFragment);
    }

    @Override
    public void didGetPackages(ArrayList<ServicePackage> packages) {
        packagesAdapter.setPackages(packages);
        packagesAdapter.notifyDataSetChanged();
    }
}
