package com.sbload.recharge.view.main;

import android.content.Context;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import com.sbload.recharge.R;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.service.Service;

import java.util.ArrayList;

public class ServicesCheckRecyclerViewAdapter extends RecyclerView.Adapter<ServicesCheckRecyclerViewAdapter.ViewHolder> {

    private ArrayList<Service> services = new ArrayList<>();
    private ArrayList<Boolean> checkStates = new ArrayList<>();
    private Context context;
    private Reseller reseller;
    public ServicesCheckRecyclerViewAdapter(Context context, Reseller reseller) {
        this.context = context;
        this.reseller = reseller;
    }

    public ArrayList<Boolean> getCheckStates() {
        return checkStates;
    }

    public void setServices(ArrayList<Service> services) {
        this.services = services;
        checkStates.clear();
        for (Service service : this.services) {
            checkStates.add(false);
        }

        if (reseller != null) {
            int type = reseller.getType();
            String decStr = Integer.toBinaryString(type);
            int pow = 1;
            ArrayList<Integer> types = new ArrayList<>();
            for (int index = decStr.length() - 1; index >= 0; index--) {
                int bitAt = Character.getNumericValue(decStr.charAt(index));
                if (bitAt == 1) {
                    types.add(bitAt * pow);
                }
                pow = pow + pow;
            }

            for (int index = 0; index < services.size(); index++) {
                Service service = services.get(index);
                if (types.contains(service.getType())) {
                    checkStates.set(index, true);
                }
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_service_check, parent, false);
        return new ServicesCheckRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Service service = services.get(position);
        holder.checkService.setText(service.getName());
        holder.checkService.setChecked(checkStates.get(position));
        holder.checkService.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                checkStates.set(position, isChecked);
            }
        });
    }

    @Override
    public int getItemCount() {
        return services.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        final AppCompatCheckBox checkService;

        ViewHolder(View view) {
            super(view);

            checkService = view.findViewById(R.id.chk_service);
        }
    }
}
