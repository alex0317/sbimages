package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatSpinner;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.service.PackageOperatorExecutive;
import com.sbload.recharge.model.service.PackageOperator;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PackageOperatorFragment extends BaseFragment implements View.OnClickListener, PackageOperatorExecutive.PackageOperatorDisplay {
    private AppCompatSpinner operatorSpinner;
    ArrayAdapter<String> operatorAdapter;
    private PackageOperatorExecutive executive;

    public PackageOperatorFragment() {
    }

    @Override
    public String getTagName() {
        return PackageOperatorFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_package_operator, container, false);

        //
        // Bind Controls
        //

        operatorSpinner = view.findViewById(R.id.spinner_operator);
        String[] strings = getResources().getStringArray(R.array.operator_array);
        List<String> operatorItems = new ArrayList<>(Arrays.asList(strings));
        operatorAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, operatorItems);
        operatorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        operatorSpinner.setAdapter(operatorAdapter);

        //
        // Define Events
        //

        operatorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                executive.didSelectOperator(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        view.findViewById(R.id.btn_submit).setOnClickListener(this);

        executive = new PackageOperatorExecutive(this);
        executive.getOperators();

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_submit:
                executive.didPressSubmit();
                break;
        }
    }

    @Override
    public void didGetOperators(ArrayList<PackageOperator> operators) {
        updateOperators(operators);
    }

    @Override
    public void gotoSelectPackage(PackageOperator packageOperator) {
        PackageSelectFragment fragment = new PackageSelectFragment();
        fragment.packageOperator = packageOperator;
        addContent(fragment);
    }

    public void updateOperators(ArrayList<PackageOperator> operators) {
        operatorAdapter.clear();

        if (operators != null){

            for (PackageOperator operator : operators) {
                operatorAdapter.insert(operator.getTitle(), operatorAdapter.getCount());
            }
        }

        operatorAdapter.notifyDataSetChanged();
    }


}
