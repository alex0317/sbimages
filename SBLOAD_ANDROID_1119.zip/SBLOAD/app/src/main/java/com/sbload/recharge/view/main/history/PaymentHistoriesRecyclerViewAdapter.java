package com.sbload.recharge.view.main.history;

import android.content.Context;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.payment.TransferLog;
import com.sbload.recharge.utility.CommonUtility;

import java.util.ArrayList;

public class PaymentHistoriesRecyclerViewAdapter extends RecyclerView.Adapter<PaymentHistoriesRecyclerViewAdapter.ViewHolder> {
    PaymentHistoryRecyclerItemEventListener listener;

    private ArrayList<TransferLog> histories = new ArrayList<>();
    private Context context;
    PaymentHistoriesRecyclerViewAdapter(Context context, PaymentHistoryRecyclerItemEventListener listener) {
        super();
        this.context = context;
        this.listener = listener;
    }


    public void setHistories(ArrayList<TransferLog> histories) {
        this.histories = histories;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_payment_history, parent, false);
        return new PaymentHistoriesRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final TransferLog history = histories.get(position);
        holder.balanceTextView.setText(String.format("%.2f", history.getActual()));
        holder.paymentNoteTextView.setText("Payment Note: " + history.getNote());
        holder.dateTextView.setText(CommonUtility.ChangeDateFormat(history.getLogTime(),
                "yyyy-MM-dd hh:mm:ss", "MMM dd"));
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        final AppCompatTextView balanceTextView, paymentNoteTextView, addressTextView;
        final AppCompatTextView dateTextView;

        ViewHolder(View view) {
            super(view);

            balanceTextView = view.findViewById(R.id.txt_wallet_balance);
            paymentNoteTextView = view.findViewById(R.id.txt_payment_note);
            addressTextView = view.findViewById(R.id.txt_address);
            dateTextView = view.findViewById(R.id.txt_date);
        }
    }

    public interface PaymentHistoryRecyclerItemEventListener {
//        public void didClickEdit(Reseller reseller, int position);
    }
}
