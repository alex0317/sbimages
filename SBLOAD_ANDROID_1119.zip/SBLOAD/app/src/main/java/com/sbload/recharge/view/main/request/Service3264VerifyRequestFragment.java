package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.view.BaseFragment;

public class Service3264VerifyRequestFragment extends BaseFragment implements View.OnClickListener {
    public Service3264VerifyRequestFragment() {
    }

    @Override
    public String getTagName() {
        return Service3264VerifyRequestFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_service3264_verify_request, container, false);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        view.findViewById(R.id.btn_send).setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_send:
                addContent(new RequestSuccessFragment());
                break;
        }
    }
}
