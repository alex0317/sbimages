package com.sbload.recharge.model.payment;

import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.region.GetCountriesResponse;
import com.sbload.recharge.model.region.GetOperatorsResponse;
import com.sbload.recharge.model.service.GetHistoriesResponse;
import com.sbload.recharge.model.service.GetPackageOperatorsResponse;
import com.sbload.recharge.model.service.GetPackagesResponse;
import com.sbload.recharge.model.service.GetServicesResponse;
import com.sbload.recharge.model.service.ServiceRequestResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface PaymentService {

    @FormUrlEncoded
    @POST("payment/services")
    Call<GetServicesResponse> services(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/get_countries")
    Call<GetCountriesResponse> getCountries(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/get_operators")
    Call<GetOperatorsResponse> getOperators(@Field("country_id") int country_id);

    @FormUrlEncoded
    @POST("payment/request_service")
    Call<ServiceRequestResponse> serviceRequest(@Field("user_id") String userId,
                                                @Field("service_id") Integer serviceId,
                                                @Field("number") String number,
                                                @Field("amount") Float amount,
                                                @Field("type") Integer type,
                                                @Field("country") Integer country,
                                                @Field("operator") Integer operator,
                                                @Field("is_package") Integer isPackage,
                                                @Field("package_id") Integer packageId);

    @FormUrlEncoded
    @POST("payment/add_payment")
    Call<CommonResponse> addPayment(@Field("user_id") Integer userId,
                                    @Field("to_id") Integer toUserId,
                                    @Field("amount") Float amount,
                                    @Field("type") Integer type,
                                    @Field("pin") String pin);

    @FormUrlEncoded
    @POST("payment/service_history")
    Call<GetHistoriesResponse> getServiceHistories(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/payment_history")
    Call<GetPaymentsResponse> getPaymentsHistory(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/get_package_operators")
    Call<GetPackageOperatorsResponse> getPackageOperators(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/get_packages")
    Call<GetPackagesResponse> getPackages(@Field("operator_id") Integer operatorId);
}
