package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PackageOperator {
    @SerializedName("id")
    @Expose
    private int operatorId;

    @SerializedName("title")
    @Expose
    private String title;

    public int getOperatorId() {
        return operatorId;
    }

    public String getTitle() {
        return title;
    }
}
