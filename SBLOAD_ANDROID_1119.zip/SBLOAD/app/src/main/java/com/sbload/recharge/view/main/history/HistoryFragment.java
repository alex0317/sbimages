package com.sbload.recharge.view.main.history;


import android.app.FragmentManager;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.service.HistoryExecutive;
import com.sbload.recharge.model.service.GetHistoriesRequest;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.view.BaseFragment;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

import java.util.ArrayList;
import java.util.Calendar;

public class HistoryFragment extends BaseFragment implements View.OnClickListener, HistoriesRecyclerViewAdapter.HistoryRecyclerItemEventListener, HistoryExecutive.HistoryDisplay {
    private RecyclerView historiesRecyclerView;
    private HistoriesRecyclerViewAdapter historiesAdapter;
    private AppCompatEditText dateFromEditText, dateToEditText;
    private View dateFromButton, dateToButton;
    private DatePickerDialog fromDatePickerDialog, toDatePickerDialog;
    private HistoryExecutive executive;

    public HistoryFragment() {
    }

    @Override
    public String getTagName() {
        return HistoryFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        historiesAdapter = new HistoriesRecyclerViewAdapter(getActivity(), this);

        //
        // Define controls
        //

        historiesRecyclerView = view.findViewById(R.id.recycler_history);
        historiesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        historiesRecyclerView.setAdapter(historiesAdapter);

        dateFromEditText = view.findViewById(R.id.txt_date_from);
        dateFromButton = view.findViewById(R.id.btn_date_from);
        dateToEditText = view.findViewById(R.id.txt_date_to);
        dateToButton = view.findViewById(R.id.btn_date_to);
        Calendar now = Calendar.getInstance();
        fromDatePickerDialog = DatePickerDialog.newInstance(
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
                        dateFromEditText.setText(String.format("%d-%02d-%02d", year, monthOfYear + 1, dayOfMonth));
                    }
                },
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
        );
        toDatePickerDialog = DatePickerDialog.newInstance(
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
                        dateToEditText.setText(String.format("%d-%02d-%02d", year, monthOfYear + 1, dayOfMonth));
                    }
                },
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
        );

        //
        // Set Event Handler
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        dateFromButton.setOnClickListener(this);
        dateToButton.setOnClickListener(this);
        view.findViewById(R.id.btn_show).setOnClickListener(this);
        view.findViewById(R.id.btn_refresh).setOnClickListener(this);

        executive = new HistoryExecutive(this);
        executive.requestGetHistories();

        return view;
    }

    @Override
    public void onClick(View view) {
        FragmentManager fragmentManager = getActivity().getFragmentManager();
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_date_from:
                fromDatePickerDialog.show(fragmentManager, "DateTimePicker");
                break;
            case R.id.btn_date_to:
                toDatePickerDialog.show(fragmentManager, "DateTimePicker");
                break;
            case R.id.btn_show:
                executive.requestGetHistories();
                break;
            case R.id.btn_refresh:
                executive.requestGetHistories();
                break;
        }
    }

    @Override
    public void onGetHistories(ArrayList<ServiceRequest> histories) {
        historiesAdapter.setHistories(histories);
        historiesAdapter.notifyDataSetChanged();
    }

    @Override
    public GetHistoriesRequest getHistoriesRequest() {
        return new GetHistoriesRequest(AppData.user.getUserId(),
                dateFromEditText.getText().toString(),
                dateToEditText.getText().toString());
    }
}
