package com.sbload.recharge.executive.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.service.GetHistoriesRequest;
import com.sbload.recharge.model.service.GetHistoriesResponse;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class ReportExecutive extends CommonExecutive {
    ReportDisplay display;

    public ReportExecutive(ReportDisplay display) {
        super(display);
        this.display = display;
    }

    public void requestGetHistories() {
        GetHistoriesRequest request = display.getHistoriesRequest();
        int validateString = validateGetHistoriesRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetHistoriesResponse>() {
            @Override
            public void onResponse(GetHistoriesResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                display.onGetHistories(response.getHistories());
            }
        }, this);
    }

    public int validateGetHistoriesRequest(GetHistoriesRequest request) {
//        if (request.getFromDate().isEmpty()) {
//            return R.string.empty_start_date;
//        }
//
//        if (request.getToDate().isEmpty()) {
//            return R.string.empty_end_date;
//        }

        return R.string.input_validate;
    }



    public interface ReportDisplay extends CommonDisplay {
        void onGetHistories(ArrayList<ServiceRequest> histories);
        GetHistoriesRequest getHistoriesRequest();
    }
}
