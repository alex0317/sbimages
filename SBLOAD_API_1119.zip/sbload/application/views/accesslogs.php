<?php
$this->db->query("DELETE FROM access_logs WHERE datetime < NOW() - INTERVAL 30 DAY");
$user=$this->session->userdata("username");
$date=$this->input->post('date',TRUE); if(!strlen($date)) $date=date("Y-m-d");
$action=$this->input->post('action',TRUE);
$filter=$this->input->post('filter',TRUE);
$str=$this->input->post('str',TRUE);

$q=$this->db->select("*")->from("access_logs")->order_by("datetime","desc");
$q->where("date(datetime)",$date);
$q->where("user",$user);
if (strlen($action)) $q->where("action",$action);
if (strlen($filter) && strlen($str)) $q->like($filter,$str);
$result=$q->get()->result();
$aR=$this->db->select("action")->from("access_logs")->where("action !=","AdminLogin")->group_by("action")->get()->result();
?>
<div class="main">
	<div class="ezttle"><span class="text">Access Logs</span></div>
	<div class="mypage">
        <?php echo form_open("main/accesslogs",'class="form-inline" role="form" style="margin-left:0px;"');?>
        <div class="form-group">
            <label class="sr-only" for="date1">Action</label>
            <select class="form-control input-sm" name="action" style="width:120px;">
                <option value="">--Event--</option>
                <?php foreach($aR as $a):?>
                    <option value="<?php echo $a->action;?>" <?php if ($a->action==$action) echo "selected";?>><?php echo $a->action;?></option>
                <?php endforeach;?>
            </select>
        </div>
        <div class="form-group">
            <label class="sr-only" for="date1">Filter</label>
            <select class="form-control input-sm" name="filter" style="width:120px;">
                <option value="">--Filter By--</option>
                <option value="ip" <?php if ($filter=="ip") echo "selected";?>>IP Address</option>
                <option value="logs" <?php if ($filter=="logs") echo "selected";?>>Activity</option>
                <option value="device" <?php if ($filter=="device") echo "selected";?>>Device</option>
            </select>
        </div>
        <div class="form-group">
            <label class="sr-only" for="str">Search</label>
            <input type="text" class="form-control input-sm" name="str" id="str" value="<?php echo $str?>" style="width:150px;">
        </div>
        <div class="form-group">
            <label class="sr-only" for="date1" >Date</label>
            <input type="text" class="form-control input-sm" name="date" id="date1" value="<?php echo $date?>" style="width:120px;">
        </div>
        <button type="submit" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-search"></span> Filter</button>
        <?php echo form_close();?>
        <div class="top10">&nbsp;</div>
            <table class="table table-striped table-hover">
                <thead>
                <tr>
                    <th>Nr.</th>
                    <th>Time</th>
                    <th>IP</th>
                    <th>Event</th>
                    <th>Activity</th>
                    <th>Device</th>
                </tr>
                </thead>
                <tbody>
                <?php $i=1; foreach ($result as $row):
                    ?>
                    <tr>
                        <td><?php echo $i++; ?></a></td>
                        <td><?php echo date('d M y g:i A', strtotime($row->datetime));?></td>
                        <td><?php echo $row->ip; ?> <a href="http://www.ip-adress.com/whois/<?php echo $row->ip; ?>" target="_blank" style="font-weight:normal">WhoIs</a></td>
                        <td><?php echo $row->action; ?></td>
                        <td><?php echo $row->logs; ?></td>
                        <td><?php echo $row->agent; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
	</div> 
</div>