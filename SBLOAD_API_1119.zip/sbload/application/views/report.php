<?php
function lastdays($days) {
$output = array();
$month = date("m");
$day = date("d");
$year = date("Y");
for($i=0; $i<=$days; $i++){
$output[] = date('Y-m-d',mktime(0,0,0,$month,($day-$i),$year));}
return $output;
}

$cost=0;$amount=0;$profit=0;
$rsid=$this->session->userdata("id");
$level=$this->session->userdata("user_type");
$reseller=$this->input->post('reseller'); 
$service=$this->input->post('service'); if (!strlen($service)) $service="service_id";
$range=$this->input->post('range'); if (!strlen($range)) $range=5;
$from=$this->input->post('from',TRUE);if (empty($from)) $from=date('Y-m-d');
$to=$this->input->post('to',TRUE);if (empty($to)) $to=date('Y-m-d');
if ($level==1){$reseller=$rsid;}
$rsLevel=$level-1;
$today=date("Y-m-d");$srv_date=null;$sms_date=null;$cdr_date=null;
if ($range==1){ $from=$today;$to=$today; }
if ($range==2){ $last=lastdays(30); $from=$last[30];$to=$today; }
if ($range==3){ $last=lastdays(90); $from=$last[90];$to=$today; }
if ($range==4){ $Yr=date('Y'); $from="$Yr-01-01";$to="$Yr-12-31";}
if ($range==5){ $from=null;$to=null;}

if ($_POST){
//Generate 
if ($range!=5){
$srv_date="AND date(last_update) BETWEEN '$from' AND '$to'"; 
$sms_date="AND date(send_time) BETWEEN '$from' AND '$to'";
$cdr_date="AND date(date_update) BETWEEN '$from' AND '$to'";
}

//Decide Table
if ($range!=5){
$table=$this->lib->getTable($from,$to);
}else{
$table='request_view'; 
}


//All Usage
if (!strlen($reseller)){
$q=$this->db->query("SELECT sum(amount) amount, sum(if( sender=$rsid, cost, cost$level))as cost, service_id, sender FROM $table WHERE (sender='$rsid' OR rs$level='$rsid') $srv_date AND status!=3 GROUP BY service_id, sender
UNION
SELECT sum(amount) amount, sum(if( sender=$rsid, cost, cost$level))as cost, 4 as service_id, sender FROM billpay_req WHERE (sender='$rsid' OR rs$level='$rsid') $srv_date AND status!=3 GROUP BY sender
UNION
SELECT count(id) as amount, sum(if( sender=$rsid, cost, cost$level))as cost, 1 as service_id, sender FROM sms_req WHERE (sender='$rsid' OR rs$level='$rsid') $sms_date GROUP BY sender
UNION
SELECT sum(amount) amount, sum(if( sender=$rsid, cost, cost$level))as cost, 2 as service_id, sender FROM card_history WHERE (sender='$rsid' OR rs$level='$rsid') $cdr_date GROUP BY sender
");
}

//MyUsage
if (strlen($reseller) && $reseller==$rsid){
$q=$this->db->query("SELECT sum(amount) amount, sum(cost)as cost, service_id FROM $table WHERE sender='$rsid' $srv_date  AND status!=3  GROUP BY service_id
UNION
SELECT sum(amount) amount, sum(cost)as cost, 4 as service_id FROM billpay_req WHERE sender='$rsid' $srv_date AND status!=3 
UNION 
SELECT count(id) as amount, sum(cost)as cost, 1 as service_id FROM sms_req WHERE sender='$rsid' $sms_date
UNION
SELECT sum(amount) amount, sum(cost)as cost, 2 as service_id FROM card_history WHERE sender='$rsid' $cdr_date
");
}

//ByReseller
if (strlen($reseller) && $reseller!=$rsid){
$u=$this->lib->getUser($reseller);
$type=$u->user_type; if ($type==1) {$type=""; $rsQl="sender='$reseller'";} else {$rsQl="(sender='$reseller' OR rs$type='$reseller')";}
$q=$this->db->query("SELECT sum(amount) amount, sum(if( sender=$reseller, cost, cost$type))as cost, service_id FROM $table WHERE $rsQl $srv_date  AND status!=3 GROUP BY service_id
UNION
SELECT sum(amount) amount, sum(if( sender=$reseller, cost, cost$type))as cost, 4 as service_id FROM billpay_req WHERE $rsQl $srv_date  AND status!=3 
UNION
SELECT count(id) as amount, sum(if( sender=$reseller, cost, cost$type))as cost, 1 as service_id FROM sms_req WHERE $rsQl $sms_date
UNION
SELECT sum(amount) amount, sum(if( sender=$reseller, cost, cost$type))as cost, 2 as service_id FROM card_history WHERE $rsQl $cdr_date
");
$current=$u->balance;
}else{
$u=$this->lib->getUser($rsid);
$current=$u->balance;
}
$pQuery=$this->db->query("SELECT sum(amount) total FROM flexi_transfer_log WHERE bal_to='$u->id'  AND type='transfer'");
$rQuery=$this->db->query("SELECT sum(amount) total FROM flexi_transfer_log WHERE bal_to='$u->id'  AND type='return'");
$pRow=$pQuery->row();
$rRow=$rQuery->row();
$received=$pRow->total-$rRow->total;
}
?>
<div class="main">
	<div class="ezttle"><span class="text">Total Report</span></div>
	<div class="mypage">
		<div class="top10">&nbsp;</div>
		<?php $attr=array("class"=>"form-inline filter", "role"=>"form"); echo form_open("main/report/",$attr); ?>
			<?php if ($level!=1){?>
			<div class="form-group">
			<label for="reseller">Reseller</label><br/>
				<select class="form-control input-xs" name="reseller" id="reseller" style="width:120px;">
				<option value="">--View All--</option>
				<option value="<?php echo $rsid?>" <?php if ($reseller==$rsid) echo "selected";?>>My Account</option>
				<?php for ($i=$rsLevel; $i>=1; $i--): ?>
				<optgroup label="Reseller <?php echo $this->lib->getLevel($i);?>">
					<?php $res=$this->lib->getMyReseller($i); foreach ($res as $oRow):?>
					<option value="<?php echo $oRow->id;?>" <?php if ($reseller==$oRow->id) echo "selected";?>><?php echo $oRow->username;?></option>
					<?php endforeach;?>
				</optgroup>
				<?php endfor;?>
				</select>
			</div>
			<?php } ?>
			<div class="form-group">
			<label for="range">Date Period</label><br/>
				<select class="form-control input-xs" name="range" id="range">
					<option value="5" <?php if ($range==5) echo "Selected";?>>All The Time</option>
					<option value="1" <?php if ($range==1) echo "Selected";?>>Today</option>
					<option value="2" <?php if ($range==2) echo "Selected";?>>Last Month</option>
					<option value="3" <?php if ($range==3) echo "Selected";?>>Last 3 Month</option>
					<option value="4" <?php if ($range==4) echo "Selected";?>>This Year</option>
					<option value="6" <?php if ($range==6) echo "Selected";?>>Selected Date</option>
				</select>
			</div>
			<div class="form-group">
			<label for="date1">Date From</label><br/>
			<input type="text" class="form-control input-xs" name="from" id="date1" placeholder="Date From" size="18" value="<?php echo $from;?>">
			</div>
			<div class="form-group">
			<label for="date2">Date To</label><br/>
			<input type="text" class="form-control input-xs" name="to" id="date2" placeholder="Date To" size="18" value="<?php echo $to;?>">
			</div>
			<div class="form-group">
			<label class="" for="">&nbsp;</label><br/>
			<button type="submit" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-search"></span> Filter</button>
			<a href="javascript:void(0)" class="btn btn-danger btn-xs" onClick="window.print();return false"><span class="glyphicon glyphicon-print"></span> Print</a>
			</div>
			<?php echo form_close(); if ($_POST) { ?>
			<div class="top10">&nbsp;</div>
			<div class="row" style="margin-top:5px;">
				<div class="col-md-12 fleft">
					<div class="report well" style="width:610px">
					<h3 class='printhead onprint'><?php echo $this->lib->getSet('brandname');?></h3>
					<h4 style="margin-top:5px;">Total Usage</h4>
					<p>
					<?php if (strlen($reseller)) { echo "Reseller: ".$this->lib->thisUser($reseller)."<br/>";} ?>
					<?php if ($range!=5) { ?>From <?php echo date('d-M-Y', strtotime($from)); ?>, to <?php echo date('d-M-Y', strtotime($to)); } ?>
					</p>
					<?php if (!strlen($reseller)) {
					$result=array();
					foreach ($q->result() as $r):
					$result[$r->service_id][]=$r;
					endforeach;
					foreach ($result as $sid => $val):?>
					<table>
					<caption style="background:#ccc;padding:2px 5px; margin-bottom:5px;color:#333;border:none;font-weight:bold;text-align:left;"><?php echo $this->lib->serTtlById($sid); ?></caption>
					<?php foreach ($val as $r):?>
					<tr><td class="left"><?php echo $this->lib->thisUser($r->sender); ?></td><td class="amt"><?php echo number_format($r->amount,2);?></td><td class="amt"><?php echo $this->lib->rsAmount($r->cost); $cost+=$r->cost?></td></tr>
					<?php endforeach;?>
					</table>
					<?php endforeach; } else { ?>
					<table>
					<caption style="background:#ccc;padding:2px 5px; margin-bottom:5px;color:#333;border:none;font-weight:bold;text-align:left;">Total Usage</caption>
					<tr><th class="left">Service</th><th width="100">Amount</th><th width="100">Cost</th></tr>
					<?php foreach ($q->result() as $r):?>
					<tr><td class="left"><?php echo $this->lib->serTtlById($r->service_id); ?></td><td class="amt"><?php echo number_format($r->amount,2);?></td><td class="amt"><?php echo $this->lib->rsAmount($r->cost); $cost+=$r->cost?></td></tr>
					<?php endforeach;?>
					</table>
					<?php } ?>
					<table>
					<caption style="background:#ccc;padding:2px 5px; margin-bottom:5px;color:#333;border:none;font-weight:bold;text-align:left;">Total Cost</caption>
					<tr><td class="left">Total Cost</td><td class="amt"><?php echo $this->lib->rsAmount($cost);?></td></tr>
					<tr><td class="left">Current Balance(+)</td><td class="amt"><?php echo $this->lib->rsAmount($current);?></td></tr>
					<tr><th class="left"><b>Total</b></th><th class="amt"><?php $totalCost=$current+$cost; echo $this->lib->rsAmount($totalCost)?></th></tr>
					</table>
					<table>
					<caption style="background:#ccc;padding:2px 5px; margin-bottom:5px;color:#333;border:none;font-weight:bold;text-align:left;">Summary</caption>
					<tr><td class="left">Total Receive</td><td class="amt"><?php echo number_format($pRow->total,2);?></td></tr>
					<tr><td class="left">Total Return(-)</td><td class="amt"><?php echo $this->lib->rsAmount($rRow->total);?></td></tr>
					<tr><th class="left" style="border-top:1px solid #ccc;">Balance</th><th class="amt"><?php $bl=$pRow->total-($totalCost+$rRow->total);echo $this->lib->rsAmount($bl);?></th></tr>
					</table>
					<p style="margin-top:10px;color:#666;" class="onprint"><?php echo $_SERVER['HTTP_HOST'];?></p>
					</div> 
				</div> 
			</div> 
			<?php } ?>
	</div> 
</div>