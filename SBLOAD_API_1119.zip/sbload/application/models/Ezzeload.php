<?php 

class Ezzeload extends CI_Model
{
    public function __construct()
    {
    }

    public function getLogin()
    {
        $username = $this->input->post("username", true);
        $userquery = "(username='" . $username . "' OR email='" . $username . "')";
        $q = $this->db->select();
        $q->from("resellers");
        $q->where($userquery);
        $q->where("status", "1");
        $q->limit(1);
        $q = $q->get();
        $result = $q->result();
        if( $q->num_rows() == 1 ) 
        {
            $row = $result[0];
            $enable_otp = $this->lib->getSet("reseller_otp");
            $ses = array( "id" => $row->id, "parent" => $row->parent, "username" => $row->username, "fullname" => $row->fullname, "user_type" => $row->user_type, "type" => $row->type, "pin_expire" => $row->pin_expire, "pass_expire" => $row->pass_expire, "cookie" => $row->cookie, "sID" => md5($row->id . $row->username . date("Y-m-d H:i:s")), "loged_in" => true, "attmp" => 3, "otp_sent" => 0, "session_id" => strtoupper(uniqid("RS") . time()), "enable_otp" => $enable_otp, "otp_type" => $row->otp_type, "otp_key" => $row->otp_key, "currency" => $row->currency, "ccode" => $this->lib->cCode($row->currency) );
            $this->session->set_userdata($ses);
            $this->lib->myDevice($row);
            $this->lib->license();
            if( $enable_otp == 1 ) 
            {
                $oMod = $this->lib->getType($row->otp_type);
                if( !in_array(1, $oMod) ) 
                {
                    $this->session->set_userdata("checkpoint", 0);
                }

                $this->lib->SaveLogs("UserLogin", "Login OTP disabled in reseller settings");
            }

            $ckp = $this->session->userdata("checkpoint");
            if( $ckp != 1 ) 
            {
                $this->db->where("id", $row->id)->update("resellers", array( "last_login" => date("Y-m-d H:i:s") ));
                $this->lib->getOnline();
                $this->lib->SaveLogs("UserLogin", "User logged in with valid username and password");
                $this->lib->onlineUser();
                $this->lib->notifyLogin($row, 1);
            }

            $this->lib->dbtbl();
            redirect("main", "location");
        }

    }

    public function AdminLogin()
    {
        $username = $this->input->post("username", true);
        $password = $this->input->post("password", true);
        $where = array( "username" => $username, "status" => 1 );
        $q = $this->db->get_where("admin", $where, 1, 0);
        $result = $q->result();
        if( $q->num_rows() == 1 ) 
        {
            $row = $result[0];
            $ses = array( "id" => $row->id, "username" => $row->username, "fullname" => $row->fullname, "otp_enable" => $row->otp_enable, "type" => $row->type, "sID" => md5($row->id . $row->username . date("Y-m-d H:i:s")), "loged_in" => true, "thisadmin" => true, "attmp" => 5, "otp_sent" => 0, "cookie" => $row->cookie, "currency" => $this->lib->getSet("base_currency"), "session_id" => strtoupper(uniqid("ES") . time()), "checkpoint" => 1 );
            $this->session->set_userdata($ses);
            $this->lib->license();
            $ckp = $this->session->userdata("checkpoint");
            if( $ckp != 1 ) 
            {
                $this->db->where("id", $row->id)->update("admin", array( "date_login" => date("Y-m-d H:i:s") ));
                $this->lib->getOnline();
                $this->lib->SaveLogs("AdminLogin", "Admin logged in with valid username and password");
                $this->lib->onlineUser();
            }

            $this->lib->dbtbl();
            $this->lib->notifyLogin($row);
            redirect("admin", "location");
        }

    }

    public function isAdminLogin()
    {
        $sID = $this->session->userdata("sID");
        $username = $this->session->userdata("username");
        $otp_enable = $this->session->userdata("otp_enable");
        $loged_in = $this->session->userdata("loged_in");
        $thisadmin = $this->session->userdata("thisadmin");
        $checkpoint = $this->session->userdata("checkpoint");
        $cookie = $this->session->userdata("cookie");
        if( empty($sID) && $loged_in != true && $thisadmin != true ) 
        {
            $this->session->sess_destroy();
            redirect("portal", "location");
            show_404();
            exit();
        }

        $q = $this->db->select("status")->FROM("admin")->where("username", $username)->where("cookie", $cookie)->where("status", 1)->limit(1)->get();
        if( $q->num_rows() == 0 ) 
        {
            $this->session->sess_destroy();
            redirect("portal?sk=out", "location");
        }

        if( $otp_enable == 0 ) 
        {
            redirect("otp", "location");
        }

        if( $checkpoint == 1 ) 
        {
            redirect("verify", "location");
        }

        $this->lib->onlineUser();
    }

    public function isLogin()
    {
        $sID = $this->session->userdata("sID");
        $username = $this->session->userdata("username");
        $loged_in = $this->session->userdata("loged_in");
        $checkpoint = $this->session->userdata("checkpoint");
        $enable_otp = $this->session->userdata("enable_otp");
        $cookie = $this->session->userdata("cookie");
        if( empty($sID) && $loged_in != true ) 
        {
            $this->session->sess_destroy();
            redirect("login", "location");
        }

        $q = $this->db->select("status")->FROM("resellers")->where("username", $username)->where("cookie", $cookie)->where("status", 1)->limit(1)->get();
        if( $q->num_rows() == 0 ) 
        {
            redirect("login?sk=out", "location");
        }

        if( $checkpoint == 1 ) 
        {
            redirect("checkpoint", "location");
        }

        $uri = $this->router->method;
        $pin_expire = $this->session->userdata("pin_expire");
        $pass_expire = $this->session->userdata("pass_expire");
        if( $uri != "password" ) 
        {
            $pexpire = $this->lib->dateDiff($pass_expire);
            if( $pexpire <= 1 ) 
            {
                redirect("main/password", "location");
            }

        }

        if( $uri != "pin" ) 
        {
            $expire = $this->lib->dateDiff($pin_expire);
            if( $pin_expire == $pass_expire ) 
            {
                $expire = 2;
            }

            if( $expire <= 1 && $enable_otp == 0 ) 
            {
                redirect("main/pin", "location");
            }

        }

        $this->lib->onlineUser();
    }

    public function onlineUser()
    {
        $session = $this->session->userdata("session_id");
        $time = time();
        $time_check = time() - 3600;
        $q = $this->db->select("count(*) as found")->from("user_online")->where("session", $session);
        $tmp = $q->get()->result();
        $found = $tmp[0]->found;
        if( $found == "0" ) 
        {
            redirect("logout", "location");
        }
        else
        {
            $uData = array( "time" => $time );
            $this->db->where("session", $session);
            $this->db->update("user_online", $uData);
        }

        $this->db->delete("user_online", array( "time <" => $time_check ));
    }

    public function getOnline()
    {
        $user_id = $this->session->userdata("username");
        $parent = $this->session->userdata("parent");
        $level = $this->session->userdata("user_type");
        $ip = $this->lib->RemoteIP();
        $session = $this->session->userdata("session_id");
        $time = time();
        $this->db->delete("user_online", array( "user_id" => $user_id ));
        $q = $this->db->select("count(*) as found")->from("user_online")->where("session", $session);
        $tmp = $q->get()->result();
        $found = $tmp[0]->found;
        if( $found == "0" ) 
        {
            $data = array( "session" => $session, "time" => $time, "user_id" => $user_id, "parent" => $parent, "type" => $level, "ip" => $ip, "login_time" => date("Y-m-d H:i:s") );
            $this->db->insert("user_online", $data);
        }

    }

    public function getUser($id)
    {
        $q = $this->db->get_where("resellers", array( "id" => $id ), 1, 0);
        $result = $q->result();
        if( $q->num_rows() == 1 ) 
        {
            return $result[0];
        }

        show_404();
        exit();
    }

    public function getAdmin($id)
    {
        $q = $this->db->get_where("admin", array( "id" => $id ), 1, 0);
        $result = $q->result();
        if( $q->num_rows() == 1 ) 
        {
            return $result[0];
        }

        return false;
    }

    public function inActive_all($id, $type)
    {
        $data = array( "status" => 0 );
        $this->db->where("id", $id);
        $this->db->update("resellers", $data);
        if( 1 < $type ) 
        {
            $this->db->where("rs" . $type, $id);
            $this->db->update("resellers", $data);
        }

    }

    public function Active_all($id, $type)
    {
        $data = array( "status" => 1 );
        $this->db->where("id", $id);
        $this->db->update("resellers", $data);
        if( 1 < $type ) 
        {
            $this->db->where("rs" . $type, $id);
            $this->db->update("resellers", $data);
        }

    }

    public function dateDiff($end)
    {
        $start_ts = strtotime(date("Y-m-d"));
        $end_ts = strtotime($end);
        $diff = $end_ts - $start_ts;
        return round($diff / 86400);
    }

    public function getSet($set)
    {
        $q = $this->db->select("value");
        $q->from("config");
        $q->where("setting", $set);
        $q->limit(1);
        $tmp = $q->get()->result();
        return $tmp[0]->value;
    }

    public function globalSet($set)
    {
        $q = $this->db->select("value");
        $q->from("config_global");
        $q->where("setting", $set);
        $q->limit(1);
        $tmp = $q->get()->result();
        return $tmp[0]->value;
    }

    public function myDevice($row)
    {
        $otp_enable = $this->session->userdata("otp_enable");
        $admin = $this->session->userdata("thisadmin");
        if( $admin == true ) 
        {
            $cookiename = "epresence";
        }
        else
        {
            $cookiename = "rpresence";
        }

        if( $this->agent->is_browser() ) 
        {
            $agent = $this->agent->browser() . " " . $this->agent->version();
        }
        else
        {
            if( $this->agent->is_robot() ) 
            {
                $agent = $this->agent->robot();
            }
            else
            {
                if( $this->agent->is_mobile() ) 
                {
                    $agent = $this->agent->mobile();
                }
                else
                {
                    $agent = "Unidentified User Agent";
                }

            }

        }

        $system = $this->agent->platform();
        $device = NULL;
        $key = base64_encode(str_replace(" ", "", $row->username . $row->cookie . $system . $agent . "E3993V9173821049"));
        if( isset($_COOKIE[$cookiename]) ) 
        {
            $device = $_COOKIE[$cookiename];
            $device = $this->lib->mc_decrypt($device);
        }

        if( $admin == true ) 
        {
            if( $otp_enable == 1 ) 
            {
                if( $key == $device ) 
                {
                    $this->session->set_userdata("checkpoint", "0");
                }
                else
                {
                    $this->session->set_userdata("checkpoint", "1");
                }

            }
            else
            {
                $this->session->set_userdata("checkpoint", "0");
            }

        }
        else
        {
            if( $key == $device ) 
            {
                $this->session->set_userdata("checkpoint", "1");
            }
            else
            {
                $this->session->set_userdata("checkpoint", "1");
            }

        }

    }

    public function getType($type)
    {
        $modules = array(  );
        if( 0 < $type ) 
        {
            $bin = decbin($type);
            $digit = str_split($bin);
            $result = array_reverse($digit);
            $i = 1;
            $j = 1;
            foreach( $result as $data ) 
            {
                $tata = $data * $i;
                if( $tata != 0 ) 
                {
                    $slipt[$j] = $tata;
                    $j++;
                }

                $i = $i + $i;
            }
            if( isset($slipt) ) 
            {
                $clients = new stdClass();
                foreach( $slipt as $client ) 
                {
                    $modules[] = $client;
                }
            }

        }

        return $modules;
    }

    public function myServices()
    {
        $data = array(  );
        $type = $this->session->userdata("type");
        $module = $this->lib->getType($type);
        $q = $this->db->select("*")->from("services")->where("type >", "4")->order_by("short", "asc");
        $q->where("type !=", "512");
        $result = $q->get()->result();
        foreach( $result as $row ) 
        {
            if( in_array($row->type, $module) ) 
            {
                $data[] = $row;
            }

        }
        return $data;
    }

    public function getServices()
    {
        $q = $this->db->order_by("short", "asc")->get_where("services", array( "type >" => "4" ));
        $result = $q->result();
        return $result;
    }

    public function getModules()
    {
        $q = $this->db->order_by("short", "asc")->get_where("services", array( "enable" => "1" ));
        $result = $q->result();
        return $result;
    }

    public function curl_get($url, $get = NULL, $options = array(  ))
    {
        $defaults = array( CURLOPT_URL => $url . ((strpos($url, "?") === false ? "?" : "")) . http_build_query($get), CURLOPT_HEADER => 0, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 400 );
        $ch = curl_init();
        curl_setopt_array($ch, $options + $defaults);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    public function isIE()
    {
        $var = false;
        $agent = $_SERVER["HTTP_USER_AGENT"];
        if( $this->agent->browser() == "Internet Explorer" && $this->agent->version() <= 7 ) 
        {
            $var = true;
        }

        if( $this->agent->is_mobile() ) 
        {
            if( strpos($agent, "Android") !== false ) 
            {
                $var = false;
            }
            else
            {
                if( strpos($agent, "iPhone") !== false ) 
                {
                    $var = false;
                }
                else
                {
                    $var = true;
                }

            }

        }

        return $var;
    }

    public function getLevel($type)
    {
        $level = NULL;
        if( $type == 1 ) 
        {
            $level = "I";
        }

        if( $type == 2 ) 
        {
            $level = "II";
        }

        if( $type == 3 ) 
        {
            $level = "III";
        }

        if( $type == 4 ) 
        {
            $level = "IV";
        }

        if( $type == 5 ) 
        {
            $level = "Admin";
        }

        return $level;
    }

    public function myBalance()
    {
        $id = $this->session->userdata("id");
        $q = $this->db->select("balance")->from("resellers")->where("id", $id)->limit(1);
        $res = $q->get()->result();
        return $res[0]->balance;
    }

    public function thisBrowser()
    {
        if( $this->agent->is_browser() ) 
        {
            $agent = $this->agent->browser() . " " . $this->agent->version();
        }
        else
        {
            if( $this->agent->is_robot() ) 
            {
                $agent = $this->agent->robot();
            }
            else
            {
                if( $this->agent->is_mobile() ) 
                {
                    $agent = $this->agent->mobile();
                }
                else
                {
                    $agent = "Undefined";
                }

            }

        }

        return $agent;
    }

    public function license()
    {
        $go = false;
        $var = $this->lib->getSet("version");
        //$url = STUN_URL . "getModule";
        //$data = array( "domain" => $_SERVER["HTTP_HOST"], "version" => $var );
        $ret = $this->lib->curl_get($url, $data);
        if( $ret == 2 ) 
        {
            $go = false;
        }
        else
        {
            $sesData = array( "module" => $ret );
            $this->session->set_userdata($sesData);
            $go = true;
        }

        if( $go == false ) 
        {
            redirect("login?sk=license", "location");
        }

    }

    public function SaveLogs($type, $info, $user_id = "")
    {
        if( !strlen($user_id) ) 
        {
            $user_id = $this->session->userdata("username");
        }

        $level = $this->session->userdata("user_type");
        if( !strlen($level) ) 
        {
            $level = "";
        }

        $ip = $this->lib->RemoteIP();
        $date_time = date("Y-m-d H:i:s");
        $browser = $this->lib->thisBrowser();
        $platform = $this->agent->platform();
        $logs = array( "user" => $user_id, "level" => "", "action" => $type, "logs" => $info, "datetime" => $date_time, "ip" => $ip, "agent" => $browser . " (" . $platform . ")" );
        $this->db->insert("access_logs", $logs);
    }

    public function status($type)
    {
        if( $type == 1 ) 
        {
            echo "<img src='content/img/active.png'>";
        }

        if( $type == 0 ) 
        {
            echo "<img src='content/img/cross.png'>";
        }

    }

    public function showing($limit, $ofset, $rows)
    {
        $from = $ofset;
        if( $from == 0 ) 
        {
            $from = 1;
        }

        $to = $limit + $ofset;
        if( $rows < $to ) 
        {
            $to = $rows;
        }

        return "Showing " . $from . " to " . $to . " of " . $rows . " records";
    }

    public function offlinesmsAction($ids)
    {
        $error = 0;
        foreach( $ids as $id ) 
        {
            $this->db->query("DELETE FROM offline_sms WHERE id='" . $id . "' LIMIT 1");
        }
        $this->lib->SaveLogs("Offline SMS Delete", "Some selected sms was deleted by admin user");
        return NULL;
    }

    public function smsAction($ids)
    {
        $error = 0;
        foreach( $ids as $id ) 
        {
            $this->db->query("DELETE FROM flexi_message WHERE id='" . $id . "' LIMIT 1");
        }
        $this->lib->SaveLogs("SMS Delete", "Some selected sms was deleted by admin user");
        return NULL;
    }

    public function rsAction($action, $ids)
    {
        $error = 0;
        if( $action == "delete" ) 
        {
            foreach( $ids as $id ) 
            {
                $uRow = $this->lib->getUser($id);
                $this->lib->SaveLogs("Delete Reseller", "Reseller " . $uRow->username . " and its child's has been deleted!");
                $this->db->query("UPDATE resellers SET status='3', balance='0' WHERE id='" . $id . "' LIMIT 1");
                if( $uRow->user_type != 1 ) 
                {
                    $this->db->query("UPDATE resellers SET status='3', balance='0' WHERE rs" . $uRow->user_type . "='" . $uRow->id . "'");
                }

            }
        }
        else
        {
            if( $action == "active" ) 
            {
                foreach( $ids as $id ) 
                {
                    $uRow = $this->lib->getUser($id);
                    $this->lib->SaveLogs("Active Reseller", "Reseller " . $uRow->username . " and its child's has been activated!");
                    $this->db->query("UPDATE resellers SET status='1' WHERE id='" . $id . "' AND status!=3 LIMIT 1");
                    if( $uRow->user_type != 1 ) 
                    {
                        $this->db->query("UPDATE resellers SET status='1' WHERE rs" . $uRow->user_type . "='" . $uRow->id . "' AND status!=3");
                    }

                }
            }
            else
            {
                if( $action == "inactive" ) 
                {
                    foreach( $ids as $id ) 
                    {
                        $uRow = $this->lib->getUser($id);
                        $this->lib->SaveLogs("DeActive Reseller", "Reseller " . $uRow->username . " and its child's has been deactivated!");
                        $this->db->query("UPDATE resellers SET status='0' WHERE id='" . $id . "' AND status!=3 LIMIT 1");
                        if( $uRow->user_type != 1 ) 
                        {
                            $this->db->query("UPDATE resellers SET status='0' WHERE rs" . $uRow->user_type . "='" . $uRow->id . "' AND status!=3");
                        }

                    }
                }
                else
                {
                    if( $action == "optreset" ) 
                    {
                        foreach( $ids as $id ) 
                        {
                            $uRow = $this->lib->getUser($id);
                            $mid = $this->session->userdata("id");
                            $thisadmin = $this->session->userdata("thisadmin");
                            $this->lib->SaveLogs("OTP Reset", "Reseller " . $uRow->username . " OTP was reseted!");
                            if( $thisadmin == true ) 
                            {
                                $this->db->query("UPDATE resellers SET otp_key='' WHERE id='" . $id . "' LIMIT 1");
                            }
                            else
                            {
                                $this->db->query("UPDATE resellers SET otp_key='' WHERE id='" . $id . "' AND parent='" . $mid . "' LIMIT 1");
                            }

                        }
                    }

                }

            }

        }

        return $error;
    }

    public function reqAction($action, $ids)
    {
        $error = 0;
        $req_tbl = $this->lib->req_tbl();
        $admin = $this->session->userdata("username");
        if( $action == "resend" ) 
        {
            foreach( $ids as $id ) 
            {
                $data = array( "status" => "0", "modem" => "-1", "api" => "-1", "confirmed" => "0", "transactionid" => "", "token" => "" );
                $this->db->where("id", $id);
                $this->db->where("status <", 3);
                $this->db->update($req_tbl, $data);
            }
        }
        else
        {
            if( $action == "confirm" ) 
            {
                foreach( $ids as $id ) 
                {
                    $random = $this->lib->random_numbers(8);
                    $trid = $random . "- " . $admin;
                    $data = array( "transactionid" => $trid, "status" => "4", "last_update" => date("Y-m-d H:i:s") );
                    $this->db->where("id", $id);
                    $this->db->update($req_tbl, $data);
                }
            }
            else
            {
                if( $action == "process" ) 
                {
                    foreach( $ids as $reqid ) 
                    {
                        $this->db->query("UPDATE " . $req_tbl . " SET status=1 WHERE id='" . $reqid . "'");
                    }
                }
                else
                {
                    if( $action == "cancel" ) 
                    {
                        foreach( $ids as $reqid ) 
                        {
                            $trid = "Canceled by " . $this->session->userdata("fullname");
                            $bal_from = $this->session->userdata("id");
                            $q = $this->db->query("SELECT * FROM " . $req_tbl . " WHERE id='" . $reqid . "' LIMIT 1");
                            if( $q->num_rows() == 1 ) 
                            {
                                $row = $q->row();
                                $this->lib->addBal($row->sender, $row->cost);
                                if( $row->rs5 != "-1" ) 
                                {
                                    $this->lib->addBal($row->rs5, $row->cost5);
                                }

                                if( $row->rs4 != "-1" ) 
                                {
                                    $this->lib->addBal($row->rs4, $row->cost4);
                                }

                                if( $row->rs3 != "-1" ) 
                                {
                                    $this->lib->addBal($row->rs3, $row->cost3);
                                }

                                if( $row->rs2 != "-1" ) 
                                {
                                    $this->lib->addBal($row->rs2, $row->cost2);
                                }

                                $pay = array( "bal_from" => $bal_from, "bal_to" => $row->sender, "amount" => $row->cost, "type" => "Canceled", "byadmin" => 1, "note" => "Request# " . $reqid, "actual" => $this->lib->getBal($row->sender) );
                                $pay5 = array( "bal_from" => $bal_from, "bal_to" => $row->rs5, "amount" => $row->cost5, "type" => "Canceled", "byadmin" => 1, "note" => "Request# " . $reqid, "actual" => $this->lib->getBal($row->rs5) );
                                $pay4 = array( "bal_from" => $bal_from, "bal_to" => $row->rs4, "amount" => $row->cost4, "type" => "Canceled", "byadmin" => 1, "note" => "Request# " . $reqid, "actual" => $this->lib->getBal($row->rs4) );
                                $pay3 = array( "bal_from" => $bal_from, "bal_to" => $row->rs3, "amount" => $row->cost3, "type" => "Canceled", "byadmin" => 1, "note" => "Request# " . $reqid, "actual" => $this->lib->getBal($row->rs3) );
                                $pay2 = array( "bal_from" => $bal_from, "bal_to" => $row->rs2, "amount" => $row->cost2, "type" => "Canceled", "byadmin" => 1, "note" => "Request# " . $reqid, "actual" => $this->lib->getBal($row->rs2) );
                                $this->db->insert("flexi_transfer_log", $pay);
                                if( $row->rs5 != "-1" ) 
                                {
                                    $this->db->insert("flexi_transfer_log", $pay5);
                                }

                                if( $row->rs4 != "-1" ) 
                                {
                                    $this->db->insert("flexi_transfer_log", $pay4);
                                }

                                if( $row->rs3 != "-1" ) 
                                {
                                    $this->db->insert("flexi_transfer_log", $pay3);
                                }

                                if( $row->rs2 != "-1" ) 
                                {
                                    $this->db->insert("flexi_transfer_log", $pay2);
                                }

                                $this->db->query("UPDATE " . $req_tbl . " SET status='3',transactionid='" . $trid . "' WHERE id='" . $reqid . "'");
                            }

                        }
                    }

                }

            }

        }

        return $error;
    }

    public function getParent()
    {
        $data["admin"] = $this->session->userdata("id");
        $data["parent"] = "-1";
        $data["rs5"] = "-1";
        $data["rs4"] = "-1";
        $data["rs3"] = "-1";
        $data["rs2"] = "-1";
        return $data;
    }

    public function getRelation($id, $newLevel)
    {
        $row = $this->lib->getUser($id);
        if( $newLevel == 4 ) 
        {
            $data["admin"] = $row->admin;
            $data["parent"] = $row->id;
            $data["rs5"] = $row->id;
            $data["rs4"] = "-1";
            $data["rs3"] = "-1";
            $data["rs2"] = "-1";
        }
        else
        {
            if( $newLevel == 3 ) 
            {
                $data["admin"] = $row->admin;
                $data["parent"] = $row->id;
                $data["rs5"] = $row->rs5;
                $data["rs4"] = $row->id;
                $data["rs3"] = "-1";
                $data["rs2"] = "-1";
            }
            else
            {
                if( $newLevel == 2 ) 
                {
                    $data["admin"] = $row->admin;
                    $data["parent"] = $row->id;
                    $data["rs5"] = $row->rs5;
                    $data["rs4"] = $row->rs4;
                    $data["rs3"] = $row->id;
                    $data["rs2"] = "-1";
                }
                else
                {
                    if( $newLevel == 1 ) 
                    {
                        $data["admin"] = $row->admin;
                        $data["parent"] = $row->id;
                        $data["rs5"] = $row->rs5;
                        $data["rs4"] = $row->rs4;
                        $data["rs3"] = $row->rs3;
                        $data["rs2"] = $row->id;
                    }
                    else
                    {
                        $data["admin"] = $row->admin;
                        $data["parent"] = $row->id;
                        $data["rs5"] = "-1";
                        $data["rs4"] = "-1";
                        $data["rs3"] = "-1";
                        $data["rs2"] = "-1";
                    }

                }

            }

        }

        return $data;
    }

    public function random_numbers($digits)
    {
        $min = pow(10, $digits - 1);
        $max = pow(10, $digits) - 1;
        return mt_rand($min, $max);
    }

    public function addBal($id, $amount)
    {
        $this->db->query("UPDATE resellers SET balance=balance+'" . $amount . "' WHERE id='" . $id . "' LIMIT 1");
        return true;
    }

    public function dedBal($id, $amount)
    {
        $this->db->query("UPDATE resellers SET balance=balance-'" . $amount . "' WHERE id='" . $id . "' LIMIT 1");
        return true;
    }

    public function getRates($id)
    {
        $where = array( "res_id" => $id );
        $q = $this->db->select("*")->from("rates")->order_by("service_id", "ASC")->order_by("prefix", "ASC");
        $q->where("res_id", $id);
        $q->where("service_id != ", "512");
        return $q->get()->result();
    }

    public function serTtlById($type)
    {
        if( $type == 1 ) 
        {
            $title = "SMS";
        }
        else
        {
            if( $type == 2 ) 
            {
                $title = "Prepaid Card";
            }
            else
            {
                $q = $this->db->select("title")->from("services")->where("type", $type)->limit(1);
                $r = $q->get()->row();
                $title = $r->title;
            }

        }

        return $title;
    }

    public function iSync($data)
    {
        $where = array( "res_id" => $data["res_id"], "service_id" => $data["service_id"], "type" => $data["type"], "prefix" => $data["prefix"] );
        $q = $this->db->select("count(*) found")->from("rates")->where($where)->limit(1);
        $tmp = $q->get()->result();
        return $tmp[0]->found;
    }

    public function getSafe($url, $data)
    {
        $key = "3bba47d9b26bb5978197751400639K8K";
        $newData = $this->lib->encode($data, $key);
        echo base_url() . $url . "?data=" . $newData;
    }

    public function get2Safe($url, $data)
    {
        $key = "3bba47d9b26bb5978197751400639K8K";
        $newData = $this->lib->encode($data, $key);
        return base_url() . $url . "?data=" . $newData;
    }

    public function getVal($data)
    {
        $key = "3bba47d9b26bb5978197751400639K8K";
        $i = 0;
        $fetch = array(  );
        $val = $this->lib->decode($data, $key);
        $vaA = explode(";", $val);
        foreach( $vaA as $key ) 
        {
            $wh = explode("=", $key);
            $fetch[$wh[0]] = $wh[1];
            $i++;
        }
        return $fetch;
    }

    public function rowab($id)
    {
        if( $id % 2 ) 
        {
            echo "rowb";
        }
        else
        {
            echo "rowa";
        }

    }

    public function getMyReseller($type)
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $q = $this->db->query("SELECT id, username, user_type FROM resellers WHERE rs" . $level . "='" . $id . "'AND user_type='" . $type . "'");
        return $q->result();
    }

    public function thisUser($id)
    {
        $result = NULL;
        $q = $this->db->query("SELECT username, user_type FROM resellers WHERE id='" . $id . "' LIMIT 1");
        if( $q->num_rows() == 1 ) 
        {
            $row = $q->row();
            $type = $this->lib->getLevel($row->user_type);
            $result = $row->username . " (" . $type . ")";
        }

        return $result;
    }

    public function serviceByUri($uri)
    {
        $q = $this->db->select("*")->from("services")->where(array( "spaceuri" => $uri ))->limit(1);
        $r = $q->get()->row();
        if( count($r) == 1 ) 
        {
            return $r;
        }

        show_404();
        exit();
    }

    public function serviceByType($type)
    {
        $q = $this->db->select("*")->from("services")->where(array( "type" => $type ))->limit(1);
        $r = $q->get()->row();
        if( count($r) == 1 ) 
        {
            return $r;
        }

        show_404();
        exit();
    }

    public function dedBal_all($res, $level, $cost)
    {
        $uRow = $this->lib->getUser($res);
        $this->lib->dedbal($res, $cost["main"]);
        $this->lib->dedbal($uRow->rs5, $cost["rs5"]);
        $this->lib->dedbal($uRow->rs4, $cost["rs4"]);
        $this->lib->dedbal($uRow->rs3, $cost["rs3"]);
        $this->lib->dedbal($uRow->rs2, $cost["rs2"]);
    }

    public function addBal_all($res, $cost)
    {
        $uRow = $this->lib->getUser($res);
        $this->lib->addBal($res, $cost["main"]);
        $this->lib->addBal($uRow->rs5, $cost["rs5"]);
        $this->lib->addBal($uRow->rs4, $cost["rs4"]);
        $this->lib->addBal($uRow->rs3, $cost["rs3"]);
        $this->lib->addBal($uRow->rs2, $cost["rs2"]);
    }

    public function safeAmount($type, $amount)
    {
        $status = 0;
        $r = $this->db->select("risk_amount risk, require_pid nid")->from("services")->where("type", $type)->get()->row();
        if( $r->nid == 1 ) 
        {
            $status = 5;
        }
        else
        {
            $status = 0;
        }

        if( 0 < $r->risk ) 
        {
            if( $r->risk < $amount ) 
            {
                $status = 5;
            }
            else
            {
                $status = 0;
            }

        }

        return $status;
    }

    public function request($service, $number, $amount, $type, $res, $level, $cid = "-1", $oid = "-1", $photoid = "", $sendername = "", $receivername = "", $photofile = "")
    {
        $table = $this->lib->req_tbl();
        $amount = round($amount);
        $uRow = $this->lib->getUser($res);
        if( $service != 512 ) 
        {
            if( $this->startsWith($number, "008801") ) 
            {
                $number = substr($number, 4);
            }

            if( $this->startsWith($number, "8801") ) 
            {
                $number = substr($number, 2);
            }

        }

        $cost["main"] = $this->session->userdata("cost");
        $cost["rs5"] = $this->session->userdata("cost5");
        $cost["rs4"] = $this->session->userdata("cost4");
        $cost["rs3"] = $this->session->userdata("cost3");
        $cost["rs2"] = $this->session->userdata("cost2");
        $bb1 = $this->lib->getBal($res);
        $bb5 = $this->lib->getBal($uRow->rs5);
        $bb4 = $this->lib->getBal($uRow->rs4);
        $bb3 = $this->lib->getBal($uRow->rs3);
        $bb2 = $this->lib->getBal($uRow->rs2);
        $this->lib->dedBal_all($res, $level, $cost);
        if( !strlen($type) ) 
        {
            $type = 1;
        }

        $data = array( "cid" => $cid, "oid" => $oid, "sender" => $res, "receiver" => $number, "amount" => $amount, "type" => $type, "status" => $this->lib->safeAmount($service, $amount), "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "currency" => $uRow->currency, "bal" => $bb1 . "," . $this->lib->getBal($res), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "service_id" => $service, "req_time" => date("Y-m-d H:i:s"), "ip" => $this->lib->RemoteIP(), "photoid" => (strlen($photoid) ? $photoid : ""), "sendername" => (strlen($sendername) ? $sendername : ""), "receivername" => (strlen($receivername) ? $receivername : ""), "photofile" => (strlen($photofile) ? $photofile : "") );
        $this->db->insert($table, $data);
        $send = $this->db->insert_id();
        $this->load->model("Module", "mod");
        $this->mod->request($send, $data);
        return $send;
    }

    public function request_global($service, $package, $number, $type, $res, $level)
    {
        $table = $this->lib->req_tbl();
        $pack = $this->lib->getIntPack($package);
        $amount = round($pack->amount);
        $uRow = $this->lib->getUser($res);
        $cost["main"] = $this->session->userdata("cost");
        $cost["rs5"] = $this->session->userdata("cost5");
        $cost["rs4"] = $this->session->userdata("cost4");
        $cost["rs3"] = $this->session->userdata("cost3");
        $cost["rs2"] = $this->session->userdata("cost2");
        $bb1 = $this->lib->getBal($res);
        $bb5 = $this->lib->getBal($uRow->rs5);
        $bb4 = $this->lib->getBal($uRow->rs4);
        $bb3 = $this->lib->getBal($uRow->rs3);
        $bb2 = $this->lib->getBal($uRow->rs2);
        $this->lib->dedBal_all($res, $level, $cost);
        if( !strlen($type) ) 
        {
            $type = 1;
        }

        $data = array( "cid" => $pack->country, "oid" => $pack->operator, "sender" => $res, "receiver" => $number, "amount" => $pack->amount, "type" => $type, "status" => $this->lib->safeAmount($service, $amount), "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "currency" => $uRow->currency, "bal" => $bb1 . "," . $this->lib->getBal($res), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "service_id" => $service, "req_time" => date("Y-m-d H:i:s"), "ip" => $this->lib->RemoteIP(), "photoid" => "", "sendername" => "", "receivername" => "", "photofile" => "" );
        $this->db->insert($table, $data);
        $send = $this->db->insert_id();
        $this->load->model("Module", "mod");
        $this->mod->global_request($send, $data, $pack);
        return $send;
    }

    public function startsWith($haystack, $needle)
    {
        return !strncmp($haystack, $needle, strlen($needle));
    }

    public function bulk_request($service, $number, $amount, $type, $res, $level)
    {
        $amount = round($amount);
        $valid = 1;
        $uRow = $this->lib->getUser($res);
        $var = $this->lib->bulk_destination(8, $number, $amount, $type, $res, $level);
        $valid = $var["verify_dst"];
        $valid = $var["verify_bal"];
        $valid = $var["verify_cst"];
        if( $valid == 1 ) 
        {
            $getCost = $var["cost_var"];
            $cost["main"] = $getCost["cost"];
            $cost["rs5"] = $getCost["cost5"];
            $cost["rs4"] = $getCost["cost4"];
            $cost["rs3"] = $getCost["cost3"];
            $cost["rs2"] = $getCost["cost2"];
            $bb1 = $this->lib->getBal($res);
            $bb5 = $this->lib->getBal($uRow->rs5);
            $bb4 = $this->lib->getBal($uRow->rs4);
            $bb3 = $this->lib->getBal($uRow->rs3);
            $bb2 = $this->lib->getBal($uRow->rs2);
            $this->lib->dedBal_all($res, $level, $cost);
            $data = array( "sender" => $res, "receiver" => $number, "amount" => $amount, "type" => $type, "status" => $this->lib->safeAmount($service, $amount), "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "currency" => $uRow->currency, "bal" => $bb1 . "," . $this->lib->getBal($res), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "service_id" => $service, "req_time" => date("Y-m-d H:i:s"), "ip" => $this->lib->RemoteIP() );
            $req_tbl = $this->lib->req_tbl();
            $this->db->insert($req_tbl, $data);
            $send = $this->db->insert_id();
            $this->mod->request($send, $data);
        }
        else
        {
            $send = 0;
        }

        return $send;
    }

    public function verify_bank($bank, $amount, $res, $level)
    {
        $this->session->unset_userdata("cost");
        $this->session->unset_userdata("cost5");
        $this->session->unset_userdata("cost4");
        $this->session->unset_userdata("cost3");
        $this->session->unset_userdata("cost2");
        $service = 4;
        $amount = round($amount);
        $flag["verify_dst"] = 1;
        $flag["verify_bal"] = 1;
        $flag["verify_cst"] = 1;
        $uRow = $this->lib->getUser($res);
        $orSql = " LIMIT 1";
        $exRate = $this->lib->bankRate($bank);
        $bQ = $this->db->query("SELECT * FROM bankrates WHERE amount_start <='" . $amount . "' AND amount_end >= '" . $amount . "' AND bid='" . $bank . "' ORDER BY amount_start ASC LIMIT 1");
        if( $bQ->num_rows() == 1 ) 
        {
            $bR = $bQ->row();
            $cost = $amount / $exRate;
            if( $bR->type == "FIXED" ) 
            {
                $cost = $cost + $bR->charge;
            }
            else
            {
                $cost = $cost + ($cost * $bR->charge) / 100;
            }

            $allrs = array( "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "rs" => $res );
            foreach( $allrs as $key => $rsid ) 
            {
                if( $rsid != "-1" ) 
                {
                    $q1 = $this->db->query("SELECT * FROM rates WHERE service_id='4' AND res_id='" . $rsid . "'  AND enable='1'");
                    if( $q1->num_rows() == 1 ) 
                    {
                        $r = $q1->row();
                        $commision = 0;
                        $charge = 0;
                        $commision = ($cost * $r->commision) / 100;
                        $charge = ($cost * $r->charge) / 100;
                        $cost = $cost - $commision + $charge;
                        if( 0 < $cost ) 
                        {
                            $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $cost . "' AND id='" . $rsid . "' LIMIT 1");
                            $bR = $bQ->row();
                            if( $bR->bal == 1 ) 
                            {
                                $cs = str_replace("rs", "", $key);
                                $this->session->set_userdata("cost" . $cs, round($cost, 4));
                            }
                            else
                            {
                                $flag["verify_bal"] = 0;
                            }

                        }
                        else
                        {
                            $flag["verify_cst"] = 0;
                        }

                    }
                    else
                    {
                        $flag["verify_dst"] = 0;
                    }

                }

            }
        }
        else
        {
            $flag["verify_dst"] = 0;
        }

        return $flag;
    }

    public function verify_pintransfer($country, $amount, $res, $level)
    {
        $this->session->unset_userdata("cost");
        $this->session->unset_userdata("cost5");
        $this->session->unset_userdata("cost4");
        $this->session->unset_userdata("cost3");
        $this->session->unset_userdata("cost2");
        $service = 4;
        $amount = round($amount);
        $flag["verify_dst"] = 1;
        $flag["verify_bal"] = 1;
        $flag["verify_cst"] = 1;
        $uRow = $this->lib->getUser($res);
        $orSql = " LIMIT 1";
        $exRate = $this->lib->pinRate($country);
        $bQ = $this->db->query("SELECT * FROM bankpinrates WHERE amount_start <='" . $amount . "' AND amount_end >= '" . $amount . "' AND cid='" . $country . "' ORDER BY amount_start ASC LIMIT 1");
        if( $bQ->num_rows() == 1 ) 
        {
            $bR = $bQ->row();
            $cost = $amount / $exRate;
            if( $bR->type == "FIXED" ) 
            {
                $cost = $cost + $bR->charge;
            }
            else
            {
                $cost = $cost + ($cost * $bR->charge) / 100;
            }

            $allrs = array( "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "rs" => $res );
            foreach( $allrs as $key => $rsid ) 
            {
                if( $rsid != "-1" ) 
                {
                    $q1 = $this->db->query("SELECT * FROM rates WHERE service_id='4' AND res_id='" . $rsid . "'  AND enable='1'");
                    if( $q1->num_rows() == 1 ) 
                    {
                        $r = $q1->row();
                        $commision = 0;
                        $charge = 0;
                        $commision = ($cost * $r->commision) / 100;
                        $charge = ($cost * $r->charge) / 100;
                        $cost = $cost - $commision + $charge;
                        if( 0 < $cost ) 
                        {
                            $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $cost . "' AND id='" . $rsid . "' LIMIT 1");
                            $bR = $bQ->row();
                            if( $bR->bal == 1 ) 
                            {
                                $cs = str_replace("rs", "", $key);
                                $this->session->set_userdata("cost" . $cs, round($cost, 4));
                            }
                            else
                            {
                                $flag["verify_bal"] = 0;
                            }

                        }
                        else
                        {
                            $flag["verify_cst"] = 0;
                        }

                    }
                    else
                    {
                        $flag["verify_dst"] = 0;
                    }

                }

            }
        }
        else
        {
            $flag["verify_dst"] = 0;
        }

        return $flag;
    }

    public function verify_card($opt, $amt, $res, $level)
    {
        $this->session->unset_userdata("cost");
        $this->session->unset_userdata("cost5");
        $this->session->unset_userdata("cost4");
        $this->session->unset_userdata("cost3");
        $this->session->unset_userdata("cost2");
        $service = 2;
        $q = $this->db->query("SELECT cost FROM card_amount WHERE id='" . $amt . "' LIMIT 1");
        $r = $q->row();
        $amount = $r->cost;
        $flag["verify_dst"] = 1;
        $flag["verify_bal"] = 1;
        $flag["verify_cst"] = 1;
        $uRow = $this->lib->getUser($res);
        $orSql = " LIMIT 1";
        $allrs = array( "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "rs" => $res );
        foreach( $allrs as $key => $rsid ) 
        {
            if( $rsid != "-1" ) 
            {
                $rQ = $this->db->query("SELECT * FROM rates WHERE service_id='" . $service . "' AND res_id='" . $res . "' AND enable='1' " . $orSql);
                if( $rQ->num_rows() == 1 ) 
                {
                    $rT = $rQ->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $rT->commision ) 
                    {
                        $commision = ($cost * $rT->commision) / 100;
                    }

                    if( 0 < $rT->charge ) 
                    {
                        $charge = ($cost * $rT->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $cost . "' AND id='" . $rsid . "' LIMIT 1");
                        $bR = $bQ->row();
                        if( $bR->bal == 1 ) 
                        {
                            $cs = str_replace("rs", "", $key);
                            $this->session->set_userdata("cost" . $cs, round($cost, 4));
                        }
                        else
                        {
                            $flag["verify_bal"] = 0;
                        }

                    }
                    else
                    {
                        $flag["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag["verify_dst"] = 0;
                }

            }

        }
        return $flag;
    }

    public function verify_destination($service, $number, $amount, $type, $res, $level, $vrfy_type = 0)
    {
        $amount = round($amount);
        $sRow = $this->lib->serviceByType($service);
        $exRate = $this->lib->exRate($sRow->currency);
        $this->session->unset_userdata("cost");
        $this->session->unset_userdata("cost5");
        $this->session->unset_userdata("cost4");
        $this->session->unset_userdata("cost3");
        $this->session->unset_userdata("cost2");
        $this->session->unset_userdata("currency");
        $flag["verify_dst"] = 1;
        $flag["verify_bal"] = 1;
        $flag["verify_cst"] = 1;
        $uRow = $this->lib->getUser($res);
        $this->session->set_userdata("currency", $uRow->currency);
        $rQ = $this->db->query("SELECT * FROM rates_slab WHERE amount_start <='" . $amount . "' AND amount_end >= '" . $amount . "' AND sid='" . $service . "' ORDER BY amount_start ASC LIMIT 1");
        if( $rQ->num_rows() == 1 ) 
        {
            $rR = $rQ->row();
            if( $rR->type == "FIXED" ) 
            {
                $amount = $amount + $rR->charge;
            }
            else
            {
                $amount = $amount + ($amount * $rR->charge) / 100;
            }

        }

        $len = strlen($number);
        $prefix[] = $number;
        $where = NULL;
        $i = 0;
        while( $i < $len ) 
        {
            $prefix[] = substr($number, 0, 0 - $i);
            $i++;
        }
        foreach( $prefix as $row ) 
        {
            $where .= " prefix LIKE '" . $row . "' OR";
        }
        $search = substr_replace($where, "", -2);
        if( $vrfy_type == 1 ) 
        {
            $tSQl = "AND type='" . $type . "'";
        }
        else
        {
            $tSQl = NULL;
        }

        $orSql = "ORDER BY prefix DESC LIMIT 1";
        $allrs = array( "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "rs" => $res );
        foreach( $allrs as $key => $rsid ) 
        {
            if( $rsid != "-1" ) 
            {
                $rQ = $this->db->query("SELECT * FROM rates WHERE service_id='" . $service . "' AND res_id='" . $rsid
                    . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
                if( $rQ->num_rows() == 1 ) 
                {
                    $rT = $rQ->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $rT->rate ) 
                    {
                        $cost = $rT->rate * $amount;
                    }

                    if( 0 < $rT->commision ) 
                    {
                        $commision = ($cost * $rT->commision) / 100;
                    }

                    if( 0 < $rT->charge ) 
                    {
                        $charge = ($cost * $rT->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $cost . "' AND id='" . $rsid . "' LIMIT 1");
                        $bR = $bQ->row();
                        if( $bR->bal == 1 ) 
                        {
                            $cs = str_replace("rs", "", $key);
                            $this->session->set_userdata("cost" . $cs, round($cost, 4));
                        }
                        else
                        {
                            $flag["verify_bal"] = 0;
                        }

                    }
                    else
                    {
                        $flag["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag["verify_dst"] = 0;
                }

            }

        }
        return $flag;
    }

    public function verify_global($number, $pack, $type, $res, $level)
    {
        $this->session->unset_userdata("cost");
        $this->session->unset_userdata("cost5");
        $this->session->unset_userdata("cost4");
        $this->session->unset_userdata("cost3");
        $this->session->unset_userdata("cost2");
        $this->session->unset_userdata("currency");
        $flag["verify_dst"] = 1;
        $flag["verify_bal"] = 1;
        $flag["verify_cst"] = 1;
        $uRow = $this->lib->getUser($res);
        $this->session->set_userdata("currency", $uRow->currency);
        $allrs = array( "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "rs" => $res );
        foreach( $allrs as $key => $rsid ) 
        {
            if( $rsid != "-1" ) 
            {
                $g = $this->lib->globalTariff($rsid);
                $cost = $pack->cost;
                $commision = 0;
                $charge = 0;
                if( 0 < $g->comission ) 
                {
                    $commision = ($cost * $g->comission) / 100;
                }

                if( 0 < $g->charge ) 
                {
                    $charge = ($cost * $g->charge) / 100;
                }

                $cost = $cost - $commision + $charge;
                if( 0 < $cost ) 
                {
                    $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $cost . "' AND id='" . $rsid . "' LIMIT 1");
                    $bR = $bQ->row();
                    if( $bR->bal == 1 ) 
                    {
                        $cs = str_replace("rs", "", $key);
                        $this->session->set_userdata("cost" . $cs, round($cost, 4));
                    }
                    else
                    {
                        $flag["verify_bal"] = 0;
                    }

                }
                else
                {
                    $flag["verify_cst"] = 0;
                }

            }

        }
        return $flag;
    }

    public function bulk_destination($service, $number, $amount, $type, $res, $level, $vrfy_type = 0)
    {
        $sRow = $this->lib->serviceByType($service);
        $exRate = $this->lib->exRate($sRow->currency);
        $cost_var["cost"] = 0;
        $cost_var["cost5"] = 0;
        $cost_var["cost4"] = 0;
        $cost_var["cost3"] = 0;
        $cost_var["cost2"] = 0;
        $flag["verify_dst"] = 1;
        $flag["verify_bal"] = 1;
        $flag["verify_cst"] = 1;
        $uRow = $this->lib->getUser($res);
        $len = strlen($number);
        $prefix[] = $number;
        $where = NULL;
        $i = 0;
        while( $i < $len ) 
        {
            $prefix[] = substr($number, 0, 0 - $i);
            $i++;
        }
        foreach( $prefix as $row ) 
        {
            $where .= " prefix LIKE '" . $row . "' OR";
        }
        $search = substr_replace($where, "", -2);
        if( $vrfy_type == 1 ) 
        {
            $tSQl = "AND type='" . $type . "'";
        }
        else
        {
            $tSQl = NULL;
        }

        $orSql = "ORDER BY prefix DESC LIMIT 1";
        $allrs = array( "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "rs" => $res );
        foreach( $allrs as $key => $rsid ) 
        {
            if( $rsid != "-1" ) 
            {
                $rQ = $this->db->query("SELECT * FROM rates WHERE service_id='" . $service . "' AND res_id='" . $rsid . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
                if( $rQ->num_rows() == 1 ) 
                {
                    $rT = $rQ->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $rT->rate ) 
                    {
                        $cost = $rT->rate * $amount;
                    }

                    if( 0 < $rT->commision ) 
                    {
                        $commision = ($cost * $rT->commision) / 100;
                    }

                    if( 0 < $rT->charge ) 
                    {
                        $charge = ($cost * $rT->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $cost . "' AND id='" . $rsid . "' LIMIT 1");
                        $bR = $bQ->row();
                        if( $bR->bal == 1 ) 
                        {
                            $cs = str_replace("rs", "", $key);
                            $cost_var["cost" . $cs] = round($cost, 4);
                        }
                        else
                        {
                            $flag["verify_bal"] = 0;
                        }

                    }
                    else
                    {
                        $flag["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag["verify_dst"] = 0;
                }

            }

        }
        $flag["cost_var"] = $cost_var;
        return $flag;
    }

    public function bulk_verify($list_id)
    {
        $sRow = $this->lib->serviceByType(8);
        $exRate = $this->lib->exRate($sRow->currency);
        $verify[0] = NULL;
        $verify["verify_bal"] = 1;
        $prefix[] = NULL;
        $tSQl = NULL;
        $orSql = "ORDER BY prefix DESC LIMIT 1";
        $flag[0]["verify_dst"] = 1;
        $costM = 0;
        $costR5 = 0;
        $costR4 = 0;
        $costR3 = 0;
        $costR2 = 0;
        $flag[0]["verify_cst"] = 1;
        $flag[0]["verify_ant"] = 1;
        $flag[0]["verify_int"] = 1;
        $res = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $uRow = $this->lib->getUser($res);
        $sRow = $this->lib->serviceByUri("flexiload");
        $interbal = $this->lib->getSet("req_interval");
        $where = array( "lid" => $list_id, "rid" => $res );
        $query = $this->db->query("SELECT id, COUNT(*) tot FROM flexi_bulk_numbers WHERE lid='" . $list_id . "' AND rid='" . $res . "' GROUP BY number HAVING tot > 1");
        if( 0 < $query->num_rows() ) 
        {
            $result = $query->result();
            $verify["duplicate"] = $result;
        }

        $q = $this->db->select("*")->from("flexi_bulk_numbers")->where($where);
        $result = $q->get()->result();
        foreach( $result as $row ) 
        {
            unset($prefix);
            $number = $row->number;
            $amount = $row->amount;
            $amount = round($amount);
            if( $amount < $sRow->min_amnt || $sRow->max_amnt < $amount ) 
            {
                $flag[$row->id]["verify_ant"] = 0;
            }

            $time = $this->lib->inTime($number, 8, $interbal);
            if( !$time ) 
            {
                $flag[$row->id]["verify_int"] = 0;
            }

            $len = strlen($number);
            $prefix[] = $number;
            $where = NULL;
            $i = 0;
            while( $i < $len ) 
            {
                $prefix[] = substr($number, 0, 0 - $i);
                $i++;
            }
            foreach( $prefix as $pow ) 
            {
                $where .= " prefix LIKE '" . $pow . "' OR";
            }
            $search = substr_replace($where, "", -2);
            $q1 = $this->db->query("SELECT * FROM rates WHERE service_id='8' AND res_id='" . $res . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
            if( $q1->num_rows() == 1 ) 
            {
                $r = $q1->row();
                $cost = $amount;
                $commision = 0;
                $charge = 0;
                if( 0 < $r->rate ) 
                {
                    $cost = $r->rate * $amount;
                }

                if( 0 < $r->commision ) 
                {
                    $commision = ($cost * $r->commision) / 100;
                }

                if( 0 < $r->charge ) 
                {
                    $charge = ($cost * $r->charge) / 100;
                }

                $cost = $cost - $commision + $charge;
                if( 0 < $cost ) 
                {
                    $costM += $cost;
                }
                else
                {
                    $flag[$row->id]["verify_cst"] = 0;
                }

            }
            else
            {
                $flag[$row->id]["verify_dst"] = 0;
            }

            if( $uRow->rs5 != "-1" ) 
            {
                $q5 = $this->db->query("SELECT * FROM rates WHERE service_id='8' AND res_id='" . $uRow->rs5 . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
                if( $q5->num_rows() == 1 ) 
                {
                    $r = $q5->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $r->rate ) 
                    {
                        $cost = $r->rate * $amount;
                    }

                    if( 0 < $r->commision ) 
                    {
                        $commision = ($cost * $r->commision) / 100;
                    }

                    if( 0 < $r->charge ) 
                    {
                        $charge = ($cost * $r->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $costR5 += $cost;
                    }
                    else
                    {
                        $flag[$row->id]["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag[$row->id]["verify_dst"] = 0;
                }

            }

            if( $uRow->rs4 != "-1" ) 
            {
                $q4 = $this->db->query("SELECT * FROM rates WHERE service_id='8' AND res_id='" . $uRow->rs4 . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
                if( $q4->num_rows() == 1 ) 
                {
                    $r = $q4->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $r->rate ) 
                    {
                        $cost = $r->rate * $amount;
                    }

                    if( 0 < $r->commision ) 
                    {
                        $commision = ($cost * $r->commision) / 100;
                    }

                    if( 0 < $r->charge ) 
                    {
                        $charge = ($cost * $r->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $costR4 += $cost;
                    }
                    else
                    {
                        $flag[$row->id]["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag[$row->id]["verify_dst"] = 0;
                }

            }

            if( $uRow->rs3 != "-1" ) 
            {
                $q3 = $this->db->query("SELECT * FROM rates WHERE service_id='8' AND res_id='" . $uRow->rs3 . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
                if( $q3->num_rows() == 1 ) 
                {
                    $r = $q3->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $r->rate ) 
                    {
                        $cost = $r->rate * $amount;
                    }

                    if( 0 < $r->commision ) 
                    {
                        $commision = ($cost * $r->commision) / 100;
                    }

                    if( 0 < $r->charge ) 
                    {
                        $charge = ($cost * $r->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $costR3 += $cost;
                    }
                    else
                    {
                        $flag[$row->id]["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag[$row->id]["verify_dst"] = 0;
                }

            }

            if( $uRow->rs2 != "-1" ) 
            {
                $q2 = $this->db->query("SELECT * FROM rates WHERE service_id='8' AND res_id='" . $uRow->rs2 . "' AND enable='1' " . $tSQl . " AND (" . $search . ") " . $orSql);
                if( $q2->num_rows() == 1 ) 
                {
                    $r = $q2->row();
                    $cost = $amount;
                    $commision = 0;
                    $charge = 0;
                    if( 0 < $r->rate ) 
                    {
                        $cost = $r->rate * $amount;
                    }

                    if( 0 < $r->commision ) 
                    {
                        $commision = ($cost * $r->commision) / 100;
                    }

                    if( 0 < $r->charge ) 
                    {
                        $charge = ($cost * $r->charge) / 100;
                    }

                    $cost = $cost - $commision + $charge;
                    if( 0 < $cost ) 
                    {
                        $costR2 += $cost;
                    }
                    else
                    {
                        $flag[$row->id]["verify_cst"] = 0;
                    }

                }
                else
                {
                    $flag[$row->id]["verify_dst"] = 0;
                }

            }

        }
        $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $costM . "' AND id='" . $res . "' LIMIT 1");
        $bR = $bQ->row();
        if( $bR->bal != 1 ) 
        {
            $verify["verify_bal"] = 0;
        }

        if( $uRow->rs5 != "-1" ) 
        {
            $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $costR5 . "' AND id='" . $uRow->rs5 . "' LIMIT 1");
            $bR = $bQ->row();
            if( $bR->bal != 1 ) 
            {
                $verify["verify_bal"] = 0;
            }

        }

        if( $uRow->rs4 != "-1" ) 
        {
            $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $costR4 . "' AND id='" . $uRow->rs4 . "' LIMIT 1");
            $bR = $bQ->row();
            if( $bR->bal != 1 ) 
            {
                $verify["verify_bal"] = 0;
            }

        }

        if( $uRow->rs3 != "-1" ) 
        {
            $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $costR3 . "' AND id='" . $uRow->rs3 . "' LIMIT 1");
            $bR = $bQ->row();
            if( $bR->bal != 1 ) 
            {
                $verify["verify_bal"] = 0;
            }

        }

        if( $uRow->rs2 != "-1" ) 
        {
            $bQ = $this->db->query("SELECT count(*) as bal FROM resellers WHERE balance >= '" . $costR2 . "' AND id='" . $uRow->rs2 . "' LIMIT 1");
            $bR = $bQ->row();
            if( $bR->bal != 1 ) 
            {
                $verify["verify_bal"] = 0;
            }

        }

        unset($flag[0]);
        unset($verify[0]);
        $verify["flag"] = $flag;
        return $verify;
    }

    public function last_req($service_id)
    {
        $req_tbl = $this->lib->req_tbl();
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $q = $this->db->query("SELECT receiver,amount,type,cost,status FROM " . $req_tbl . " WHERE service_id='" . $service_id . "' AND sender='" . $id . "' ORDER BY id DESC LIMIT 10");
        return $q->result();
    }

    public function convert_type($service_id, $type)
    {
        $title = NULL;
        if( $service_id == 8 ) 
        {
            if( $type == 1 ) 
            {
                $title = "Prepaid";
            }

            if( $type == 2 ) 
            {
                $title = "PostPaid";
            }

        }
        else
        {
            if( $service_id == 512 ) 
            {
                if( $type == 1 ) 
                {
                    $title = "Prepaid";
                }

                if( $type == 2 ) 
                {
                    $title = "PostPaid";
                }

            }
            else
            {
                if( $service_id == 32 ) 
                {
                    if( $type == 1 ) 
                    {
                        $title = "CashIn";
                    }

                    if( $type == 2 ) 
                    {
                        $title = "CashOut";
                    }

                }
                else
                {
                    if( $service_id != 4 ) 
                    {
                        $title = "Transfer";
                    }

                }

            }

        }

        return $title;
    }

    public function getReq($id, $str = NULL)
    {
        if( $str == NULL ) 
        {
            $table = $this->lib->req_tbl();
        }
        else
        {
            $table = "requests_" . $str;
        }

        $q = $this->db->select("*")->from($table)->where("id", $id)->limit(1);
        $d = $q->get();
        if( $d->num_rows() == 0 ) 
        {
            show_404();
            exit();
        }

        $r = $d->row();
        return $r;
    }

    public function fStatus($status)
    {
        $admin = $this->session->userdata("thisadmin");
        if( $status == 0 ) 
        {
            $title = "<span style='color:red'>Pending</span>";
        }

        if( $status == 1 ) 
        {
            $title = "<span style='color:blue'>Processed</span>";
        }

        if( $status == 2 ) 
        {
            $title = "<span style='color:#ccc'>Failed</span>";
        }

        if( $status == 3 ) 
        {
            $title = "<span style='color:#FF9500'>Cancelled</span>";
        }

        if( $status == 4 ) 
        {
            $title = "<span style='color:green'>Completed</span>";
        }

        if( $status == 5 ) 
        {
            $title = "<span style='color:red'>Pending</span>";
        }

        if( $admin == true ) 
        {
            if( $status == 5 ) 
            {
                $title = "<span style='color:#333'>Waiting</span>";
            }

        }

        return $title;
    }

    public function inTime($number, $service_id, $interbal, $amount = 0)
    {
        $req_tbl = $this->lib->req_tbl();
        if( $service_id == 8 ) 
        {
            $bd = $this->lib->startsWith($number, "8801");
            if( $bd == 1 ) 
            {
                $number = substr($number, strlen($number) - 11);
            }

            $cd = $this->lib->startsWith($number, "008801");
            if( $cd == 1 ) 
            {
                $number = substr($number, strlen($number) - 11);
            }

        }

        $return = true;
        $query = $this->db->query("SELECT id FROM " . $req_tbl . " WHERE receiver='" . $number . "' AND service_id='" . $service_id . "' AND last_update > NOW() - INTERVAL " . $interbal . " MINUTE");
        $rows = $query->num_rows();
        if( 0 < $rows ) 
        {
            $return = false;
        }

        $query = $this->db->query("SELECT count(*) as found FROM " . $req_tbl . " WHERE receiver='" . $number . "' AND amount='" . $amount . "' AND service_id='" . $service_id . "' AND status < 3");
        $r = $query->row();
        if( 0 < $r->found ) 
        {
            $return = false;
        }

        return $return;
    }

    public function isMyList($lid)
    {
        $title = NULL;
        $rid = $this->session->userdata("id");
        $where = array( "id" => $lid, "res_id" => $rid );
        $q = $this->db->select("title")->from("flexi_bulk_list")->where($where)->limit(1);
        $d = $q->get();
        if( $d->num_rows() == 0 ) 
        {
            redirect("main", "location");
        }
        else
        {
            $r = $d->row();
            $title = $r->title;
        }

        return $title;
    }

    public function bulkListbyID($lid)
    {
        $where = array( "id" => $lid );
        $q = $this->db->select("*")->from("flexi_bulk_list")->where($where)->limit(1);
        $d = $q->get();
        if( $d->num_rows() == 0 ) 
        {
            redirect("admin", "location");
        }
        else
        {
            return $d->row();
        }

    }

    public function getBulkList($lid, $e = "")
    {
        $bulk_limit = $this->lib->getSet("bulk_limit");
        $rid = $this->session->userdata("id");
        $thisadmin = $this->session->userdata("thisadmin");
        if( $thisadmin != true ) 
        {
            $where["rid"] = $rid;
        }

        $where["lid"] = $lid;
        $q = $this->db->select("*")->from("flexi_bulk_numbers")->where($where)->order_by("id", "ASC")->limit($bulk_limit);
        if( $e == "exe" ) 
        {
            $q->where("enable", 1);
        }

        $r = $q->get()->result();
        return $r;
    }

    public function ttlNumber($id)
    {
        $q = $this->db->select("count(*) as total")->from("flexi_bulk_numbers")->where(array( "lid" => $id ));
        $r = $q->get()->row();
        return $r->total;
    }

    public function ttlAmount($id)
    {
        $q = $this->db->select("SUM(amount) as total")->from("flexi_bulk_numbers")->where(array( "lid" => $id ));
        $r = $q->get()->row();
        return $r->total;
    }

    public function getMyBulkList()
    {
        $res_id = $this->session->userdata("id");
        $q = $this->db->select("id,title")->from("flexi_bulk_list")->where("res_id", $res_id);
        return $q->get()->result();
    }

    public function errorMsg($str)
    {
        $sRow = $this->lib->serviceByUri("flexiload");
        $interbal = $this->lib->getSet("req_interval");
        if( $str == "verify_dst" ) 
        {
            $error = "Number format invalid or not allowed.";
        }

        if( $str == "verify_cst" ) 
        {
            $error = "Sorry! rate was not found.";
        }

        if( $str == "verify_ant" ) 
        {
            $error = "Amount must between " . $sRow->min_amnt . " & " . $sRow->max_amnt . ".";
        }

        if( $str == "verify_int" ) 
        {
            $error = "Can't process same number within " . $interbal . " minute.";
        }

        if( $str == "duplicate" ) 
        {
            $error = "Can't process this number due to duplicate entry";
        }

        return $error;
    }

    public function getOptList()
    {
        $q = $this->db->get("card_opt");
        return $q->result();
    }

    public function isAvailable($opt, $amnt, $type)
    {
        $q = $this->db->query("SELECT count(*) as total FROM card_store WHERE opt='" . $opt . "' AND amnt='" . $amnt . "' AND type='" . $type . "' AND sell='-1' AND userid='-1'");
        $r = $q->row();
        return $r->total;
    }

    public function bilTitle($id)
    {
        $q = $this->db->select("title")->from("billpay")->where("id", $id)->limit(1);
        $r = $q->get()->row();
        return $r->title;
    }

    public function opTitle($id)
    {
        $q = $this->db->select("title")->from("card_opt")->where("id", $id)->limit(1);
        $r = $q->get()->row();
        return $r->title;
    }

    public function getAmount($id)
    {
        $q = $this->db->select("amount")->from("card_amount")->where("id", $id)->limit(1);
        $r = $q->get()->row();
        return $r->amount;
    }

    public function getCardID($opt, $amnt, $type)
    {
        $q = $this->db->query("SELECT id FROM card_store WHERE opt='" . $opt . "' AND amnt='" . $amnt . "' AND type='" . $type . "' AND sell='-1' AND userid='-1' ORDER BY id ASC LIMIT 1");
        $r = $q->row();
        return $r->id;
    }

    public function banktransfer($country, $bank, $branch, $sender, $receiver, $account_name, $account, $amount, $note, $id, $level)
    {
        $uRow = $this->lib->getUser($id);
        $cost["main"] = $this->session->userdata("cost");
        $cost["rs5"] = $this->session->userdata("cost5");
        $cost["rs4"] = $this->session->userdata("cost4");
        $cost["rs3"] = $this->session->userdata("cost3");
        $cost["rs2"] = $this->session->userdata("cost2");
        $bb1 = $this->lib->getBal($id);
        $bb5 = $this->lib->getBal($uRow->rs5);
        $bb4 = $this->lib->getBal($uRow->rs4);
        $bb3 = $this->lib->getBal($uRow->rs3);
        $bb2 = $this->lib->getBal($uRow->rs2);
        $this->lib->dedBal_all($id, $level, $cost);
        $data = array( "type" => "TRANSFER", "cid" => $country, "bid" => $bank, "bcid" => $branch, "sender" => $id, "receiver" => $account, "receivername" => $account_name, "amount" => $amount, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "bal" => $bb1 . "," . $this->lib->getBal($id), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "status" => 0, "note" => $note, "transactionid" => "", "receiptfile" => "", "ip" => $this->lib->RemoteIP(), "req_time" => date("Y-m-d H:i:s"), "last_update" => date("Y-m-d H:i:s"), "kycfrom" => $sender, "kycto" => $receiver );
        $this->db->insert("banktransfer", $data);
        $send = $this->db->insert_id();
        return $send;
    }

    public function pintransfer($country, $sender, $receiver, $amount, $note, $id, $level)
    {
        $uRow = $this->lib->getUser($id);
        $cost["main"] = $this->session->userdata("cost");
        $cost["rs5"] = $this->session->userdata("cost5");
        $cost["rs4"] = $this->session->userdata("cost4");
        $cost["rs3"] = $this->session->userdata("cost3");
        $cost["rs2"] = $this->session->userdata("cost2");
        $bb1 = $this->lib->getBal($id);
        $bb5 = $this->lib->getBal($uRow->rs5);
        $bb4 = $this->lib->getBal($uRow->rs4);
        $bb3 = $this->lib->getBal($uRow->rs3);
        $bb2 = $this->lib->getBal($uRow->rs2);
        $this->lib->dedBal_all($id, $level, $cost);
        $pinLen = $this->lib->getSet("pintransfer_length");
        $transferpin = $this->lib->random_numbers($pinLen);
        $data = array( "type" => "PIN", "cid" => $country, "bid" => "-1", "bcid" => "-1", "sender" => $id, "receiver" => $transferpin, "amount" => $amount, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "bal" => $bb1 . "," . $this->lib->getBal($id), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "status" => 0, "note" => $note, "transactionid" => "", "receiptfile" => "", "ip" => $this->lib->RemoteIP(), "req_time" => date("Y-m-d H:i:s"), "last_update" => date("Y-m-d H:i:s"), "kycfrom" => $sender, "kycto" => $receiver );
        $this->db->insert("banktransfer", $data);
        $send = $this->db->insert_id();
        return $send;
    }

    public function buycard($opt, $amount, $type, $receiver)
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $uRow = $this->lib->getUser($id);
        $cardId = $this->lib->getCardID($opt, $amount, $type);
        $cardUser = array( "userid" => $id, "sell" => 1, "buy_date" => date("Y-m-d H:i:s") );
        $this->db->where("id", $cardId);
        $this->db->update("card_store", $cardUser);
        $cost["main"] = $this->session->userdata("cost");
        $cost["rs5"] = $this->session->userdata("cost5");
        $cost["rs4"] = $this->session->userdata("cost4");
        $cost["rs3"] = $this->session->userdata("cost3");
        $cost["rs2"] = $this->session->userdata("cost2");
        $bb1 = $this->lib->getBal($id);
        $bb5 = $this->lib->getBal($uRow->rs5);
        $bb4 = $this->lib->getBal($uRow->rs4);
        $bb3 = $this->lib->getBal($uRow->rs3);
        $bb2 = $this->lib->getBal($uRow->rs2);
        $this->lib->dedBal_all($id, $level, $cost);
        $f = $this->db->select("amount")->from("card_amount")->where("id", $amount)->limit(1);
        $d = $f->get()->row();
        $data = array( "card_id" => $cardId, "opt_id" => $opt, "amnt_id" => $amount, "amount" => $d->amount, "receiver" => $receiver, "type" => $type, "sender" => $id, "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "bal" => $bb1 . "," . $this->lib->getBal($id), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "ip" => $this->lib->RemoteIP(), "req_time" => date("Y-m-d H:i:s"), "date_update" => date("Y-m-d H:i:s") );
        $this->db->insert("card_history", $data);
        $send = $this->db->insert_id();
        if( strlen($receiver) ) 
        {
            $card = $this->lib->myCard($cardId);
            $opttitle = $this->lib->opTitle($card->opt);
            $cardvalue = $this->lib->getAmount($card->amnt);
            $otp_route = $this->lib->getSet("otp_route");
            $senderid = $this->lib->getSet("brandname");
            $api = $this->lib->smsApi();
            $msg = (string) $opttitle . " " . $card->type . " card value " . $cardvalue . ". Serial No. " . $card->pin . ", PIN/Secret No. " . $card->pin;
            if( $otp_route == 1 && $api->found == 1 ) 
            {
                $senderid = substr($senderid, 0, 11);
                $senderid = urlencode($senderid);
                $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
                $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $receiver, "" . urlencode($msg) . "", "0" );
                $link = str_replace($uData, $sData, $api->url);
                $fdata = array(  );
                $this->lib->curl_get($link, $fdata);
                $route = $api->id;
            }
            else
            {
                $outbox = array( "rid" => "-1", "receiver" => $uRow->mobile, "message" => $msg, "status" => 0 );
                $this->db->insert("outbox", $outbox);
                $route = "-1";
            }

        }

        return $send;
    }

    public function myCard($id)
    {
        $q = $this->db->select()->from("card_store")->where("id", $id)->limit(1);
        $r = $q->get()->row();
        return $r;
    }

    public function getBillOpt()
    {
        $q = $this->db->select()->from("billpay")->where("enable", 1);
        $r = $q->get()->result();
        return $r;
    }

    public function isSmsList($lid)
    {
        $title = NULL;
        $rid = $this->session->userdata("id");
        $where = array( "id" => $lid, "res_id" => $rid );
        $q = $this->db->select("title")->from("sms_list")->where($where)->limit(1);
        $d = $q->get();
        if( $d->num_rows() == 0 ) 
        {
            redirect("main", "location");
        }
        else
        {
            $r = $d->row();
            $title = $r->title;
        }

        return $title;
    }

    public function ttlSMSNumber($lid)
    {
        $q = $this->db->select("COUNT(*) total")->from("sms_contacts")->where("lid", $lid);
        $r = $q->get()->row();
        return $r->total;
    }

    public function getbulksmslist($id)
    {
        $rid = $this->session->userdata("id");
        $q = $this->db->select("id,title")->from("sms_list")->where("res_id", $rid);
        $r = $q->get()->result();
        return $r;
    }

    public function getSMSList($id)
    {
        $q = $this->db->select("id,number,firstname,lastname")->from("sms_contacts")->where("lid", $id);
        $r = $q->get()->result();
        return $r;
    }

    public function smsApi()
    {
        $r = new stdClass();
        $r->found = 0;
        $q = $this->db->select("*")->from("sms_apis")->where("enable", 1)->limit(1);
        $d = $q->get();
        if( $d->num_rows() == 1 ) 
        {
            $a = $d->row();
            $r->found = 1;
            $r->id = $a->id;
            $r->user = $a->user;
            $r->apikey = $a->apikey;
            $r->response = $a->response;
            $r->url = $a->url;
        }

        return $r;
    }

    public function sendSMS($number, $from, $msg, $res, $level)
    {
        $api = $this->lib->smsApi();
        $uRow = $this->lib->getUser($res);
        $cost["main"] = $this->session->userdata("cost");
        $cost["rs5"] = $this->session->userdata("cost5");
        $cost["rs4"] = $this->session->userdata("cost4");
        $cost["rs3"] = $this->session->userdata("cost3");
        $cost["rs2"] = $this->session->userdata("cost2");
        $bb1 = $this->lib->getBal($res);
        $bb5 = $this->lib->getBal($uRow->rs5);
        $bb4 = $this->lib->getBal($uRow->rs4);
        $bb3 = $this->lib->getBal($uRow->rs3);
        $bb2 = $this->lib->getBal($uRow->rs2);
        $data = array( "sender" => $res, "sender_id" => $from, "receiver" => $number, "sms" => $msg, "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0), "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0), "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0), "bal" => "0,0", "bal5" => "0,0", "bal4" => "0,0", "bal3" => "0,0", "bal2" => "0,0", "api" => $api->id, "send_time" => date("Y-m-d H:i:s"), "ip" => $this->lib->RemoteIP() );
        $this->db->insert("sms_req", $data);
        $smsId = $this->db->insert_id();
        $msg = urlencode($msg);
        $senderid = urlencode($from);
        $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
        $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $number, (string) $msg, (string) $smsId );
        $link = str_replace($uData, $sData, $api->url);
        $fdata = array(  );
        $ret = $this->lib->curl_get($link, $fdata);
        $ret = "SUBMIT_SUCCESS";
        if( $ret == $api->response ) 
        {
            $this->lib->dedBal_all($res, $level, $cost);
            $upd = array( "bal" => $bb1 . "," . $this->lib->getBal($res), "bal5" => $bb5 . "," . $this->lib->getBal($uRow->rs5), "bal4" => $bb4 . "," . $this->lib->getBal($uRow->rs4), "bal3" => $bb3 . "," . $this->lib->getBal($uRow->rs3), "bal2" => $bb2 . "," . $this->lib->getBal($uRow->rs2), "status" => 4 );
            $this->db->where("id", $smsId);
            $this->db->update("sms_req", $upd);
            $result = 1;
        }
        else
        {
            $this->db->where("id", $smsId);
            $this->db->update("sms_req", array( "status" => 2, "cost" => 0, "cost5" => 0, "cost4" => 0, "cost3" => 0, "cost2" => 0 ));
            $result = 0;
        }

        return $result;
    }

    public function ttSts($type)
    {
        $txt = NULL;
        if( $type == 1 ) 
        {
            $txt = "<span style='color:red'>Open</span>";
        }

        if( $type == 2 ) 
        {
            $txt = "<span style='color:green'>Answered</span>";
        }

        if( $type == 3 ) 
        {
            $txt = "<span style='color:blue'>In Progress</span>";
        }

        if( $type == 4 ) 
        {
            $txt = "<span style='color:green'>On Hold</span>";
        }

        if( $type == 5 ) 
        {
            $txt = "<span style='color:#ccc'>Close</span>";
        }

        if( $type == 6 ) 
        {
            $txt = "<span style='color:orangered'>Customer Reply</span>";
        }

        return $txt;
    }

    public function isMyTT($tid)
    {
        $id = $this->session->userdata("id");
        $rs = $this->session->userdata("user_type");
        if( $rs == 1 ) 
        {
            $resQl = "sender ='" . $id . "'";
        }
        else
        {
            $resQl = "(sender='" . $id . "' OR rs" . $rs . "='" . $id . "')";
        }

        $q = $this->db->select("id")->from("support_ticket")->where($resQl)->limit(1);
        $q->where("id", $tid);
        $r = $q->get();
        return $r->num_rows();
    }

    public function getTicket($id)
    {
        $q = $this->db->select("*")->from("support_ticket")->where("id", $id)->limit(1);
        $r = $q->get();
        return $r->row();
    }

    public function getReplys($id)
    {
        $q = $this->db->select("*")->from("support_reply")->where("tid", $id);
        $r = $q->get();
        return $r->result();
    }

    public function safe_b64encode($string)
    {
        $data = base64_encode($string);
        $data = str_replace(array( "+", "/", "=" ), array( "-", "_", "" ), $data);
        return $data;
    }

    public function safe_b64decode($string)
    {
        $data = str_replace(array( "-", "_" ), array( "+", "/" ), $string);
        $mod4 = strlen($data) % 4;
        if( $mod4 ) 
        {
            $data .= substr("====", $mod4);
        }

        return base64_decode($data);
    }

    public function encode($value, $skey)
    {
        if( !$value ) 
        {
            return false;
        }

        $text = $value;
        $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $skey, $text, MCRYPT_MODE_ECB, $iv);
        return trim($this->safe_b64encode($crypttext));
    }

    public function decode($value, $skey)
    {
        if( !$value ) 
        {
            return false;
        }

        $crypttext = $this->safe_b64decode($value);
        $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $skey, $crypttext, MCRYPT_MODE_ECB, $iv);
        return trim($decrypttext);
    }

    public function clearData()
    {
        $sQ = $this->db->query("SELECT count(*) as tot FROM ci_query");
        $sR = $sQ->row();
        if( 500 < $sR->tot ) 
        {
            $this->db->query("TRUNCATE TABLE ci_query");
        }

    }

    public function getReseller($type)
    {
        $q = $this->db->select("id,username")->from("resellers")->where(array( "status !=" => 3, "user_type" => $type ));
        return $q->get()->result();
    }

    public function getAdminResellers($type)
    {
        $q = $this->db->select("id,username")->from("resellers")->where(array( "status !=" => 3, "user_type" => $type, "parent" => "-1" ));
        return $q->get()->result();
    }

    public function route($modem, $api)
    {
        $route = "---";
        if( $api != "-1" ) 
        {
            $q = $this->db->query("SELECT title FROM flexi_apis WHERE id='" . $api . "' LIMIT 1");
            $r = $q->row();
            $route = $r->title . "-(API)";
        }
        else
        {
            if( $modem != "-1" ) 
            {
                $route = "Modem-" . $modem;
            }

        }

        return $route;
    }

    public function fAction($id, $status, $tbl)
    {
        $url = base_url() . "admin";
        if( $status < 3 || 4 < $status ) 
        {
            $links = "<a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/confirm/" . $id . "/" . $tbl . "', 450, 300); return false;\" title=\"Confirm\" class=\"btn btn-success btn-xs\"><span class=\"glyphicon glyphicon-ok\"></span></a>";
            $links .= " <a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/resend/" . $id . "/" . $tbl . "', 450, 300); return false;\" title=\"Resend\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-repeat\"></span></a>";
            $links .= " <a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/cancel/" . $id . "/" . $tbl . "', 450, 300); return false;\" title=\"Cancel & Refund\" class=\"btn btn-danger btn-xs\"><span class=\"glyphicon glyphicon-remove\"></span></a>";
            $links .= " <a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/details/" . $id . "/" . $tbl . "', 650, 500); return false;\" title=\"View Details\" class=\"btn btn-info btn-xs\"><span class=\"glyphicon glyphicon-info-sign\"></span></a>";
        }
        else
        {
            $links = "<a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/details/" . $id . "', 650, 465); return false;\" title=\"View Details\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-info-sign\"></span> View Details</a>";
        }

        return $links;
    }

    public function bAction($id, $status)
    {
        $url = base_url() . "admin";
        if( $status < 3 || 4 < $status ) 
        {
            $links = "<a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/bill_confirm/" . $id . "', 450, 365); return false;\" title=\"Confirm\" class=\"btn btn-success btn-xs\"><span class=\"glyphicon glyphicon-ok\"></span></a>";
            $links .= " <a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/bill_status/" . $id . "', 450, 300); return false;\" title=\"Change Status\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-repeat\"></span></a>";
            $links .= " <a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/bill_cancel/" . $id . "', 450, 300); return false;\" title=\"Cancel & Refund\" class=\"btn btn-danger btn-xs\"><span class=\"glyphicon glyphicon-remove\"></span></a>";
            $links .= " <a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/bill_details/" . $id . "', 650, 500); return false;\" title=\"View Details\" class=\"btn btn-info btn-xs\"><span class=\"glyphicon glyphicon-info-sign\"></span></a>";
        }
        else
        {
            $links = "<a href='javascript:void(0)' onclick=\"javascript:PopUp('" . $url . "/bill_details/" . $id . "', 650, 500); return false;\" title=\"View Details\" class=\"btn btn-primary btn-xs\"><span class=\"glyphicon glyphicon-info-sign\"></span> View Details</a>";
        }

        return $links;
    }

    public function getModems()
    {
        $q = $this->db->query("SELECT id FROM flexi_modem");
        return $q->result();
    }

    public function getSims()
    {
        $q = $this->db->query("SELECT id,number FROM flexi_sim");
        return $q->result();
    }

    public function getSIM($id)
    {
        if( $id != "-1" ) 
        {
            $q = $this->db->query("SELECT number FROM flexi_sim WHERE id='" . $id . "'");
            return $q->row()->number;
        }

        return "-";
    }

    public function getApis()
    {
        $q = $this->db->query("SELECT id,title FROM flexi_apis");
        return $q->result();
    }

    public function myDomain($uid)
    {
        $domain = NULL;
        $q = $this->db->select("domain")->from("subadmin")->where("uid", $uid)->limit(1);
        $r = $q->get()->row();
        $domain = $r->domain;
        return $domain;
    }

    public function addedBy($id, $admin)
    {
        if( $admin == 1 ) 
        {
            $aRow = $this->lib->getAdmin($id);
            $addedby = $aRow->fullname . " (Super Admin)";
        }
        else
        {
            $q = $this->db->query("SELECT fullname FROM resellers WHERE id=" . $id);
            $r = $q->row();
            $addedby = $r->fullname;
        }

        return $addedby;
    }

    public function mStatus($send)
    {
        if( $send == 0 ) 
        {
            $status = "<span style='color:#FF9500'>Not Connected</span>";
        }

        if( $send == 1 ) 
        {
            $status = "<span style='color:green'>Connected</span>";
        }

        return $status;
    }

    public function apiBalance($id)
    {
        $bal = "N/A";
        $q = $this->db->select("*")->from("flexi_apis")->where("id", $id)->where("status", 1)->LIMIT(1);
        $d = $q->get();
        $r = $d->row();
        $url = $r->url . "/getBalance";
        $get = array( "user" => $r->user, "key" => $r->pass );
        $x = $this->lib->curl_get($url, $get);
        $bal = intval($x);
        return $bal;
    }

    public function sluggify($url)
    {
        $url = strtolower($url);
        $url = strip_tags($url);
        $url = stripslashes($url);
        $url = html_entity_decode($url);
        $url = str_replace("'", "", $url);
        $match = "/[^a-z0-9]+/";
        $replace = "-";
        $url = preg_replace($match, $replace, $url);
        $url = trim($url, "-");
        return $url;
    }

    public function adminBalance()
    {
        $usd = 0;
        $query = $this->db->query("SELECT sum(balance) as balance, currency FROM flexi_modem WHERE busy='1' AND operator NOT LIKE '%sms%' GROUP BY currency");
        foreach( $query->result() as $r ) 
        {
            $rate = $this->lib->baseRate($r->currency);
            $usd += $r->balance / $rate;
        }
        return $this->lib->adminAmount($usd);
    }

    public function getBal($id)
    {
        $query = $this->db->query("SELECT balance FROM resellers WHERE id='" . $id . "' LIMIT 1");
        $row = $query->row();
        if( $query->num_rows() == 1 ) 
        {
            return $row->balance;
        }

        return "0.00";
    }

    public function islevel5()
    {
        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $q = $this->db->select("*")->from("subadmin")->where("domain", $domain)->limit(1);
        $query = $q->get();
        if( $query->num_rows() == 1 ) 
        {
            $r = $query->row();
            return $r->uid;
        }

        return false;
    }

    public function getBrand($str)
    {
        $var = $this->lib->islevel5();
        if( $var == false ) 
        {
            $q = $this->db->select("value");
            $q->from("config");
            $q->where("setting", $str);
            $q->limit(1);
            $tmp = $q->get()->result();
            return $tmp[0]->value;
        }

        $q = $this->db->select((string) $str . " value")->from("subadmin")->where("uid", $var);
        $tmp = $q->get()->result();
        return $tmp[0]->value;
    }

    public function optTitle($opt)
    {
        if( $opt == "grameenphone" ) 
        {
            $title = "GrameenPhone";
        }

        if( $opt == "robi" ) 
        {
            $title = "Robi";
        }

        if( $opt == "banglalink" ) 
        {
            $title = "Banglalink";
        }

        if( $opt == "airtel" ) 
        {
            $title = "Airtel";
        }

        if( $opt == "citycell" ) 
        {
            $title = "Citycell";
        }

        if( $opt == "teletalk" ) 
        {
            $title = "Teletalk";
        }

        if( $opt == "bkash" ) 
        {
            $title = "bKash";
        }

        if( $opt == "dbbl" ) 
        {
            $title = "DBBL";
        }

        return $title;
    }

    public function mail($param = NULL)
    {
        require_once(APPPATH . "/third_party/phpmail/class.phpmailer.php");
        return new PHPMailer($param);
    }

    public function getPermision($id)
    {
        $q = $this->db->query("SELECT permision FROM admin WHERE id='" . $id . "' LIMIT 1");
        $r = $q->row();
        $val = explode(";", $r->permision);
        return $val;
    }

    public function view($page, $access, $data = NULL)
    {
        $id = $this->session->userdata("id");
        $super = $this->session->userdata("type");
        $role = $this->lib->getPermision($id);
        if( $super == "-1" ) 
        {
            $this->load->view($page, $data);
        }
        else
        {
            if( in_array($access, $role) ) 
            {
                $this->load->view($page, $data);
            }
            else
            {
                $this->load->view("admin/denied");
            }

        }

    }

    public function isAccess($per)
    {
        $super = $this->session->userdata("type");
        if( $super == "-1" ) 
        {
            return true;
        }

        $id = $this->session->userdata("id");
        $role = $this->lib->getPermision($id);
        if( in_array($per, $role) ) 
        {
            return true;
        }

        return false;
    }

    public function lastdays($days)
    {
        $output = array(  );
        $month = date("m");
        $day = date("d");
        $year = date("Y");
        $i = 0;
        while( $i <= $days ) 
        {
            $output[] = date("Y-m-d", mktime(0, 0, 0, $month, $day - $i, $year));
            $i++;
        }
        return $output;
    }

    public function isBalLimit($amount, $type)
    {
        $bal_limit = $this->lib->getSet("balance_limit");
        $id = $this->session->userdata("id");
        $lbl = $this->session->userdata("user_type");
        $child = $lbl - 1;
        if( $bal_limit == 1 && $type == 1 ) 
        {
            $myBal = $this->lib->myBalance();
            $aQ = $this->db->query("SELECT sum(balance) total FROM resellers WHERE parent='" . $id . "' AND user_type='" . $child . "' AND status!=3");
            $aR = $aQ->row();
            $resBal = $aR->total;
            $available = $myBal - $resBal;
            if( $amount <= $available ) 
            {
                return true;
            }

        }
        else
        {
            return true;
        }

    }

    public function isBalLimit_offline($id, $rstype, $amount, $type)
    {
        $bal_limit = $this->lib->getSet("balance_limit");
        $id = $id;
        $lbl = $rstype;
        $child = $lbl - 1;
        if( $bal_limit == 1 && $type == 1 ) 
        {
            $mQl = $this->db->query("SELECT balance FROM resellers WHERE id='" . $id . "' AND user_type='" . $lbl . "' LIMIT 1");
            $mRow = $mQl->row();
            $myBal = $mRow->balance;
            $aQ = $this->db->query("SELECT sum(balance) total FROM resellers WHERE parent='" . $id . "' AND user_type='" . $child . "' AND status!=3");
            $aR = $aQ->row();
            $resBal = $aR->total;
            $available = $myBal - $resBal;
            if( $amount <= $available ) 
            {
                return true;
            }

        }
        else
        {
            return true;
        }

    }

    public function gwList()
    {
        $q = $this->db->query("SELECT id,title FROM gateways");
        return $q->result();
    }

    public function gwRow($id)
    {
        $q = $this->db->query("SELECT * FROM gateways WHERE id='" . $id . "' LIMIT 1");
        if( $q->num_rows() == 0 ) 
        {
            return false;
        }

        return $q->row();
    }

    public function gwTitle($id)
    {
        $q = $this->db->query("SELECT title FROM gateways WHERE id='" . $id . "' LIMIT 1");
        $r = $q->row();
        return $r->title;
    }

    public function gwCurrency($id)
    {
        $q = $this->db->query("SELECT currency FROM gateways WHERE id='" . $id . "' LIMIT 1");
        $r = $q->row();
        return $r->currency;
    }

    public function gwListLive()
    {
        $q = $this->db->query("SELECT id,title FROM gateways WHERE enable='1'");
        return $q->result();
    }

    public function getTable($from, $to)
    {
        $sk = 0;
        $current = date("mY");
        $tbl_from = date("mY", strtotime($from));
        $tbl_to = date("mY", strtotime($to));
        if( $tbl_from == $tbl_to ) 
        {
            $tmptbl = "requests_" . $tbl_from;
            $database = $this->db->database;
            $tQ = $this->db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='" . $tmptbl . "' LIMIT 1");
            $yes = $tQ->num_rows();
            if( $yes == 0 ) 
            {
                $table = "request_view";
            }
            else
            {
                $table = $tmptbl;
            }

        }
        else
        {
            $table = "request_view";
        }

        return $table;
    }

    public function req_tbl()
    {
        $table = "requests_" . date("mY");
        return $table;
    }

    public function get_months($date1, $date2)
    {
        if( strlen($date1) && strlen($date2) ) 
        {
            $date1 = date("Y-m", strtotime($date1));
            $date2 = date("Y-m", strtotime($date2));
            if( $date1 < $date2 ) 
            {
                $past = $date1;
                $future = $date2;
            }
            else
            {
                $past = $date2;
                $future = $date1;
            }

            $months = array(  );
            $i = $past;
            while( $past <= $future ) 
            {
                $timestamp = strtotime($past . "-1");
                $months[] = date("mY", $timestamp);
                $past = date("Y-m", strtotime("+1 month", $timestamp));
                $i++;
            }
            $tables = array(  );
            $database = $this->db->database;
            foreach( $months as $month ) 
            {
                $sQ = $this->db->query("SELECT count(*) tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='requests_" . $month . "'");
                $sR = $sQ->row();
                if( $sR->tbl == 1 ) 
                {
                    $tables[] = $month;
                }

            }
            return $tables;
        }
        else
        {
            $tbls = array(  );
            $database = $this->db->database;
            $query = $this->db->query("SELECT table_name tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name LIKE 'requests_%' ORDER BY CREATE_TIME DESC");
            foreach( $query->result() as $row ) 
            {
                $tbls[] = str_replace("requests_", "", $row->tbl);
            }
            return $tbls;
        }

    }

    public function tblList()
    {
        $tbls = array(  );
        $database = $this->db->database;
        $query = $this->db->query("SELECT table_name tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name LIKE 'requests_%' ORDER BY CREATE_TIME DESC");
        foreach( $query->result() as $row ) 
        {
            $tbls[] = str_replace("requests_", "", $row->tbl);
        }
        return $tbls;
    }

    public function dbtbl()
    {
        $prev_month = date("mY", strtotime("-1 month"));
        $month = date("mY");
        $new_tbl = "requests_" . $month;
        $prv_tbl = "requests_" . $prev_month;
        $database = $this->db->database;
        $sQ = $this->db->query("SELECT count(*) tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='" . $new_tbl . "'");
        $rQ = $sQ->row();
        if( $rQ->tbl == 0 ) 
        {
            $prv = $this->db->query("SELECT count(*) tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='" . $prv_tbl . "'")->row();
            if( $prv->tbl == 0 ) 
            {
                $prv_tbl = "requestmp";
            }

            $this->db->query("CREATE TABLE IF NOT EXISTS " . $new_tbl . " LIKE " . $prv_tbl);
            $pQ = $this->db->query("SELECT id,cid,oid,sender,receiver,amount,type,service_id,cost,cost2,cost3,cost4,cost5,currency,bal,bal2,bal3,bal4,bal5,rs2,rs3,rs4,rs5,status,transactionid,modem,sim,api,confirmed,token,ip,req_time,last_update,photoid,sendername,receivername,photofile FROM " . $prv_tbl . " WHERE status<3");
            if( 0 < $pQ->num_rows() ) 
            {
                foreach( $pQ->result() as $pR ) 
                {
                    $id = $pR->id;
                    $this->db->insert($new_tbl, $pR);
                    $newid = $this->db->insert_id();
                    if( strlen($newid) && $newid == $id ) 
                    {
                        $this->db->query("DELETE FROM " . $prv_tbl . " WHERE id='" . $id . "'");
                    }

                }
            }

            $aQ = $this->db->query("SELECT AUTO_INCREMENT last_id FROM information_schema.tables WHERE table_name='" . $prv_tbl . "' AND table_schema='" . $database . "'");
            $aR = $aQ->row();
            $this->db->query("ALTER TABLE " . $new_tbl . " AUTO_INCREMENT = " . $aR->last_id);
            $clm = "id,cid,oid,sender,receiver,amount,type,service_id,cost,cost2,cost3,cost4,cost5,currency,bal,bal2,bal3,bal4,bal5,rs2,rs3,rs4,rs5,status,transactionid,modem,sim,api,confirmed,token,ip,req_time,last_update,photoid,sendername,receivername,photofile";
            $tQ = $this->db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name LIKE 'requests_%'");
            $sql = NULL;
            foreach( $tQ->result() as $row ) 
            {
                $month = str_replace("requests_", "", $row->table_name);
                $sql .= "UNION ALL SELECT " . $clm . ", '" . $month . "' tbl FROM " . $row->table_name . " ";
            }
            $sql = substr($sql, 10);
            $this->db->query("DROP VIEW IF EXISTS request_view");
            $this->db->query("CREATE VIEW `request_view` AS " . $sql);
        }

        $this->db->query("ALTER TABLE `resellers` CHANGE `status` `status` INT(11) NULL DEFAULT '0'");
        return NULL;
    }

    public function curl_post($url, $val)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $val);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    public function notifyLogin($row, $res = 0)
    {
        $ip_addr = $this->lib->RemoteIP();
        $time = date("d F Y h:i a");
        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $brandname = $this->lib->getSet("brandname");
        $otp_route = $this->lib->getSet("otp_route");
        if( $res == 0 ) 
        {
            $msg = (string) $brandname . " portal login attempt was successful. Username: " . $row->username . ", IP: " . $ip_addr . ", Time: " . $time;
        }

        if( $res == 1 ) 
        {
            $msg = "Your last login attempt as successfull for " . $brandname . ". Username: " . $row->username . ", IP: " . $ip_addr . ", Time: " . $time;
        }

        if( $res == 0 && strlen($row->mobile) ) 
        {
            $api = $this->lib->smsApi();
            if( $otp_route == 1 && $api->found == 1 ) 
            {
                $msg = urlencode($msg);
                $senderid = substr($brandname, 0, 11);
                $senderid = urlencode($senderid);
                $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
                $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $row->mobile, (string) $msg, "0" );
                $link = str_replace($uData, $sData, $api->url);
                $fdata = array(  );
                $ret = $this->lib->curl_get($link, $fdata);
            }
            else
            {
                $outbox = array( "rid" => "-1", "receiver" => $row->mobile, "message" => $msg, "status" => 0 );
                $this->db->insert("outbox", $outbox);
            }

        }

        if( strlen($row->email) ) 
        {
            $mail = $this->lib->mail();
            $mail->AddReplyTo("no-reply@" . $domain, $brandname);
            $mail->SetFrom("no-reply@" . $domain, $brandname);
            $mail->AddAddress($row->email, $row->fullname);
            $mail->Subject = (string) $brandname . " login notification";
            $mail->MsgHTML(urldecode($msg));
            $mail->Send();
        }

    }

    public function mc_encrypt($encrypt)
    {
        $key = "fc20faf446aa0197252220c677fdb4b8acb61142fcd55f4b5c32611b87cd923e";
        $encrypt = serialize($encrypt);
        $iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC), MCRYPT_DEV_URANDOM);
        $key = pack("H*", $key);
        $mac = hash_hmac("sha256", $encrypt, substr(bin2hex($key), -32));
        $passcrypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $encrypt . $mac, MCRYPT_MODE_CBC, $iv);
        $encoded = base64_encode($passcrypt) . "|" . base64_encode($iv);
        return $encoded;
    }

    public function mc_decrypt($decrypt)
    {
        $key = "fc20faf446aa0197252220c677fdb4b8acb61142fcd55f4b5c32611b87cd923e";
        $decrypt = explode("|", $decrypt . "|");
        $decoded = base64_decode($decrypt[0]);
        $iv = base64_decode($decrypt[1]);
        if( strlen($iv) !== mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC) ) 
        {
            return false;
        }

        $key = pack("H*", $key);
        $decrypted = trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $decoded, MCRYPT_MODE_CBC, $iv));
        $mac = substr($decrypted, -64);
        $decrypted = substr($decrypted, 0, -64);
        $calcmac = hash_hmac("sha256", $decrypted, substr(bin2hex($key), -32));
        if( $calcmac !== $mac ) 
        {
            return false;
        }

        $decrypted = unserialize($decrypted);
        return $decrypted;
    }

    public function laps($start, $end = "")
    {
        if( !strlen($end) ) 
        {
            $end = date("Y-m-d H:i:s");
        }

        $start = date_create($start);
        $end = date_create($end);
        $diff = date_diff($end, $start);
        $min = $diff->y * 525949;
        $min += $diff->m * 43829.1;
        $min += $diff->d * 525949;
        $min += $diff->h * 60;
        $min += $diff->s * Infinity;
        $min += $diff->i;
        return round($min);
    }

    public function topParent($id)
    {
        $row = $this->db->select("rs2,rs3,rs4,rs5,user_type")->from("resellers")->where("id", $id)->limit(1)->get()->row();
        $parent = "-1";
        $l = 0;
        if( $row->rs2 != "-1" ) 
        {
            $parent = $row->rs2;
            $l = 2;
        }

        if( $row->rs3 != "-1" ) 
        {
            $parent = $row->rs3;
            $l = 3;
        }

        if( $row->rs4 != "-1" ) 
        {
            $parent = $row->rs4;
            $l = 4;
        }

        if( $row->rs5 != "-1" ) 
        {
            $parent = $row->rs5;
            $l = 5;
        }

        if( $parent == "-1" ) 
        {
            $parent = $id;
            $l = $row->user_type;
        }

        $top = new stdClass();
        $top->id = $parent;
        $top->level = $l;
        return $top;
    }

    public function dailyLimit($id, $amount)
    {
        $table = $this->lib->req_tbl();
        $res = $this->lib->topParent($id);
        $this->session->set_userdata("topRes", "-1");
        $day = $this->db->select("duse,dlimit")->from("resellers")->where("id", $res->id)->limit(1)->get()->row();
        $duse = $day->duse;
        if( 0 < $day->dlimit ) 
        {
            $this->session->set_userdata("topRes", $res->id);
            if( 1 < $res->level ) 
            {
                $whr = "(sender='" . $res->id . "' OR rs" . $res->level . "='" . $res->id . "')";
            }
            else
            {
                $whr = array( "sender" => $id );
            }

            $r = $this->db->select("count(*) c")->from($table)->where($whr)->where("date(req_time)", date("Y-m-d"))->limit(1)->get()->row();
            if( $r->c == 0 ) 
            {
                $this->db->query("UPDATE resellers SET duse='0' WHERE id='" . $res->id . "' LIMIT 1");
                $duse = 0;
            }

            $total = $duse + $amount;
            if( $day->dlimit < $total ) 
            {
                return false;
            }

            return true;
        }

        return true;
    }

    public function countryName($id)
    {
        $q = $this->db->select("name")->from("countries")->where("id", $id)->limit(1)->get()->row();
        return $q->name;
    }

    public function countryByIso($iso)
    {
        $q = $this->db->select("name")->from("countries")->where("iso_alpha2", $iso)->limit(1)->get()->row();
        return $q->name;
    }

    public function exRate($id)
    {
        $q = $this->db->select("exchange_rate")->from("currency")->where("currency_id", $id)->limit(1)->get()->row();
        return $q->exchange_rate;
    }

    public function baseRate($id)
    {
        $q = $this->db->select("base_rate")->from("currency")->where("currency_id", $id)->limit(1)->get()->row();
        return $q->base_rate;
    }

    public function myCode()
    {
        $cid = $this->session->userdata("currency");
        $q = $this->db->select("currency_code")->from("currency")->where("currency_id", $cid)->limit(1)->get();
        $r = $q->row();
        return $r->currency_code;
    }

    public function cCode($id)
    {
        $q = $this->db->select("currency_code")->from("currency")->where("currency_id", $id)->limit(1)->get();
        $r = $q->row();
        $code = $r->currency_code;
        return $code;
    }

    public function cFullText($id)
    {
        $q = $this->db->select("currency_code, currency_name")->from("currency")->where("currency_id", $id)->limit(1)->get();
        $r = $q->row();
        return $r->currency_name . " (" . $r->currency_code . ")";
    }

    public function getDefaultCountry()
    {
        $r = $this->db->select("id")->from("countries")->where("status !=", 0)->order_by("status", "desc")->limit(1)->get()->row();
        return $r->id;
    }

    public function operatorName($code)
    {
        $q = $this->db->select("title")->from("operatorlist")->where("code", $code)->limit(1)->get()->row();
        return $q->title;
    }

    public function optLength($id)
    {
        $length = 13;
        $q = $this->db->select("length")->from("operatorlist")->where("code", $id)->limit(1)->get();
        if( $q->num_rows() == 1 ) 
        {
            $r = $q->row();
            $length = $r->length;
        }

        return $length;
    }

    public function countryLength($id)
    {
        $length = 13;
        $q = $this->db->select("length")->from("countries")->where("id", $id)->limit(1)->get();
        if( $q->num_rows() == 1 ) 
        {
            $r = $q->row();
            $length = $r->length;
        }

        return $length;
    }

    public function ePinGen($len)
    {
        $alphabet = "0123456789";
        $pass = array(  );
        $alphaLength = strlen($alphabet) - 1;
        $i = 0;
        while( $i < $len ) 
        {
            $n = mt_rand(1, $alphaLength);
            $pass[] = $alphabet[$n];
            $i++;
        }
        return implode($pass);
    }

    public function lotTitle($id)
    {
        $r = $this->db->query("SELECT title FROM epin_lots WHERE id='" . $id . "' LIMIT 1")->row();
        return $r->title;
    }

    public function isMask($id = "")
    {
        if( !strlen($id) ) 
        {
            $id = $this->session->userdata("id");
        }

        $r = $this->db->select("parent,rs2,rs3,rs4,rs5,mask")->from("resellers")->where("id", $id)->get()->row();
        if( $r->rs5 != "-1" ) 
        {
            $m = $this->db->select("mask")->from("resellers")->where("id", $r->rs5)->get()->row();
            $mask = $m->mask;
        }
        else
        {
            if( $r->rs4 != "-1" ) 
            {
                $m = $this->db->select("mask")->from("resellers")->where("id", $r->rs4)->get()->row();
                $mask = $m->mask;
            }
            else
            {
                if( $r->rs3 != "-1" ) 
                {
                    $m = $this->db->select("mask")->from("resellers")->where("id", $r->rs3)->get()->row();
                    $mask = $m->mask;
                }
                else
                {
                    if( $r->rs2 != "-1" ) 
                    {
                        $m = $this->db->select("mask")->from("resellers")->where("id", $r->rs2)->get()->row();
                        $mask = $m->mask;
                    }
                    else
                    {
                        $mask = $r->mask;
                    }

                }

            }

        }

        return $mask;
    }

    public function passKey()
    {
        $this->load->config("status");
        $key = $this->config->item("data");
        return $this->mc_decrypt($key);
    }

    public function securityCheck()
    {
        $warn = array(  );
        $val = $this->lib->getSet("complex_pass");
        if( $val == 0 ) 
        {
            $warn[] = array( "danger", "Please use complex password for reseller. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $val = $this->lib->getSet("pin_interval");
        if( 30 < $val ) 
        {
            $warn[] = array( "danger", "Reseller PIN Change interval " . $val . " days is too short. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $val = $this->lib->getSet("pin_len");
        if( $val < 6 ) 
        {
            $warn[] = array( "warning", "PIN length " . $val . " is too short. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $val = $this->lib->getSet("reseller_otp");
        if( $val == 0 ) 
        {
            $warn[] = array( "danger", "Please enable reseller login OTP for high security. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $val = $this->lib->getSet("pass_interval");
        if( $val == 0 ) 
        {
            $warn[] = array( "error", "Reseller password change interval " . $val . " days is too short. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $val = $this->lib->getSet("daylimit");
        if( $val == 0 ) 
        {
            $warn[] = array( "danger", "Please set daily reseller usage limit to protect uncertain requests. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $val = $this->lib->getSet("ssl");
        if( $val == 0 ) 
        {
            $warn[] = array( "danger", "Please enable install & enable SSL certification for data security & safety. Click <a href=\"admin/security\">Server &raquo; Security</a> to update" );
        }

        $otp = $this->lib->getSet("reseller_otp");
        if( $otp == 1 ) 
        {
            $empty = $this->db->query("SELECT count(*) c FROM resellers WHERE (email='' OR mobile ='')")->row();
            if( 0 < $empty->c ) 
            {
                $warn[] = array( "warning", $empty->c . " resellers dose not have mobile number or email for otp verification. Click <a href=\"admin/resellers/all\">Resellers</a> to update" );
            }

        }

        $srv = $this->db->query("SELECT title,risk_amount FROM services WHERE enable=1 AND type > 2 AND type!=16 AND risk_amount='0'")->result();
        foreach( $srv as $sr ) 
        {
            $warn[] = array( "danger", "Please update safe amount for " . $sr->title . " to protect high value request. Click <a href=\"admin/modules\">Server &raquo; Service Module</a> to update" );
        }
        $aQ = $this->db->query("SELECT count(*) c FROM admin WHERE (username='Administrator' OR username='Admin')")->row();
        if( 0 < $aQ->c ) 
        {
            $warn[] = array( "danger", "Portal username as Administrator or Admin is easy to guess. Click <a href=\"admin/profile\">Admin &raquo; Profile </a> to change username" );
        }

        return $warn;
    }

    public function isCaptcha($login)
    {
        $key = $this->lib->getSet("gcaptcha_key");
        $sec = $this->lib->getSet("gcaptcha_secrete");
        if( strlen($key) && strlen($sec) ) 
        {
            if( $login == "admin" ) 
            {
                $captcha = $this->lib->getSet("admin_capcha");
                if( $captcha == 0 ) 
                {
                    $captcha = $this->session->userdata("admin_capcha");
                }

            }
            else
            {
                if( $login == "reseller" ) 
                {
                    $captcha = $this->lib->getSet("login_capcha");
                    if( $captcha == 0 ) 
                    {
                        $captcha = $this->session->userdata("login_capcha");
                    }

                }

            }

        }
        else
        {
            $captcha = 0;
        }

        return $captcha;
    }

    public function totp()
    {
        require_once(APPPATH . "/third_party/Authenticator.php");
        return new Authenticator();
    }

    public function RemoteIP()
    {
        $ip = (isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? ($ip = $_SERVER["HTTP_CF_CONNECTING_IP"]) : "");
        if( !strlen($ip) ) 
        {
            $ip = $_SERVER["REMOTE_ADDR"];
        }

        return $ip;
    }

    public function otpText($otp)
    {
        if( $otp == 1 ) 
        {
            $txt = "OTP Code";
        }

        if( $otp == 2 ) 
        {
            $txt = "SMS Code";
        }

        if( $otp == 3 ) 
        {
            $txt = "PIN";
        }

        return $txt;
    }

    public function sendOtp()
    {
        $send = array(  );
        $uid = $this->session->userdata("id");
        $otp_route = $this->lib->getSet("otp_route");
        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $senderid = $this->lib->getSet("brandname");
        $brandname = $this->lib->getSet("brandname");
        $newCode = $this->lib->random_numbers(6);
        $this->db->where("id", $uid)->update("resellers", array( "sms_code" => password_hash($newCode . $this->lib->passKey(), PASSWORD_BCRYPT) ));
        $this->session->set_userdata("verify_session", time());
        $uRow = $this->db->get_where("resellers", array( "id" => $uid ))->row();
        if( strlen($uRow->mobile) ) 
        {
            $send[] = "mobile";
            $api = $this->lib->smsApi();
            if( $otp_route == 1 && $api->found == 1 ) 
            {
                $msg = "Use " . $newCode . " as one time password for login " . $domain;
                $msg = urlencode($msg);
                $senderid = substr($senderid, 0, 11);
                $senderid = urlencode($senderid);
                $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
                $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $uRow->mobile, (string) $msg, "0" );
                $link = str_replace($uData, $sData, $api->url);
                $fdata = array(  );
                $this->lib->curl_get($link, $fdata);
                $route = $api->id;
            }
            else
            {
                $outbox = array( "rid" => "-1", "receiver" => $uRow->mobile, "message" => "Use " . $newCode . " as one time password for login " . $domain, "status" => 0 );
                $this->db->insert("outbox", $outbox);
                $route = "-1";
            }

            $otp_cost = $this->lib->getSet("otp_cost");
            if( 0 < $otp_cost ) 
            {
                $cost["main"] = $otp_cost;
                $cost["rs5"] = $otp_cost;
                $cost["rs4"] = $otp_cost;
                $cost["rs3"] = $otp_cost;
                $cost["rs2"] = $otp_cost;
                $this->lib->dedBal_all($uRow->id, $uRow->user_type, $cost);
                $smsLogs = array( "sender" => $uRow->id, "sender_id" => $senderid, "receiver" => $uRow->mobile, "sms" => "Reseller login OTP was sent via sms", "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => $cost["main"], "cost5" => $cost["rs5"], "cost4" => $cost["rs4"], "cost3" => $cost["rs3"], "cost2" => $cost["rs2"], "bal" => $this->lib->getBal($uRow->id), "bal5" => $this->lib->getBal($uRow->rs5), "bal4" => $this->lib->getBal($uRow->rs4), "bal3" => $this->lib->getBal($uRow->rs3), "bal2" => $this->lib->getBal($uRow->rs2), "api" => $route, "status" => 4, "send_time" => date("Y-m-d H:i:s"), "ip" => $this->lib->RemoteIP() );
                $this->db->insert("sms_req", $smsLogs);
            }

        }

        if( count($send) == 0 ) 
        {
            redirect("login?sk=identity");
        }
        else
        {
            $this->session->set_userdata("otp_sent", 1);
        }

    }

    public function myCurrency()
    {
        return $base = $this->lib->getSet("base_currency");
    }

    public function httpPost($url, $params)
    {
        $postData = "";
        foreach( $params as $k => $v ) 
        {
            $postData .= $k . "=" . $v . "&";
        }
        $postData = rtrim($postData, "&");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }

    public function globalTariff($rid, $type = "id")
    {
        if( $type == "id" ) 
        {
            $q = $this->db->get_where("rates_global", array( "rid" => $rid ));
        }

        if( $type == "username" ) 
        {
            $rid = $this->db->get_where("resellers", array( "username" => $rid ))->row()->id;
            $q = $this->db->get_where("rates_global", array( "rid" => $rid ));
        }

        if( $q->num_rows() == 0 ) 
        {
            $ins = array( "rid" => $rid, "comission" => $this->lib->globalSet("default_comission"), "charge" => $this->lib->globalSet("default_charge") );
            $this->db->insert("rates_global", $ins);
        }
        else
        {
            $r = $q->row();
            $ins = array( "rid" => $r->rid, "comission" => $r->comission, "charge" => $r->charge );
        }

        return (object) $ins;
    }

    public function listCurrency()
    {
        return $this->db->get_where("currency", array( "status" => 1 ))->result();
    }

    public function getIntPack($id)
    {
        return $this->db->get_where("global_package", array( "id" => $id ))->row();
    }

    public function viewAmount($usd, $cid = "", $c = true)
    {
        if( !strlen($cid) ) 
        {
            $cid = $this->session->userdata("currency");
        }

        $cR = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
        if( $c == true ) 
        {
            return $actual = number_format($usd * $cR->base_rate, 4, ".", "")
                . " " . $cR->currency_code;
        }

        return $actual = number_format($usd * $cR->base_rate, 4, ".", ",");
    }

    public function adminAmount($usd, $c = true)
    {
        $cid = $this->lib->getSet("base_currency");
        $cR = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
        if( $c == true ) 
        {
            return $actual = number_format($usd * $cR->base_rate, 4, ".", "") . " " . $cR->currency_code;
        }

        return $actual = number_format($usd * $cR->base_rate, 4, ".", "");
    }

    public function showRate($amount, $cid)
    {
        $base = $this->lib->getSet("base_currency");
        if( $base != $cid ) 
        {
            $cR = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
            return $actual = number_format($amount * $cR->base_rate, 4);
        }

        return number_format($amount, 4);
    }

    public function rsAmount($usd)
    {
        $cid = $this->session->userdata("currency");
        $cR = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
        return $actual = number_format($usd * $cR->base_rate, 4, ".", "") . " " . $cR->currency_code;
    }

    public function rsRate($amount)
    {
        $cid = $this->session->userdata("currency");
        $cR = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
        return $actual = number_format($amount * $cR->base_rate, 4);
    }

    public function gRate($cost)
    {
        $rid = $this->session->userdata("id");
        $cid = $this->session->userdata("currency");
        $g = $this->lib->globalTariff($rid);
        $commision = 0;
        $charge = 0;
        if( 0 < $g->comission ) 
        {
            $commision = ($cost * $g->comission) / 100;
        }

        if( 0 < $g->charge ) 
        {
            $charge = ($cost * $g->charge) / 100;
        }

        $cost = $cost - $commision + $charge;
        return round($cost, 4);
    }

    public function convertUSD($val, $cid)
    {
        $cRow = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
        return $rate = $val / $cRow->base_rate;
    }

    public function bankName($id)
    {
        return $this->db->select("bankname")->from("banklist")->where("id", $id)->get()->row()->bankname;
    }

    public function branchName($id)
    {
        return $this->db->select("title")->from("bankbranch")->where("id", $id)->get()->row()->title;
    }

    public function getKyc($id)
    {
        return $this->db->select("fullname")->from("bankprofile")->where("id", $id)->get()->row()->fullname;
    }

    public function viewFile($file)
    {
        $path = "../photoid/" . $file;
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $data = file_get_contents($path);
        $base64 = "data:image/" . $type . ";base64," . base64_encode($data);
        return "<img src='" . $base64 . "' class='img-responsive'>";
    }

    public function viewLogo($file)
    {
        $path = "../photoid/" . $file;
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $data = file_get_contents($path);
        return $base64 = "data:image/" . $type . ";base64," . base64_encode($data);
    }

    public function viewPinDigit($pin)
    {
        $fast = substr($pin, 0, 4);
        $num = strlen($pin);
        $k = $num - 4;
        $i = 0;
        while( $i < $k ) 
        {
            $fast .= "*";
            $i++;
        }
        return $fast;
    }

    public function bankRate($bid, $v = false)
    {
        $cid = $this->db->get_where("banklist", array( "id" => $bid ))->row()->cid;
        $r = $this->db->query("SELECT r.exchange_rate, r.currency_code FROM countries c, currency r WHERE c.currency_code=r.currency_code AND id='" . $cid . "'");
        if( $r->num_rows() == 1 ) 
        {
            $r = $r->row();
            if( $v == false ) 
            {
                return $r->exchange_rate;
            }

            return number_format($r->exchange_rate, 4) . "  " . $r->currency_code;
        }

        return "-1";
    }

    public function pinRate($cid, $v = false)
    {
        $r = $this->db->query("SELECT r.exchange_rate, r.currency_code FROM countries c, currency r WHERE c.currency_code=r.currency_code AND id='" . $cid . "'");
        if( $r->num_rows() == 1 ) 
        {
            $r = $r->row();
            if( $v == false ) 
            {
                return $r->exchange_rate;
            }

            return number_format($r->exchange_rate, 4) . "  " . $r->currency_code;
        }

        return "-1";
    }

    public function cCodeByCountry($id)
    {
        $r = $this->db->query("SELECT r.exchange_rate, r.currency_code FROM countries c, currency r WHERE c.currency_code=r.currency_code AND c.id='" . $id . "'");
        if( $r->num_rows() == 1 ) 
        {
            $r = $r->row();
            echo $r->currency_code . " <small style='color:red'> (Ex Rate: " . $r->exchange_rate . ")</small>";
        }

    }

}


