<?php

class Request_model extends CI_Model    {

    public function __construct() {
        parent::__construct();
    }

    public function get_cost($res, $service, $number, $amount) {
        $rate_query = $this->db->from('rates')
            ->where('res_id', $res)
            ->where('service_id', $service)
            ->where('LOCATE(prefix, "'.$number.'")=1');
        $rate_row = $rate_query->get()->row();
        if ($rate_row == null) {
            return -1;
        }

        $cost = $amount;
        $commision = 0;
        $charge = 0;
        if( 0 < $rate_row->rate )
        {
            $cost = $rate_row->rate * $amount;
        }

        if( 0 < $rate_row->commision )
        {
            $commision = ($cost * $rate_row->commision) / 100;
        }

        if( 0 < $rate_row->charge )
        {
            $charge = ($cost * $rate_row->charge) / 100;
        }

        $cost = $cost - $commision + $charge;
        return $cost;
    }

    public function request($service, $number, $amount, $type, $res, $level, $cid = "-1", $oid = "-1", $photoid = "",
                            $sendername = "", $receivername = "", $photofile = "")
    {
        $this->table_schema_model->generate_requests_table();
        $table = $this->table_schema_model->get_request_table();
        $amount = round($amount);
        $uRow = $this->utility_model->get_row('resellers', array('id'=>$res));

        $cost_main = $this->get_cost($res, $service, $number, $amount);
        if ($cost_main == -1) {
            return array("code" => -1, 'data' => null);
        }

        $cost["main"] = $cost_main;
        $cost["rs5"] = $uRow->rs5;
        $cost["rs4"] = $uRow->rs4;
        $cost["rs3"] = $uRow->rs3;
        $cost["rs2"] = $uRow->rs2;
        $bb1 = $this->utility_model->getBalance($res);
        $bb5 = $this->utility_model->getBalance($uRow->rs5);
        $bb4 = $this->utility_model->getBalance($uRow->rs4);
        $bb3 = $this->utility_model->getBalance($uRow->rs3);
        $bb2 = $this->utility_model->getBalance($uRow->rs2);
        $this->utility_model->dedBal_all($res, $level, $cost);
        if( !strlen($type) )
        {
            $type = 1;
        }

        $data = array( "cid" => $cid, "oid" => $oid, "sender" => $res, "receiver" => $number,
            "amount" => $amount, "type" => $type, "status" => $this->utility_model->safeAmount($service, $amount),
            "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2,
            "cost" => (strlen($cost["main"]) ? $cost["main"] : 0), "cost5" => (strlen($cost["rs5"]) ? $cost["rs5"] : 0),
            "cost4" => (strlen($cost["rs4"]) ? $cost["rs4"] : 0), "cost3" => (strlen($cost["rs3"]) ? $cost["rs3"] : 0),
            "cost2" => (strlen($cost["rs2"]) ? $cost["rs2"] : 0),
            "bal" => $bb1 . "," . $this->utility_model->getBalance($res),
            "bal5" => $bb5 . "," . $this->utility_model->getBalance($uRow->rs5),
            "bal4" => $bb4 . "," . $this->utility_model->getBalance($uRow->rs4),
            "bal3" => $bb3 . "," . $this->utility_model->getBalance($uRow->rs3),
            "bal2" => $bb2 . "," . $this->utility_model->getBalance($uRow->rs2), "service_id" => $service,
            "req_time" => date("Y-m-d H:i:s"), "ip" => $this->utility_model->RemoteIP());

        $this->db->insert($table, $data);
        $send = $this->db->insert_id();
        $send_data = $this->utility_model->get($table, array('id'=>$send));
        $response = array("code" => 0, 'data' => $send_data);
//        $this->load->model("Module", "mod");
//        $this->mod->request($send, $data);
        return $response;
    }
}