<?php

class Filter_model extends CI_Model    {

    public function __construct() {
        parent::__construct();
    }

    public function myLatestHistory($reseller) {
        $rsQl = "sender='$reseller'";

        $sql = null;
        $select = "*";

        $where = "1=1 ";
        if (strlen($reseller)) {
            $where .= "AND $rsQl";
        }

        $from = date("Y-m-d");
        $to = date("Y-m-d");

        $months = $this->utility_model->get_months($from, $to);

        foreach ($months as $month):
            $sql .= "UNION (SELECT $select, '$month' tbl  FROM requests_$month WHERE $where) ";
        endforeach;

        $sql = substr($sql, 6);

        $sql .= " ORDER BY last_update DESC LIMIT 50";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function myHistory($query) {
        $from = $query['from'];
        $to = $query['to'];
        $reseller = $query['reseller'];
        $rsQl = null;

        if (strlen($reseller)) {
            $rsQl = "sender='$reseller'";
        }

        $sql = null;
        $select = "*";

        $where = "1=1 ";
        if (strlen($reseller)) {
            $where .= "AND $rsQl";
        }

        if (strlen($from) && strlen($to)) {
            $where .= "AND date(last_update) >= '$from' AND  date(last_update) <= '$to' ";
        };

        //FIND TABLE
        $months = $this->utility_model->get_months($from, $to);

        foreach ($months as $month):
            $sql .= "UNION (SELECT $select, '$month' tbl  FROM requests_$month WHERE $where) ";
        endforeach;

        $sql = substr($sql, 6);

        $sql .= " LIMIT 50";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function myLatestPayments($reseller) {
        $query = $this->db->select('*')
            ->from('flexi_transfer_log')
            ->where('bal_from', $reseller)
            ->order_by('logtime', 'desc')
            ->limit(50);

        return $query->get()->result_array();
    }
}