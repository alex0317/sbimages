<?php

class Filter extends CI_Model
{

    public function __construct()
    {

    }

    public function myReseller($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('username', 'balance', 'mobile', 'status', 'last_login', 'creationdate');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';

        $id = $this->session->userdata('id');
        $level = $this->session->userdata("user_type");
        $myres = $level - 1;

        $q = $this->db->select('id, username, balance, mobile, status, last_login, creationdate,parent,currency')
            ->from('resellers')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['username'])) {
            $q->like('username', $query_array['username'], 'after');
        }

        if (strlen($query_array['mobile'])) {
            $q->like('mobile', $query_array['mobile'], 'after');
        }

        if (strlen($query_array['name'])) {
            $q->like('fullname', $query_array['name'], 'after');
        }

        if (strlen($query_array['email'])) {
            $q->like('email', $query_array['email'], 'after');
        }

        $q->where('user_type !=', '-1');
        $q->where('status !=', '3');

        if ($level != 5) {
            $q->where('user_type', $myres);
            $q->where('parent', $id);
        } else {
            $q->where('user_type', $query_array['rs']);
            $q->where('rs5', $id);
        }

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('resellers');

        if (strlen($query_array['username'])) {
            $q->like('username', $query_array['username'], 'after');
        }

        if (strlen($query_array['mobile'])) {
            $q->like('mobile', $query_array['mobile'], 'after');
        }

        if (strlen($query_array['name'])) {
            $q->like('fullname', $query_array['name'], 'after');
        }

        if (strlen($query_array['email'])) {
            $q->like('email', $query_array['email'], 'after');
        }

        $q->where('parent', $id);
        $q->where('user_type', $myres);
        $q->where('user_type !=', '-1');
        $q->where('status !=', '3');

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function bulkList($limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'title');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';

        $id = $this->session->userdata('id');

        $q = $this->db->select('id, title')
            ->from('flexi_bulk_list')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);


        $q->where('res_id', $id);

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('flexi_bulk_list');

        $q->where('res_id', $id);

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function addressbook($limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'title');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';

        $id = $this->session->userdata('id');

        $q = $this->db->select('id, title')
            ->from('sms_list')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);


        $q->where('res_id', $id);

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('sms_list');

        $q->where('res_id', $id);

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }


    public function myHistory($query, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'receiver', 'amount', 'cost', 'type', 'service_id', 'sender', 'status', 'last_update');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';
        $rid = $this->session->userdata("id");

        //QUERY STRING
        $sql = null;
        $sql_count = null;
        $num_rows = 0;
        $from = $query['from'];
        $to = $query['to'];
        $req_id = $query['id'];
        $logic = $query['logic'];
        $number = $query['number'];
        $reseller = $query['reseller'];
        $service_id = $query['service'];
        $status = $query['status'];

        if (strlen($reseller)) {
            $lvl = $this->lvlByid($reseller);
            if ($lvl == 1) $rsQl = "sender='$reseller'";
            else if ($rid == $reseller) $rsQl = "sender='$reseller'";
            else $rsQl = "(sender='$reseller' OR rs$lvl='$reseller')";
        }

        //Decide Table
        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        if ($rs == 1) {
            $resQl = "sender ='$id'";
            $selQl = "cost as cost";
            $balQl = "bal as bal";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
            $selQl = "if( sender=$id, cost, cost$rs )as cost";
            $balQl = "if( sender=$id, bal, bal$rs )as bal";
        }

        $select = "id, receiver, amount, $selQl, $balQl, type, service_id, sender, status, last_update, transactionid, currency";

        $where = "1=1 ";
        if (strlen($logic) && strlen($req_id)) {
            $where .= "AND id $logic $req_id ";
        }
        if (strlen($number)) {
            $where .= "AND receiver LIKE '$number%' ";
        }
        if (strlen($reseller)) {
            $where .= "AND $rsQl";
        } else {
            $where .= "AND $resQl ";
        }
        if ($service_id != 'all') {
            $where .= "AND service_id='$service_id' ";
        }
        if (strlen($status)) {
            $where .= "AND status='$status' ";
        }
        if (strlen($from) && strlen($to)) {
            $where .= "AND date(last_update) >= '$from' AND  date(last_update) <= '$to' ";
        };

        //FIND TABLE
        $months = $this->lib->get_months($from, $to);

        foreach ($months as $month):
            $sql .= "UNION (SELECT $select, '$month' tbl  FROM requests_$month WHERE $where) ";
            $sql_count .= "UNION (SELECT COUNT(*) as count FROM requests_$month WHERE $where) ";
        endforeach;

        $sql = substr($sql, 6);
        $sql_count = substr($sql_count, 6);

        $order = "ORDER BY $sort_by $sort_order ";
        $limit = "LIMIT $offset, $limit";

        //Result Query
        $query = $this->db->query($sql . $order . $limit);
        $ret['rows'] = $query->result();

        //Record Query
        $cQ = $this->db->query($sql_count);

        foreach ($cQ->result() as $r):$num_rows += $r->count;endforeach;

        $ret['num_rows'] = $num_rows;

        return $ret;
    }

    public function myPending($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $table = $this->lib->req_tbl();
        $str = str_replace('requests_', '', $table);
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'receiver', 'amount', 'cost', 'type', 'service_id', 'sender', 'status', 'last_update');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        if ($rs == 1) {
            $resQl = "sender ='$id'";
            $selQl = "cost as cost";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
            $selQl = "if( sender=$id, cost, cost$rs )as cost";
        }

        $q = $this->db->select("id, receiver, amount, $selQl, type, currency, service_id, sender, status, last_update, '$str' tbl", false)
            ->from($table)
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['number'])) {
            $q->like('receiver', $query_array['number'], 'after');
        }

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['service'])) {
            $q->where('service_id', $query_array['service']);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        } else {
            $q->where("(status<3 OR status>4)");
        }

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from($table);

        if (strlen($query_array['number'])) {
            $q->like('receiver', $query_array['number'], 'after');
        }

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['service'])) {
            $q->where('service_id', $query_array['service']);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        } else {
            $q->where("(status<3 OR status>4)");
        }

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function cardHistory($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'opt_id', 'type', 'amnt_id', 'sender', 'date_update', 'mycost');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        if ($rs == 1) {
            $resQl = "sender ='$id'";
            $selQl = "cost as mycost";
            $balQl = "bal as bal";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
            $selQl = "if( sender=$id, cost, cost$rs )as mycost";
            $balQl = "if( sender=$id, bal, bal$rs )as bal";
        }

        $q = $this->db->select("id, opt_id, type, amnt_id, $selQl, $balQl, date_update, card_id, sender, receiver")
            ->from('card_history')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['operator'])) {
            $q->where('opt_id', $query_array['operator']);
        }
        if (strlen($query_array['type'])) {
            $q->where('type', $query_array['type']);
        }
        if (strlen($query_array['amount'])) {
            $q->where('amnt_id', $query_array['amount']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(date_update)>=', $query_array['from']);
            $q->where('date(date_update)<=', $query_array['to']);
        }

        $ret['rows'] = $q->get()->result();

        //	print_r($ret['rows']); exit;

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('card_history');

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['operator'])) {
            $q->where('opt_id', $query_array['operator']);
        }
        if (strlen($query_array['type'])) {
            $q->where('type', $query_array['type']);
        }
        if (strlen($query_array['amount'])) {
            $q->where('amnt_id', $query_array['amount']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(date_update)>=', $query_array['from']);
            $q->where('date(date_update)<=', $query_array['to']);
        }

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function smsHistory($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'sender_id', 'receiver', 'mycost', 'sender', 'status', 'send_time');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        if ($rs == 1) {
            $resQl = "sender ='$id'";
            $selQl = "cost as mycost";
            $balQl = "bal as bal";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
            $selQl = "if( sender=$id, cost, cost$rs )as mycost";
            $balQl = "if( sender=$id, bal, bal$rs )as bal";
        }

        $q = $this->db->select("id, sender_id, receiver, $selQl, $balQl, sender, status, send_time, sms")
            ->from('sms_req')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['number'])) {
            $q->like('receiver', $query_array['number'], 'after');
        }

        if (strlen($query_array['sender'])) {
            $q->where('sender_id', $query_array['sender']);
        }

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(send_time)>=', $query_array['from']);
            $q->where('date(send_time)<=', $query_array['to']);
        }

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('sms_req');

        if (strlen($query_array['number'])) {
            $q->like('receiver', $query_array['number'], 'after');
        }

        if (strlen($query_array['sender'])) {
            $q->where('sender_id', $query_array['sender']);
        }

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(send_time)>=', $query_array['from']);
            $q->where('date(send_time)<=', $query_array['to']);
        }

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }


    public function bankHistory($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'receiver', 'amount', 'mycost', 'type', 'reseller', 'transactionid', 'status', 'last_update');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        if ($rs == 1) {
            $resQl = "sender ='$id'";
            $selQl = "cost as mycost";
            $balQl = "bal as bal";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
            $selQl = "if( sender=$id, cost, cost$rs )as mycost";
            $balQl = "if( sender=$id, bal, bal$rs )as bal";
        }

        $q = $this->db->select("*, $selQl, $balQl")
            ->from('banktransfer')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['receiver'])) {
            $q->like('receiver', $query_array['receiver'], 'after');
        }

        if (strlen($query_array['country'])) {
            $q->where('cid', $query_array['country']);
        }

        if (strlen($query_array['bank'])) {
            $q->where('bid', $query_array['bank']);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        }

        $q->where('type', "TRANSFER");

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(last_update)>=', $query_array['from']);
            $q->where('date(last_update)<=', $query_array['to']);
        }

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('banktransfer');

        if (strlen($query_array['receiver'])) {
            $q->like('receiver', $query_array['receiver'], 'after');
        }

        if (strlen($query_array['country'])) {
            $q->where('cid', $query_array['country']);
        }

        if (strlen($query_array['bank'])) {
            $q->where('bid', $query_array['bank']);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        }

        $q->where('type', "TRANSFER");


        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(last_update)>=', $query_array['from']);
            $q->where('date(last_update)<=', $query_array['to']);
        }

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function pinHistory($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'receiver', 'amount', 'mycost', 'type', 'reseller', 'transactionid', 'status', 'last_update');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        if ($rs == 1) {
            $resQl = "sender ='$id'";
            $selQl = "cost as mycost";
            $balQl = "bal as bal";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
            $selQl = "if( sender=$id, cost, cost$rs )as mycost";
            $balQl = "if( sender=$id, bal, bal$rs )as bal";
        }

        $q = $this->db->select("*, $selQl, $balQl")
            ->from('banktransfer')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['receiver'])) {
            $q->like('receiver', $query_array['receiver'], 'after');
        }

        if (strlen($query_array['country'])) {
            $q->where('cid', $query_array['country']);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        }

        $q->where('type', "PIN");

        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(last_update)>=', $query_array['from']);
            $q->where('date(last_update)<=', $query_array['to']);
        }

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('banktransfer');

        if (strlen($query_array['receiver'])) {
            $q->like('receiver', $query_array['receiver'], 'after');
        }

        if (strlen($query_array['country'])) {
            $q->where('cid', $query_array['country']);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        }

        $q->where('type', "PIN");


        if (strlen($query_array['reseller'])) {
            $rsId = $query_array['reseller'];
            $lvl = $this->lvlByid($rsId);
            if ($lvl == 1) $q->where('sender', $rsId);
            else $q->where("(sender='$rsId' OR rs$lvl='$rsId')");
        } else {
            $q->where($resQl);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(last_update)>=', $query_array['from']);
            $q->where('date(last_update)<=', $query_array['to']);
        }

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function myPaymnets($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'logtime', 'bal_to', 'note', 'type', 'amount');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';

        $id = $this->session->userdata('id');
        $level = $this->session->userdata("user_type");
        $myres = $level - 1;

        $q = $this->db->select('id, logtime, bal_to, note, type, amount, actual, bal_currency')
            ->from('flexi_transfer_log')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['id']) && $query_array['id'] != "all") {
            $q->where('bal_to', $query_array['id']);
        }

        if (strlen($query_array['type'])) {
            $q->where('type', $query_array['type']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_from', $id);
        $q->where('byadmin', 0);

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('flexi_transfer_log');

        if (strlen($query_array['id']) && $query_array['id'] != "all") {
            $q->where('bal_to', $query_array['id']);
        }

        if (strlen($query_array['type'])) {
            $q->where('type', $query_array['type']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_from', $id);
        $q->where('byadmin', 0);

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;


        //Total Payment
        $q = $this->db->select('SUM(amount) as total', FALSE)
            ->from('flexi_transfer_log');

        if (strlen($query_array['id']) && $query_array['id'] != "all") {
            $q->where('bal_to', $query_array['id']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_from', $id);
        $q->where('type', "transfer");
        $q->where('byadmin', 0);

        $tmp = $q->get()->result();
        $ret['transfer'] = $tmp[0]->total;

        //Total Refund
        $q = $this->db->select('SUM(amount) as total', FALSE)
            ->from('flexi_transfer_log');

        if (strlen($query_array['id']) && $query_array['id'] != "all") {
            $q->where('bal_to', $query_array['id']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_from', $id);
        $q->where('type', "return");

        $tmp = $q->get()->result();
        $ret['refund'] = $tmp[0]->total;
        $q->where('byadmin', 0);

        //Total Canceled
        $q = $this->db->select('SUM(amount) as total', FALSE)
            ->from('flexi_transfer_log');

        if (strlen($query_array['id']) && $query_array['id'] != "all") {
            $q->where('bal_to', $query_array['id']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_from', $id);
        $q->where('type', "canceled");
        $q->where('byadmin', 0);

        $tmp = $q->get()->result();
        $ret['canceled'] = $tmp[0]->total;

        return $ret;
    }

    public function myReveived($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'logtime', 'bal_from', 'note', 'type', 'amount');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';

        $id = $this->session->userdata('id');

        $q = $this->db->select('id, logtime, bal_from, note, type, amount, byadmin, actual, bal_currency')
            ->from('flexi_transfer_log')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (!strlen($query_array['type'])) {
            $q->where('type !=', 'canceled');
        } else if ($query_array['type'] != 'all') {
            $q->where('type', $query_array['type']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_to', $id);

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('flexi_transfer_log');

        if (!strlen($query_array['type'])) {
            $q->where('type !=', 'canceled');
        } else if ($query_array['type'] != 'all') {
            $q->where('type', $query_array['type']);
        }

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_to', $id);

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        //Query Payment
        $q = $this->db->select('SUM(amount) total')
            ->from('flexi_transfer_log');

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_to', $id);
        $q->where('type', "transfer");
        $tmp = $q->get()->result();
        $ret['transfer'] = $tmp[0]->total;

        //Query Return
        $q = $this->db->select('SUM(amount) total')
            ->from('flexi_transfer_log');

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_to', $id);
        $q->where('type', "refund");
        $tmp = $q->get()->result();
        $ret['refund'] = $tmp[0]->total;

        //Query canceled
        $q = $this->db->select('SUM(amount) total')
            ->from('flexi_transfer_log');

        if (strlen($query_array['from']) && strlen($query_array['to'])) {
            $q->where('date(logtime)>=', $query_array['from']);
            $q->where('date(logtime)<=', $query_array['to']);
        }

        $q->where('bal_to', $id);
        $q->where('type', "canceled");
        $tmp = $q->get()->result();
        $ret['canceled'] = $tmp[0]->total;

        return $ret;
    }

    public function myListNumber($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'number', 'firstname', 'lastname');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';

        $q = $this->db->select('id, number, firstname, lastname')
            ->from('sms_contacts')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['number'])) {
            $q->like('number', $query_array['number'], "after");
        }

        if (strlen($query_array['firstname'])) {
            $q->like('firstname', $query_array['firstname'], "after");
        }

        if (strlen($query_array['lastname'])) {
            $q->like('lastname', $query_array['lastname'], "after");
        }

        $q->where('lid', $query_array['id']);

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('sms_contacts');

        if (strlen($query_array['number'])) {
            $q->like('number', $query_array['number'], "after");
        }

        if (strlen($query_array['firstname'])) {
            $q->like('firstname', $query_array['firstname'], "after");
        }

        if (strlen($query_array['lastname'])) {
            $q->like('lastname', $query_array['lastname'], "after");
        }

        $q->where('lid', $query_array['id']);

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    public function myTicket($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('id', 'title', 'sender', 'status', 'last_update');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');
        $txt = $query_array['text'];
        $textSQL = "(title LIKE '%$txt%' OR message LIKE '%$txt%')";

        if ($rs == 1) {
            $resQl = "sender ='$id'";
        } else {
            $resQl = "(sender='$id' OR rs$rs='$id')";
        }

        $q = $this->db->select("id, title, sender, status, last_update")
            ->from('support_ticket')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        if (strlen($query_array['id'])) {
            $q->where('id', $query_array['id']);
        }

        if (strlen($query_array['text'])) {
            $q->where($textSQL);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        }

        $q->where($resQl);

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('support_ticket');

        if (strlen($query_array['id'])) {
            $q->where('id', $query_array['id']);
        }

        if (strlen($query_array['text'])) {
            $q->where($textSQL);
        }

        if (strlen($query_array['status'])) {
            $q->where('status', $query_array['status']);
        }

        $q->where($resQl);

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }


    public function myRates($query_array, $limit, $offset, $sort_by, $sort_order)
    {
        $sort_order = ($sort_order == 'desc') ? 'desc' : 'asc';
        $sort_columns = array('service_id', 'prefix', 'type', 'rate', 'commision', 'charge', 'enable');
        $sort_by = (in_array($sort_by, $sort_columns)) ? $sort_by : 'id';


        $res_id = $this->session->userdata('id');
        $rs = $this->session->userdata('user_type');

        $q = $this->db->select("service_id, prefix, type, rate, commision, charge, enable")
            ->from('rates')
            ->limit($limit, $offset)
            ->order_by($sort_by, $sort_order);

        $q->where('res_id', $res_id);

        if (strlen($query_array['prefix'])) {
            $q->like('prefix', $query_array['prefix'], "after");
        }

        if (strlen($query_array['service'])) {
            $q->where('service_id', $query_array['service']);
        }

        $ret['rows'] = $q->get()->result();

        //Count
        $q = $this->db->select('COUNT(*) as count', FALSE)
            ->from('rates');

        $q->where('res_id', $res_id);

        if (strlen($query_array['prefix'])) {
            $q->like('prefix', $query_array['prefix'], "after");
        }

        if (strlen($query_array['service'])) {
            $q->where('service_id', $query_array['service']);
        }

        $tmp = $q->get()->result();

        $ret['num_rows'] = $tmp[0]->count;

        return $ret;
    }

    function lvlByid($id)
    {
        $q = $this->db->query("SELECT user_type FROM resellers WHERE id='$id' LIMIT 1");
        $r = $q->row();
        return $r->user_type;
    }
}

?>