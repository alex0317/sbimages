<?php

class Table_schema_model extends CI_Model    {

    public function __construct() {
        parent::__construct();
    }

    public function generate_requests_table()
    {
        $prev_month = date("mY", strtotime("-1 month"));
        $month = date("mY");
        $new_tbl = "requests_" . $month;
        $prv_tbl = "requests_" . $prev_month;
        $database = $this->db->database;
        $sQ = $this->db->query("SELECT count(*) tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='" . $new_tbl . "'");
        $rQ = $sQ->row();
        if( $rQ->tbl == 0 )
        {
            $prv = $this->db->query("SELECT count(*) tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='" . $prv_tbl . "'")->row();
            if( $prv->tbl == 0 )
            {
                $prv_tbl = "requestmp";
            }

            $this->db->query("CREATE TABLE IF NOT EXISTS " . $new_tbl . " LIKE " . $prv_tbl);
            $pQ = $this->db->query("SELECT id,cid,oid,sender,receiver,amount,type,service_id,cost,cost2,cost3,cost4,cost5,currency,bal,bal2,bal3,bal4,bal5,rs2,rs3,rs4,rs5,status,transactionid,modem,sim,api,confirmed,token,ip,req_time,last_update,photoid,sendername,receivername,photofile FROM " . $prv_tbl . " WHERE status<3");
            if( 0 < $pQ->num_rows() )
            {
                foreach( $pQ->result() as $pR )
                {
                    $id = $pR->id;
                    $this->db->insert($new_tbl, $pR);
                    $newid = $this->db->insert_id();
                    if( strlen($newid) && $newid == $id )
                    {
                        $this->db->query("DELETE FROM " . $prv_tbl . " WHERE id='" . $id . "'");
                    }

                }
            }

            $aQ = $this->db->query("SELECT AUTO_INCREMENT last_id FROM information_schema.tables WHERE table_name='" . $prv_tbl . "' AND table_schema='" . $database . "'");
            $aR = $aQ->row();
            $this->db->query("ALTER TABLE " . $new_tbl . " AUTO_INCREMENT = " . $aR->last_id);
            $clm = "id,cid,oid,sender,receiver,amount,type,service_id,cost,cost2,cost3,cost4,cost5,currency,bal,bal2,bal3,bal4,bal5,rs2,rs3,rs4,rs5,status,transactionid,modem,sim,api,confirmed,token,ip,req_time,last_update,photoid,sendername,receivername,photofile";
            $tQ = $this->db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name LIKE 'requests_%'");
            $sql = NULL;
            foreach( $tQ->result() as $row )
            {
                $month = str_replace("requests_", "", $row->table_name);
                $sql .= "UNION ALL SELECT " . $clm . ", '" . $month . "' tbl FROM " . $row->table_name . " ";
            }
            $sql = substr($sql, 10);
            $this->db->query("DROP VIEW IF EXISTS request_view");
            $this->db->query("CREATE VIEW `request_view` AS " . $sql);
        }

        $this->db->query("ALTER TABLE `resellers` CHANGE `status` `status` INT(11) NULL DEFAULT '0'");
        return NULL;
    }

    public function get_request_table()
    {
        $table = "requests_" . date("mY");
        return $table;
    }
}