<?php


class Utility_model extends CI_Model    {

    public function __construct() {
        parent::__construct();
    }

    public function start() {
        $this->db->trans_start();
    }
    public function complete() {
        $this->db->trans_complete();
    }
    
    
    public function begin() {
        $this->db->trans_begin();
    }
    public function commit() {
        $this->db->trans_commit();
    }
    public function rollback() {
        $this->db->trans_rollback();
    }
    
    /**
     * insert data.
     * 
     * @param string $table Table Name
     * @param array $data
     * @return boolean
     */
    public function insert($table, $data){
        return $this->db->insert($table, $data);
    }
    
    public function new_id() {
        return $this->db->insert_id();
    }

    /**
     * Update data.
     * 
     * @param string $table Table Name
     * @param array $data
     * @param array $cond Condition
     * @return boolean
     */
    public function update($table, $data, $cond){
        return $this->db->update($table, $data, $cond);
    }

    public function save($table, $data, $cond, $additional_data=array()){
        if ($this->get($table, $cond)) {
            return $this->db->update($table, $data, $cond);
        } else {
            foreach ($cond as $key => $value) {
                $data[$key] = $value;
            }
            foreach ($additional_data as $key => $value) {
                $data[$key] = $value;
            }
            return $this->db->insert($table, $data);
        }
    }
    
    /**
     * Update data.
     * 
     * @param string $sql SQL
     * @return boolean
     */
    public function update__by_sql($sql) {
        return $this->db->query($sql);        
    }
    
    /**
     * Get data.
     * 
     * @param string $table Table Name
     * @param array $cond Condition
     * @return array
     */
    public function get($table, $cond){
        $query = $this->db->get_where($table, $cond);
        return $query->row_array();
    }

    public function get_row($table, $cond){
        $query = $this->db->get_where($table, $cond);
        return $query->row();
    }

    public function get_or($table, $conds) {
        $index = 0;
        $query = $this->db->select("*")->from($table);
        foreach ($conds as $cond) {
            if ($index == 0) {
                $query->where($cond["field"], $cond["val"]);
            }
            else {
                $query->or_where($cond["field"], $cond["val"]);
            }
            $index = $index + 1;
        }
        return $query->get()->row_array();
    }
    
    /**
     * Get data.
     * 
     * @param string $sql SQL
     * @return array
     */
    public function get__by_sql($sql){
        $query = $this->db->query($sql);
        return $query->row_array();
    }
    
    /**
     * Get count.
     * 
     * @param string $table Table Name
     * @param array $cond Condition
     * @return integer
     */
    public function get_count($table, $cond){
        $query = $this->db->get_where($table, $cond);
        return $query->num_rows();
    }
    
    /**
     * Get count.
     * 
     * @param string $sql SQL
     * @return integer
     */
    public function get_count__by_sql($sql){
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    
    /**
     * Get list.
     * 
     * @param string $table Table Name
     * @param array $cond Condition
     * @return array
     */
    public function get_list($table, $cond=''){
        $query=null;
        if (is_array($cond)){
            $query = $this->db->get_where($table, $cond);
        } else {
            $query = $this->db->get($table);
        }
        return $query->result_array();
    }

    /**
     * Get list with ordering.
     * 
     * @param string $table Table Name
     * @param array $cond Condition
     * @param array $order Order
     * @return array 
     */
    public function get_list__by_order($table, $cond, $order){
        foreach ($order as $row) {
            $this->db->order_by($row['name'], $row['order']);
        }
        
        $query = $this->db->get_where($table, $cond);
        return $query->result_array();
    }
    
    /**
     * Get list.
     * 
     * @param string $sql SQL
     * @return array
     */
    public function get_list__by_sql($sql){
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    
    /**
     * Delete data.
     * 
     * @param string $table Table Name
     * @param array $cond Condition
     * @return boolean
     */
    public function delete($table, $cond){
       return $this->db->delete($table , $cond);
    }
 
    public function delete__by_sql($sql) {
        return $this->db->query($sql);        
    }

    /**
     * Get field.
     * 
     * @param string $sql SQL
     * @param string $field Field Name
     * @return string
     */
    public function get_field__by_sql($sql, $field){
        $query = $this->db->query($sql);
        $row = $query->row_array();
        if ($row){
            return isset($row[$field]) ? $row[$field] : '';
        }
        
        return '';
    }
    
    public function get_default_value($value, $default_value = "") {
        return $value===false ? $default_value : $value;
    }

    public function curl_get($url, $get = NULL, $options = array(  ))
    {
        $defaults = array( CURLOPT_URL => $url . ((strpos($url, "?") === false ? "?" : "")) . http_build_query($get), CURLOPT_HEADER => 0, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 400 );
        $ch = curl_init();
        curl_setopt_array($ch, $options + $defaults);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    public function getSet($set)
    {
        $q = $this->db->select("value");
        $q->from("config");
        $q->where("setting", $set);
        $q->limit(1);
        $tmp = $q->get()->result();
        return $tmp[0]->value;
    }

    public function random_numbers($digits)
    {
        $min = pow(10, $digits - 1);
        $max = pow(10, $digits) - 1;
        return mt_rand($min, $max);
    }

    public function passKey()
    {
        $this->load->config("status");
        $key = $this->config->item("data");
        return $this->mc_decrypt($key);
    }

    public function mc_encrypt($encrypt)
    {
        $key = "fc20faf446aa0197252220c677fdb4b8acb61142fcd55f4b5c32611b87cd923e";
        $passcrypt = $this->encrypt->encode($encrypt, $key);
        $encoded = base64_encode($passcrypt);
        return $encoded;
    }

    public function mc_decrypt($decrypt)
    {
        $key = "fc20faf446aa0197252220c677fdb4b8acb61142fcd55f4b5c32611b87cd923e";
        $decoded = base64_decode($decrypt);
        $decrypted = $this->encrypt->decode($decoded, $key);
        return $decrypted;
    }

    public function islevel5()
    {
        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $q = $this->db->select("*")->from("subadmin")->where("domain", $domain)->limit(1);
        $query = $q->get();
        if( $query->num_rows() == 1 )
        {
            $r = $query->row();
            return $r->uid;
        }

        return false;
    }

    public function getBrand($str)
    {
        $var = $this->islevel5();
        if( $var == false )
        {
            $q = $this->db->select("value");
            $q->from("config");
            $q->where("setting", $str);
            $q->limit(1);
            $tmp = $q->get()->result();
            return $tmp[0]->value;
        }

        $q = $this->db->select((string) $str . " value")->from("subadmin")->where("uid", $var);
        $tmp = $q->get()->result();
        return $tmp[0]->value;
    }

    public function mail($param = NULL)
    {
        require_once(APPPATH . "/third_party/phpmail/class.phpmailer.php");
        return new PHPMailer($param);
    }

    public function getType($type)
    {
        $modules = array(  );
        if( 0 < $type )
        {
            $bin = decbin($type);
            $digit = str_split($bin);
            $result = array_reverse($digit);
            $i = 1;
            $j = 1;
            foreach( $result as $data )
            {
                $tata = $data * $i;
                if( $tata != 0 )
                {
                    $slipt[$j] = $tata;
                    $j++;
                }

                $i = $i + $i;
            }
            if( isset($slipt) )
            {
                $clients = new stdClass();
                foreach( $slipt as $client )
                {
                    $modules[] = $client;
                }
            }

        }

        return $modules;
    }

    public function myServices($type)
    {
        $data = array(  );
        $otp = $this->getSet("reseller_otp");
        $module = $this->getType($type);
        $q = $this->db->select("*")->from("services")->where("type !=", "16")->where("type >", "4");
//        $q = $this->db->select("*")->from("services")->where("type >", "4");
        $result = $q->get()->result();
        foreach( $result as $row )
        {
            if( in_array($row->type, $module) )
            {
                $tmp = new stdClass();
                $tmp->id = $row->id;
                $tmp->title = $row->title;
                $tmp->spaceuri = $row->spaceuri;
                $tmp->type = $row->type;
                $tmp->enable = $row->enable;
                $tmp->min_amnt = $row->min_amnt;
                $tmp->max_amnt = $row->max_amnt;
                $tmp->min_length = $row->min_length;
                $tmp->max_length = $row->max_length;
                $tmp->risk_amount = $row->risk_amount;
                $tmp->short = $row->short;
                $tmp->require_pin = 0;
                $tmp->logo = $row->spaceuri;
                $data[] = $tmp;
            }

        }
//        if( in_array(2, $module) )
//        {
//            $q = $this->db->select("*")->from("services")->where("type", "2");
//            $row = $q->get()->row();
//            if( $otp == 0 )
//            {
//                $row->require_pin = $row->require_pin;
//            }
//
//            if( $otp == 1 )
//            {
//                $row->require_pin = 0;
//            }
//
//            $row->logo = $row->spaceuri;
//            $data[] = $row;
//        }

        if( in_array(4, $module) )
        {
            $q = $this->db->select("*")->from("services")->where("type", "4");
            $row = $q->get()->row();
            if( $otp == 0 )
            {
                $row->require_pin = $row->require_pin;
            }

            if( $otp == 1 )
            {
                $row->require_pin = 0;
            }

            $row->logo = $row->spaceuri;
            $data[] = $row;
        }

        if( in_array(1, $module) )
        {
            $q = $this->db->select("*")->from("services")->where("type", "1");
            $row = $q->get()->row();
            if( $otp == 0 )
            {
                $row->require_pin = $row->require_pin;
            }

            if( $otp == 1 )
            {
                $row->require_pin = 0;
            }

            $row->logo = $row->spaceuri;
            $data[] = $row;
        }

        return $data;
    }

    public function getRelation($id, $newLevel)
    {
        $row = $this->get_row("resellers", array("id"=>$id));
        if( $newLevel == 4 )
        {
            $data["admin"] = $row->admin;
            $data["parent"] = $row->id;
            $data["rs5"] = $row->id;
            $data["rs4"] = "-1";
            $data["rs3"] = "-1";
            $data["rs2"] = "-1";
        }
        else
        {
            if( $newLevel == 3 )
            {
                $data["admin"] = $row->admin;
                $data["parent"] = $row->id;
                $data["rs5"] = $row->rs5;
                $data["rs4"] = $row->id;
                $data["rs3"] = "-1";
                $data["rs2"] = "-1";
            }
            else
            {
                if( $newLevel == 2 )
                {
                    $data["admin"] = $row->admin;
                    $data["parent"] = $row->id;
                    $data["rs5"] = $row->rs5;
                    $data["rs4"] = $row->rs4;
                    $data["rs3"] = $row->id;
                    $data["rs2"] = "-1";
                }
                else
                {
                    if( $newLevel == 1 )
                    {
                        $data["admin"] = $row->admin;
                        $data["parent"] = $row->id;
                        $data["rs5"] = $row->rs5;
                        $data["rs4"] = $row->rs4;
                        $data["rs3"] = $row->rs3;
                        $data["rs2"] = $row->id;
                    }
                    else
                    {
                        $data["admin"] = $row->admin;
                        $data["parent"] = $row->id;
                        $data["rs5"] = "-1";
                        $data["rs4"] = "-1";
                        $data["rs3"] = "-1";
                        $data["rs2"] = "-1";
                    }

                }

            }

        }

        return $data;
    }


    public function SaveLogs($type, $info, $user_id = "", $level = 0)
    {
        $ip = $this->RemoteIP();
        $date_time = date("Y-m-d H:i:s");
        $browser = "Google Chrome";
        $platform = "Android";
        $logs = array( "user" => $user_id, "level" => $level, "action" => $type, "logs" => $info,
            "datetime" => $date_time, "ip" => $ip, "agent" => $browser . " (" . $platform . ")" );
        $this->db->insert("access_logs", $logs);
    }

    public function RemoteIP()
    {
        $ip = (isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? ($ip = $_SERVER["HTTP_CF_CONNECTING_IP"]) : "");
        if( !strlen($ip) )
        {
            $ip = $_SERVER["REMOTE_ADDR"];
        }

        return $ip;
    }

    public function getBalance($id)
    {
        $query = $this->db->query("SELECT balance FROM resellers WHERE id='" . $id . "' LIMIT 1");
        $row = $query->row();
        if( $query->num_rows() == 1 )
        {
            return $row->balance;
        }

        return "0.00";
    }

    public function dedBal_all($res, $level, $cost)
    {
        $uRow = $this->get_row("resellers", array("id"=>$res));
        $this->dedbal($res, $cost["main"]);
        $this->dedbal($uRow->rs5, $cost["rs5"]);
        $this->dedbal($uRow->rs4, $cost["rs4"]);
        $this->dedbal($uRow->rs3, $cost["rs3"]);
        $this->dedbal($uRow->rs2, $cost["rs2"]);
    }

    public function dedBal($id, $amount)
    {
        $this->db->query("UPDATE resellers SET balance=balance-'" . $amount . "' WHERE id='" . $id . "' LIMIT 1");
        return true;
    }

    public function addBal($id, $amount)
    {
        $this->db->query("UPDATE resellers SET balance=balance+'" . $amount . "' WHERE id='" . $id . "' LIMIT 1");
        return true;
    }

    public function safeAmount($type, $amount)
    {
        $status = 0;
        $r = $this->db->select("risk_amount risk")->from("services")->where("type", $type)->get()->row();

        if( 0 < $r->risk )
        {
            if( $r->risk < $amount )
            {
                $status = 5;
            }
            else
            {
                $status = 0;
            }

        }

        return $status;
    }

    public function get_months($date1, $date2)
    {
        if( strlen($date1) && strlen($date2) )
        {
            $date1 = date("Y-m", strtotime($date1));
            $date2 = date("Y-m", strtotime($date2));
            if( $date1 < $date2 )
            {
                $past = $date1;
                $future = $date2;
            }
            else
            {
                $past = $date2;
                $future = $date1;
            }

            $months = array(  );
            $i = $past;
            while( $past <= $future )
            {
                $timestamp = strtotime($past . "-1");
                $months[] = date("mY", $timestamp);
                $past = date("Y-m", strtotime("+1 month", $timestamp));
                $i++;
            }
            $tables = array(  );
            $database = $this->db->database;
            foreach( $months as $month )
            {
                $sQ = $this->db->query("SELECT count(*) tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name='requests_" . $month . "'");
                $sR = $sQ->row();
                if( $sR->tbl == 1 )
                {
                    $tables[] = $month;
                }

            }
            return $tables;
        }
        else
        {
            $tbls = array(  );
            $database = $this->db->database;
            $query = $this->db->query("SELECT table_name tbl FROM information_schema.tables WHERE table_schema = '" . $database . "' AND table_name LIKE 'requests_%' ORDER BY CREATE_TIME DESC");
            foreach( $query->result() as $row )
            {
                $tbls[] = str_replace("requests_", "", $row->tbl);
            }
            return $tbls;
        }

    }

    public function view_amount($usd, $cid = "")
    {
        if( !strlen($cid) )
        {
            $cid = $this->getSet("base_currency");
        }

        $cR = $this->db->get_where("currency", array( "currency_id" => $cid ))->row();
        return array(
            'usd_amount' => $usd,
            'amount' => number_format($usd * $cR->base_rate, 4, ".", "") . " ",
            'code' => $cR->currency_code
        );
    }
}
