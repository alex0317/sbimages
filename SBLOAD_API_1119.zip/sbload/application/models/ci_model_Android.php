<?php 

class Android extends CI_Model
{
    private $iv = "971bf36e8eca90cf";
    private $key = "c375b81e459a10ff";

    public function __construct()
    {
    }

    public function go($action, $data)
    {
        switch( $action ) 
        {
            case "domain":
                $this->domain($data);
                break;
            case "create":
                $this->create($data);
                break;
            case "login":
                $this->login($data);
                break;
            case "2step":
                $this->otp($data);
                break;
            case "dashboard":
                $this->dashboard($data);
                break;
            case "balance":
                $this->balance($data);
                break;
            case "report":
                $this->report($data);
                break;
            case "support":
                $this->support($data);
                break;
            case "history":
                $this->history($data);
                break;
            case "voucher":
                $this->voucher($data);
                break;
            case "profile":
                $this->profile($data);
                break;
            case "payments":
                $this->payments($data);
                break;
            case "pin":
                $this->pin($data);
                break;
            case "password":
                $this->password($data);
                break;
            case "global_country":
                $this->global_country($data);
                break;
            case "global_opt":
                $this->global_opt($data);
                break;
            case "global_pack":
                $this->global_pack($data);
                break;
            case "global_topup":
                $this->global_topup($data);
                break;
            case "kyc_add":
                $this->kyc_add($data);
                break;
            case "kyc_edit":
                $this->kyc_edit($data);
                break;
            case "kyc_list":
                $this->kyc_list($data);
                break;
            case "kyc_view":
                $this->kyc_view($data);
                break;
            case "bank_list":
                $this->bank_list($data);
                break;
            case "branch_list":
                $this->branch_list($data);
                break;
            case "pin_rate":
                $this->pin_rate($data);
                break;
            case "banktransfer":
                $this->banktransfer($data);
                break;
            case "pintransfer":
                $this->pintransfer($data);
                break;
            case "card_opt":
                $this->card_opt($data);
                break;
            case "card_amount":
                $this->card_amount($data);
                break;
            case "bill_opt":
                $this->bill_opt($data);
                break;
            case "forgot":
                $this->forgot($data);
                break;
            case "reissue":
                $this->reissue($data);
                break;
            case "country_list":
                $this->country_list($data);
                break;
            default:
                $this->request($data);
        }
    }

    public function actions()
    {
        $actions = array( "domain", "create", "login", "2step", "dashboard", "balance", "report", "support", "history", "voucher", "profile", "payments", "pin", "password", "global_country", "global_opt", "global_pack", "global_topup", "kyc_add", "kyc_edit", "kyc_list", "kyc_view", "bank_list", "branch_list", "pin_rate", "banktransfer", "pintransfer", "card_opt", "card_amount", "bill_opt", "forgot", "reissue", "country_list" );
        $res = $this->db->select("spaceuri")->from("services")->where("enable", 1)->get()->result();
        foreach( $res as $r ) 
        {
            $actions[] = $r->spaceuri;
        }
        return $actions;
    }

    public function domain($data)
    {
        $result = array(  );
        $domain = $_SERVER["HTTP_HOST"];
        $brand = $this->input->post("brand");
        //$url = STUN_URL . "mobileAuth";
        $xData = array( "domain" => $domain, "brand" => $data->brand );
        $ret = $this->lib->curl_get($url, $xData);
        if( $ret == 1 ) 
        {
            $result["response"] = "VALID";
            $result["data"] = array( "brand" => $this->lib->getSet("brandname"), "ssl" => $this->lib->getSet("ssl") );
        }
        else
        {
            $result["response"] = "VALID";
            $result["data"] = array( "brand" => $this->lib->getSet("brandname"), "ssl" => $this->lib->getSet("ssl") );
        }

        $this->output($result);
    }

    public function create($data)
    {
        $result = array(  );
        $device_id = $data->device_id;
        $input = json_decode($data->params);
        $name = $input->name;
        $mobile = str_replace(array( "+", " " ), array( "", "" ), $input->mobile);
        $email = $input->email;
        $bd = $this->lib->startsWith($mobile, "8801");
        if( $bd == 1 ) 
        {
            $mobile = substr($mobile, strlen($mobile) - 11);
        }

        $cd = $this->lib->startsWith($mobile, "008801");
        if( $cd == 1 ) 
        {
            $mobile = substr($mobile, strlen($mobile) - 11);
        }

        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $auto = $this->lib->getSet("register_auto");
        if( $auto == 0 ) 
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => "Sorry! This feature is disabled." );
            $this->output($result);
        }

        if( strlen($name) && strlen($mobile) && strlen($email) ) 
        {
            if( !filter_var($email, FILTER_VALIDATE_EMAIL) ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Please use a valid email address" );
            }
            else
            {
                if( !ctype_digit($mobile) || strlen($mobile) < 10 || 15 < strlen($mobile) || (int) $mobile < 1 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Please enter a valid mobile number" );
                }
                else
                {
                    $eR = $this->db->select("count(*) c")->from("resellers")->where(array( "email" => $email ))->get()->row();
                    $mR = $this->db->select("count(*) c")->from("resellers")->where(array( "mobile" => $mobile ))->get()->row();
                    if( 0 < $eR->c ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "This email address already may have an account with us" );
                    }
                    else
                    {
                        if( 0 < $mR->c ) 
                        {
                            $result["response"] = "INVALID";
                            $result["data"] = array( "msg" => "This mobile number already may have an account with us" );
                        }
                        else
                        {
                            $ins["username"] = $this->escape_str($email);
                            $ins["fullname"] = $this->escape_str($name);
                            $ins["mobile"] = $this->escape_str($mobile);
                            $ins["email"] = $this->escape_str($email);
                            $ins["note"] = "Automatically created through Android App";
                            $ins["balance"] = "0";
                            $ins["status"] = "1";
                            $ins["creationdate"] = date("Y-m-d");
                            $ins["dlimit"] = $this->lib->getSet("daylimit");
                            $passinterval = $this->lib->getSet("pass_interval");
                            $password = $this->randomPassword(10);
                            $ins["password"] = password_hash($password . $this->lib->passKey(), PASSWORD_BCRYPT);
                            $ins["cookie"] = uniqid("QA");
                            $ins["pass_expire"] = date("Y-m-d", strtotime(date("Y-m-d") . "+" . $passinterval . " days"));
                            $otp = $this->lib->getSet("reseller_otp");
                            if( $otp == 0 ) 
                            {
                                $interval = $this->lib->getSet("pin_interval");
                                $pin_len = $this->lib->getSet("pin_len");
                                $genPin = $this->lib->random_numbers($pin_len);
                                $ins["pin_expire"] = date("Y-m-d", strtotime(date("Y-m-d") . "+" . $interval . " days"));
                                $ins["pin"] = password_hash($genPin . $this->lib->passKey(), PASSWORD_BCRYPT);
                            }

                            $sQ = $this->db->query("SELECT sum(type) type FROM services WHERE enable=1");
                            $sR = $sQ->row();
                            $ins["type"] = $sR->type;
                            $ins["admin"] = "1";
                            $ins["parent"] = "-1";
                            $ins["rs5"] = "-1";
                            $ins["rs4"] = "-1";
                            $ins["rs3"] = "-1";
                            $ins["rs2"] = "-1";
                            $ins["user_type"] = "1";
                            $ins["balance"] = "0";
                            $ins["device_id"] = "";
                            $ins["otp_type"] = "15";
                            $ins["otp_key"] = "";
                            $ins["currency"] = $this->lib->getSet("base_currency");
                            $this->db->insert("resellers", $ins);
                            $new_id = $this->db->insert_id();
                            $q = $this->db->get("ratestable");
                            foreach( $q->result() as $row ) 
                            {
                                $rData = array( "res_id" => $new_id, "service_id" => $row->service_id, "type" => $row->type, "prefix" => $row->prefix, "rate" => $row->rate, "commision" => $row->commision, "charge" => $row->charge, "enable" => 1 );
                                $this->db->insert("rates", $rData);
                            }
                            $brandname = $this->lib->getBrand("brandname");
                            $sms_route = $this->lib->getSet("otp_route");
                            $api = $this->lib->smsApi();
                            if( $otp == 0 ) 
                            {
                                $pintxt = "\r\nPIN: " . $genPin;
                            }
                            else
                            {
                                $pintxt = "";
                            }

                            $username = $this->escape_str($email);
                            $msg = "Welcome to " . $brandname . ", Your new account details as\r\nLogin ID: " . $username . "\r\nPassword: " . $password . $pintxt;
                            if( $sms_route == 1 && $api->found == 1 ) 
                            {
                                $txmsg = urlencode($msg);
                                $senderid = substr($brandname, 0, 11);
                                $senderid = urlencode($senderid);
                                $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
                                $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $mobile, (string) $txmsg, "0" );
                                $link = str_replace($uData, $sData, $api->url);
                                $fdata = array(  );
                                $ret = $this->lib->curl_get($link, $fdata);
                            }
                            else
                            {
                                $outbox = array( "rid" => "-1", "receiver" => $mobile, "message" => $msg, "status" => 0 );
                                $this->db->insert("outbox", $outbox);
                            }

                            if( strlen($email) ) 
                            {
                                if( $otp == 0 ) 
                                {
                                    $pintxt = "<br/>PIN: " . $genPin;
                                }
                                else
                                {
                                    $pintxt = "";
                                }

                                $msg = "Hello " . $name . ", <br/>Thanks for creating account with <b>" . $brandname . "</b><br/> Please find your new account details as following: <br/><br/>Username: " . $username . "<br/>Password: " . $password . $pintxt . "<br/><br/>With Thanks<br/>" . $brandname . " Team";
                                $mail = $this->lib->mail();
                                $mail->AddReplyTo("no-reply@" . $domain, $brandname);
                                $mail->SetFrom("no-reply@" . $domain, $brandname);
                                $mail->AddAddress($email, $name);
                                $mail->Subject = "Welcome to " . $brandname;
                                $mail->MsgHTML($msg);
                                $mail->Send();
                            }

                            $ToSubject = "";
                            $adminEmail = $this->lib->getSet("email");
                            $msg = "New customer has signed up successfully, Find new account details as bellow: <br/>Username: " . $username . "<br/>Password: " . $password . "." . $pintxt . ", <br/><br/>Thanks";
                            $mail = $this->lib->mail();
                            $mail->AddReplyTo("no-reply@" . $domain, $brandname);
                            $mail->SetFrom("no-reply@" . $domain, $brandname);
                            $mail->AddAddress($adminEmail, $brandname);
                            $mail->Subject = "New customer has signed up successfully!";
                            $mail->MsgHTML($msg);
                            $mail->Send();
                            $result["response"] = "VALID";
                            $result["data"] = array( "msg" => "Account created successfully", "secrete_key" => $password );
                        }

                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => "Please enter your information" );
        }

        $this->output($result);
    }

    public function login($data)
    {
        $result = array(  );
        $today = date("Y-m-d");
        $device_id = $data->device_id;
        $params = json_decode($data->params);
        $username = $params->login_id;
        $password = $params->secrete_key;
        $otp = $this->lib->getSet("reseller_otp");
        if( $otp == 1 ) 
        {
            $authtype = "OTP";
        }
        else
        {
            if( $otp == 2 ) 
            {
                $authtype = "SMS CODE";
            }
            else
            {
                if( $otp == 3 ) 
                {
                    $authtype = "PIN";
                }

            }

        }

        if( strlen($username) && strlen($password) ) 
        {
            $usersql = "(username='" . $username . "' OR email='" . $username . "')";
            $q = $this->db->select("*");
            $q->from("resellers");
            $q->where($usersql);
            $q->where("status", "1");
            $q->where("pass_expire >=", $today);
            $q->limit(1);
            $query = $q->get();
            if( $query->num_rows() == 1 ) 
            {
                $r = $query->row();
                if( password_verify($password . $this->lib->passKey(), $r->password) ) 
                {
                    if( strlen($r->device_id) ) 
                    {
                        if( $r->device_id == $device_id ) 
                        {
                            $this->lib->dbtbl();
                            $result["response"] = "VALID";
                            $result["data"] = array( "2STEP" => "NONE", "auth_token" => $this->genToken($r, 1) );
                            $this->lib->SaveLogs("UserLogin", "Android: User logged in with a new device", $username);
                        }
                        else
                        {
                            $result["response"] = "INVALID";
                        }

                    }
                    else
                    {
                        if( $otp == 1 && $r->otp_key == "" ) 
                        {
                            $result["response"] = "INVALID";
                            $result["data"] = array( "ERROR" => "Please login via web browser to setup OTP first." );
                            $this->lib->SaveLogs("UserLogin", "Android: User logged in with a new Android device", $username);
                        }
                        else
                        {
                            if( $otp == 2 ) 
                            {
                                $this->sendOtp($r);
                            }

                            $result["response"] = "VALID";
                            $result["data"] = array( "2STEP" => $authtype, "auth_token" => $this->genToken($r, 0) );
                            $this->lib->SaveLogs("UserLogin", "Android: User logged in with a new Android device", $username);
                        }

                    }

                }
                else
                {
                    $pw = substr($password, -3);
                    $this->lib->SaveLogs("FailedLogin", "Android: Login attempt was failed - " . $username . "/******" . $pw, $username);
                    $result["response"] = "INVALID";
                    $result["data"] = array( "ERROR" => "Please enter a valid username or password." );
                }

            }
            else
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "ERROR" => "Please enter a valid username or password." );
            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "ERROR" => "Please enter a valid username or password." );
        }

        $this->output($result);
    }

    public function otp($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $pin = $params->input;
        $tk = $this->verifyToken($auth_token, 0);
        if( $tk["var"] == true ) 
        {
            if( strlen($pin) ) 
            {
                $uRow = $tk["uRow"];
                $device_id = $tk["device_id"];
                $attempt = $tk["attempt"];
                $token_id = $tk["token_id"];
                $otp = $this->lib->getSet("reseller_otp");
                $expire = $this->lib->dateDiff($uRow->pin_expire);
                if( $otp == 2 ) 
                {
                    $expire = 30;
                }

                if( $otp == 1 ) 
                {
                    $totp = $this->lib->totp();
                    $otp_key = $uRow->otp_key;
                    $checkResult = $totp->verifyCode($otp_key, $pin, 0);
                    if( $checkResult == true ) 
                    {
                        $this->lib->dbtbl();
                        $this->db->where("id", $uRow->id)->update("resellers", array( "device_id" => $device_id ));
                        $this->db->where("token_id", $token_id)->update("app_token", array( "challange" => 1 ));
                        $this->db->query("DELETE FROM app_token WHERE last_used < '" . date("Y-m-d H:i:s") . "'");
                        $result["response"] = "VALID";
                        $result["data"] = array( "next" => "dashboard" );
                        $this->lib->SaveLogs("2Step", "Android: User has be authorized with valid OTP CODE", $uRow->username);
                    }
                    else
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Invalid OTP Code" );
                        $this->lib->SaveLogs("2Step", "Android: Invalid OTP CODE Provided", $uRow->username);
                        if( $attempt <= 0 ) 
                        {
                            $this->lib->inActive_all($uRow->id, $uRow->user_type);
                            $this->db->query("DELETE FROM app_token WHERE token_id='" . $token_id . "'");
                            $this->lib->SaveLogs("2Step", "Android: User has been deactivated due to invalid OTP CODE", $uRow->username);
                            $result["response"] = "BLOCKED";
                            $result["data"] = array( "msg" => "Maximum retry limit exist" );
                        }
                        else
                        {
                            $this->db->where("token_id", $token_id)->update("app_token", array( "attempt" => $attempt - 1 ));
                        }

                    }

                }
                else
                {
                    if( password_verify($pin . $this->lib->passKey(), $uRow->pin) && 1 <= $expire ) 
                    {
                        $this->lib->dbtbl();
                        $this->db->where("id", $uRow->id)->update("resellers", array( "device_id" => $device_id ));
                        $this->db->where("token_id", $token_id)->update("app_token", array( "challange" => 1 ));
                        $this->db->query("DELETE FROM app_token WHERE last_used < '" . date("Y-m-d H:i:s") . "'");
                        $result["response"] = "VALID";
                        $result["data"] = array( "next" => "dashboard" );
                        $this->lib->SaveLogs("2Step", "Android: User has be authorized with valid SMS CODE / PIN", $uRow->username);
                    }
                    else
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Invalid PIN/OTP" );
                        $this->lib->SaveLogs("2Step", "Android: Invalid PIN/CODE Provided", $uRow->username);
                        if( $attempt <= 0 ) 
                        {
                            $this->lib->inActive_all($uRow->id, $uRow->user_type);
                            $this->db->query("DELETE FROM app_token WHERE token_id='" . $token_id . "'");
                            $this->lib->SaveLogs("2Step", "Android: User has been deactivated due to invalid PIN/CODE", $uRow->username);
                            $result["response"] = "BLOCKED";
                            $result["data"] = array( "msg" => "Maximum retry limit exist" );
                        }
                        else
                        {
                            $this->db->where("token_id", $token_id)->update("app_token", array( "attempt" => $attempt - 1 ));
                        }

                    }

                }

            }
            else
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "OTP/PIN is required." );
            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function dashboard($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $services = $this->myServices($uRow->type);
            $notice = $this->lib->getSet("newsScroll");
            $otp = $this->lib->getSet("reseller_otp");
            if( $otp == 3 ) 
            {
                $pinexpire = $this->lib->dateDiff($uRow->pin_expire);
                if( $pinexpire <= 5 ) 
                {
                    $notice = "Your pin will expire after " . $pinexpire . " days. Please change your pin";
                }

            }

            $passexpire = $this->lib->dateDiff($uRow->pass_expire);
            if( $passexpire <= 6 ) 
            {
                $notice = "Your pin will expire after " . $passexpire . " days. Please change your password";
            }

            $result["response"] = "VALID";
            $result["data"] = array( "login" => true, "username" => $uRow->username, "fullname" => $uRow->fullname, "mobile" => $uRow->mobile, "mobile" => $uRow->email, "type" => $uRow->user_type, "balance" => $this->lib->viewAmount($uRow->balance, $uRow->currency), "notice" => $notice, "services" => $services );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function balance($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token, 1);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $result["response"] = "VALID";
            $result["data"] = array( "balance" => $this->lib->viewAmount($uRow->balance, $uRow->currency) );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function sms($data)
    {
        $result = array(  );
        $result["response"] = "VALID";
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $number = $params->number;
        $sender = $params->sender;
        $sender = substr($sender, 0, 11);
        $text = $params->text;
        $pin = $params->pin;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $sQuery = $this->db->get_where("services", array( "spaceuri" => $data->action, "enable" => 1 ));
            if( $sQuery->num_rows() == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Service not available right now" );
            }
            else
            {
                $sRow = $sQuery->row();
                $otp = $this->lib->getSet("reseller_otp");
                $mask = $this->lib->isMask($uRow->id);
                if( $mask == 0 ) 
                {
                    $sender = $uRow->fullname;
                    $sender = substr($sender, 0, 11);
                }

                $amount = ceil(strlen(utf8_decode($text)) / 160);
                $var = $this->lib->verify_destination($sRow->type, $number, $amount, 0, $uRow->id, $uRow->user_type);
                if( $var["verify_dst"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Number format invalid or not allowed." );
                }

                if( $var["verify_bal"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! Not enough balance." );
                }

                if( $var["verify_cst"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
                }

                if( $result["response"] == "VALID" ) 
                {
                    $response = $this->lib->sendSMS($number, $sender, $text, $uRow->id, $uRow->user_type);
                    if( $response == 1 ) 
                    {
                        $result["response"] = "VALID";
                        $result["data"] = array( "msg" => "Message was sent successfully." );
                    }
                    else
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Could not send message due to internal error." );
                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function billpay($data)
    {
        $result = array(  );
        $result["response"] = "VALID";
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $provider = $params->provider;
        $ac_title = $params->ac_title;
        $ac_area = $params->ac_area;
        $receiver = $params->receiver;
        $amount = $params->amount;
        $note = $params->note;
        $pin = $params->pin;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $sQuery = $this->db->get_where("services", array( "spaceuri" => $data->action, "enable" => 1 ));
            if( $sQuery->num_rows() == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Service not available right now" );
            }
            else
            {
                $sRow = $sQuery->row();
                $otp = $this->lib->getSet("reseller_otp");
                $var = $this->lib->verify_billpay($provider, $amount, $uRow->id, $uRow->user_type);
                if( $var["verify_dst"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! You are not allowed to use Billpay service." );
                }

                if( $var["verify_bal"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! Not enough balance." );
                }

                if( $var["verify_cst"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
                }

                if( $result["response"] == "VALID" ) 
                {
                    $this->session->set_userdata("id", $uRow->id);
                    $this->session->set_userdata("user_type", $uRow->user_type);
                    $newid = $this->lib->billpay($provider, $receiver, $amount, $note, $ac_area, $ac_title);
                    if( strlen($newid) ) 
                    {
                        $result["response"] = "VALID";
                        $result["data"] = array( "msg" => "Request processed successfully." );
                    }
                    else
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Sorry! Could complete the request." );
                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function prepaidcard($data)
    {
        $result = array(  );
        $result["response"] = "VALID";
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $opt = $params->opt;
        $amt = $params->amt;
        $type = $params->type;
        $pin = $params->pin;
        $receiver = $params->receiver;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $sQuery = $this->db->get_where("services", array( "spaceuri" => $data->action, "enable" => 1 ));
            if( $sQuery->num_rows() == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Service not available right now" );
            }
            else
            {
                $sRow = $sQuery->row();
                $otp = $this->lib->getSet("reseller_otp");
                $is = $this->lib->isAvailable($opt, $amt, $type);
                if( $is < 1 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! Your requested card is not available." );
                }

                $var = $this->lib->verify_card($opt, $amt, $uRow->id, $uRow->user_type);
                if( $var["verify_dst"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! You are not allowed to buy card." );
                }

                if( $var["verify_bal"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! Not enough balance." );
                }

                if( $var["verify_cst"] == 0 ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
                }

                if( $result["response"] == "VALID" ) 
                {
                    $this->session->set_userdata("id", $uRow->id);
                    $this->session->set_userdata("user_type", $uRow->user_type);
                    $newid = $this->lib->buycard($opt, $amt, $type, $receiver);
                    if( strlen($newid) ) 
                    {
                        $tQ = $this->db->get_where("card_history", array( "id" => $newid ));
                        $tRow = $tQ->row();
                        $card = $this->lib->myCard($tRow->card_id);
                        $cData["operator"] = $this->lib->opTitle($tRow->opt_id);
                        $cData["type"] = $tRow->type;
                        $cData["amount"] = $this->lib->getAmount($tRow->amnt_id);
                        $cData["serial"] = $card->serial;
                        $cData["pin"] = $card->pin;
                        $result["response"] = "VALID";
                        $result["data"] = array( "msg" => "Card purchase was successful.", "card" => $cData );
                    }
                    else
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Sorry! Could complete the request." );
                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function request($data)
    {
        if( $data->action == "sms" ) 
        {
            $this->sms($data);
        }
        else
        {
            if( $data->action == "billpay" ) 
            {
                $this->billpay($data);
            }
            else
            {
                if( $data->action == "prepaidcard" ) 
                {
                    $this->prepaidcard($data);
                }
                else
                {
                    $result = array(  );
                    $result["response"] = "VALID";
                    $auth_token = $data->auth_token;
                    $params = json_decode($data->params);
                    $number = $params->number;
                    $amount = $params->amount;
                    $type = $params->type;
                    $pin = $params->pin;
                    $cid = $params->country;
                    $oid = $params->operator;
                    $photoid = $params->photoid;
                    $sendername = $params->sendername;
                    $receivername = $params->receivername;
                    $photofile = $params->photofile;
                    if( strlen($photofile) ) 
                    {
                        $filename = md5(time()) . "." . explode(":", $photofile)[0];
                        $ifp = fopen("../photoid/" . $filename, "wb");
                        fwrite($ifp, base64_decode(explode(":", $photofile)[1]));
                        fclose($ifp);
                        $photofile = $filename;
                    }

                    if( !strlen($type) ) 
                    {
                        $type = 1;
                    }

                    $tk = $this->verifyToken($auth_token);
                    if( $tk["var"] == true ) 
                    {
                        $uRow = $tk["uRow"];
                        $sQuery = $this->db->get_where("services", array( "spaceuri" => $data->action, "enable" => 1 ));
                        if( $sQuery->num_rows() == 0 ) 
                        {
                            $result["response"] = "INVALID";
                            $result["data"] = array( "msg" => "Service not available right now" );
                        }
                        else
                        {
                            $sRow = $sQuery->row();
                            $otp = $this->lib->getSet("reseller_otp");
                            if( $amount < $sRow->min_amnt || $sRow->max_amnt < $amount ) 
                            {
                                $result["response"] = "INVALID";
                                $result["data"] = array( "msg" => "Amount must between " . $sRow->min_amnt . " and " . $sRow->max_amnt );
                            }

                            if( $sRow->require_pid == 1 && $photoid == "" ) 
                            {
                                $result["response"] = "INVALID";
                                $result["data"] = array( "msg" => "NID/PhotoID is required." );
                            }

                            if( $sRow->require_sender == 1 && $sendername == "" ) 
                            {
                                $result["response"] = "INVALID";
                                $result["data"] = array( "msg" => "Sendername is required." );
                            }

                            $interbal = $this->lib->getSet("req_interval");
                            $time = $this->lib->inTime($number, $sRow->type, $interbal);
                            if( !$time ) 
                            {
                                $result["response"] = "INVALID";
                                $result["data"] = array( "msg" => "Can't process! Please try after " . $interbal . " minute." );
                            }

                            if( $result["response"] == "VALID" ) 
                            {
                                if( $sRow->type == 32 ) 
                                {
                                    $var = $this->lib->verify_destination($sRow->type, $number, $amount, $type, $uRow->id, $uRow->user_type, 1);
                                }
                                else
                                {
                                    $var = $this->lib->verify_destination($sRow->type, $number, $amount, $type, $uRow->id, $uRow->user_type);
                                }

                                if( $var["verify_dst"] == 0 ) 
                                {
                                    $result["response"] = "INVALID";
                                    $result["data"] = array( "msg" => "Number format invalid or not allowed." );
                                }

                                if( $var["verify_bal"] == 0 ) 
                                {
                                    $result["response"] = "INVALID";
                                    $result["data"] = array( "msg" => "Sorry! Not enough balance." );
                                }

                                if( $var["verify_cst"] == 0 ) 
                                {
                                    $result["response"] = "INVALID";
                                    $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
                                }

                                if( $result["response"] == "VALID" ) 
                                {
                                    $insert_id = $this->lib->request($sRow->type, $number, $amount, $type, $uRow->id, $uRow->user_type, $cid, $oid, $photoid, $sendername, $receivername, $photofile);
                                    if( strlen($insert_id) ) 
                                    {
                                        $result["response"] = "VALID";
                                        $result["data"] = array( "msg" => "Request processed successfully" );
                                    }
                                    else
                                    {
                                        $result["response"] = "INVALID";
                                        $result["data"] = array( "msg" => "Sorry! Something went wrong with server" );
                                    }

                                }

                            }

                        }

                    }
                    else
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => $tk["msg"] );
                    }

                    $this->output($result);
                }

            }

        }

    }

    public function global_topup($data)
    {
        $result = array(  );
        $result["response"] = "VALID";
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $country = $params->country;
        $number = $params->number;
        $operator = $params->operator;
        $package = $params->package;
        $type = $params->type;
        $pin = $params->pin;
        if( !strlen($type) ) 
        {
            $type = 1;
        }

        $number = str_replace(array( "+", "-", " " ), array( "", "", "" ), $number);
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $sQuery = $this->db->get_where("services", array( "spaceuri" => "intopup", "enable" => 1 ));
            if( $sQuery->num_rows() == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Service not available right now" );
            }
            else
            {
                $sRow = $sQuery->row();
                $interbal = $this->lib->getSet("req_interval");
                $time = $this->lib->inTime($number, $sRow->type, $interbal);
                if( !$time ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Can't process! Please try after " . $interbal . " minute." );
                }

                if( $result["response"] == "VALID" ) 
                {
                    $pack = $this->lib->getIntPack($package);
                    $var = $this->lib->verify_global($number, $pack, $type, $uRow->id, $uRow->user_type);
                    if( $var["verify_dst"] == 0 ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Sorry! Rate prefix was not found." );
                    }

                    if( $var["verify_bal"] == 0 ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Sorry! Not enough balance." );
                    }

                    if( $var["verify_cst"] == 0 ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
                    }

                    if( $result["response"] == "VALID" ) 
                    {
                        $insert_id = $this->lib->request_global(512, $package, $number, $type, $uRow->id, $uRow->user_type);
                        if( strlen($insert_id) ) 
                        {
                            $result["response"] = "VALID";
                            $result["data"] = array( "msg" => "Request processed successfully" );
                        }
                        else
                        {
                            $result["response"] = "INVALID";
                            $result["data"] = array( "msg" => "Sorry! Something went wrong with server" );
                        }

                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function history($data)
    {
        $result = array(  );
        $limit = 10;
        $logs = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $uri = $params->uri;
        $number = $params->number;
        $offset = $params->limit;
        if( !strlen($offset) ) 
        {
            $offset = 0;
        }

        $table = $this->lib->req_tbl();
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            if( $uri == "requests" ) 
            {
                if( strlen($number) ) 
                {
                    $numSql = "AND receiver LIKE '" . $number . "%'";
                }
                else
                {
                    $numSql = "";
                }

                $q = $this->db->select("id, receiver, type, amount, cost, bal, service_id, status, transactionid, last_update")->from($table)->limit($limit, $offset)->order_by("req_time", "desc");
                $q->where("sender", $uRow->id);
                if( strlen($number) ) 
                {
                    $q->like("receiver", $number, "after");
                }

                $query = $q->get();
                foreach( $query->result() as $row ) 
                {
                    $TrxID = str_replace("TrxID: ", "", $row->transactionid);
                    $TrxID = str_replace(" Sender: ", "/", $TrxID);
                    $tmp = array(  );
                    $tmp["service"] = $this->srvUri($row->service_id);
                    $tmp["number"] = $row->receiver . " (" . $this->lib->convert_type($row->service_id, $row->type) . ")";
                    $tmp["line1"] = "AMOUNT: " . $row->amount . " - COST: " . $this->lib->viewAmount($row->cost, $uRow->currency) . " - BAL: " . $this->_viewBal($row->bal, $uRow->currency) . "";
                    $tmp["line2"] = "TrxID: " . $TrxID;
                    $tmp["status"] = $this->fStatus($row->status);
                    $tmp["showDate"] = $this->showDate($row->last_update);
                    $logs[] = $tmp;
                }
            }

            if( $uri == "sms" ) 
            {
                $q = $this->db->select("id, receiver, sender_id, sms, cost, bal, status, send_time")->from("sms_req")->limit($limit, $offset)->order_by("send_time", "desc");
                $q->where("sender", $uRow->id);
                if( strlen($number) ) 
                {
                    $q->like("receiver", $number, "after");
                }

                $query = $q->get();
                foreach( $query->result() as $row ) 
                {
                    $tmp = array(  );
                    $tmp["icon"] = $row->sender_id;
                    $tmp["number"] = $row->receiver;
                    $tmp["line1"] = "SenderID : " . $row->sender_id . " - Cost: " . $this->lib->viewAmount($row->cost, $uRow->currency) . " BAL: " . $this->_viewBal($row->bal, $uRow->currency);
                    $tmp["line2"] = (string) $row->sms;
                    $tmp["status"] = $this->fStatus($row->status);
                    $tmp["showDate"] = $this->showDate($row->send_time);
                    $logs[] = $tmp;
                }
            }

            if( $uri == "prepaidcard" ) 
            {
                $q = $this->db->select("card_id,opt_id,amnt_id,type,amount,cost,bal,date_update")->from("card_history")->limit($limit, $offset)->order_by("date_update", "desc");
                $q->where("sender", $uRow->id);
                $query = $q->get();
                foreach( $query->result() as $row ) 
                {
                    $tmp = array(  );
                    $card = $this->lib->myCard($row->card_id);
                    $tmp["icon"] = $this->lib->opTitle($row->opt_id);
                    $tmp["number"] = $this->lib->opTitle($row->opt_id);
                    $tmp["line1"] = "AMOUNT:" . $this->lib->getAmount($row->amnt_id) . " - COST: " . $this->lib->viewAmount($row->cost, $uRow->currency) . " - BAL: " . $this->_viewBal($row->bal, $uRow->currency);
                    $tmp["line2"] = "SL: " . $card->serial . " PIN: " . $card->pin;
                    $tmp["status"] = "SUCCESS";
                    $tmp["showDate"] = $this->showDate($row->date_update);
                    $logs[] = $tmp;
                }
            }

            if( $uri == "moneytransfer" ) 
            {
                $q = $this->db->select("receiver,receivername,amount,cost,bal,status,last_update,bid,cid,kycfrom,kycto,transactionid")->from("banktransfer")->where("type", "TRANSFER")->limit($limit, $offset)->order_by("last_update", "desc");
                $q->where("sender", $uRow->id);
                $query = $q->get();
                foreach( $query->result() as $row ) 
                {
                    $tmp = array(  );
                    $provider = "BANK TRANSFER";
                    $tmp["icon"] = $provider;
                    $tmp["provider"] = $this->lib->bankName($row->bid) . " - " . $this->lib->countryName($row->cid);
                    $tmp["number"] = $row->receivername . " (" . $row->receiver . ")";
                    $tmp["line1"] = "AMOUNT: " . $row->amount . " - COST: " . $this->lib->viewAmount($row->cost, $uRow->currency) . " - BAL: " . $this->_viewBal($row->bal, $uRow->currency);
                    $tmp["line2"] = "TrxID: " . $row->transactionid;
                    $tmp["sender"] = array( "id" => $row->kycfrom, "fullname" => $this->lib->getKyc($row->kycfrom) );
                    $tmp["receiver"] = array( "id" => $row->kycto, "fullname" => $this->lib->getKyc($row->kycto) );
                    $tmp["status"] = $this->fStatus($row->status);
                    $tmp["showDate"] = $this->showDate($row->last_update);
                    $logs[] = $tmp;
                }
            }

            if( $uri == "pintransfer" ) 
            {
                $q = $this->db->select("receiver,receivername,amount,cost,bal,status,last_update,bid,cid,kycfrom,kycto,transactionid")->from("banktransfer")->where("type", "PIN")->limit($limit, $offset)->order_by("last_update", "desc");
                $q->where("sender", $uRow->id);
                $query = $q->get();
                foreach( $query->result() as $row ) 
                {
                    $tmp = array(  );
                    $provider = "PIN";
                    $tmp["icon"] = $provider;
                    $tmp["provider"] = $this->lib->countryName($row->cid);
                    $tmp["number"] = $row->receiver;
                    $tmp["line1"] = "AMOUNT: " . $row->amount . " - COST: " . $this->lib->viewAmount($row->cost, $uRow->currency) . " - BAL: " . $this->_viewBal($row->bal, $uRow->currency);
                    $tmp["line2"] = "TrxID: " . $row->transactionid;
                    $tmp["status"] = $this->fStatus($row->status);
                    $tmp["sender"] = array( "id" => $row->kycfrom, "fullname" => $this->lib->getKyc($row->kycfrom) );
                    $tmp["receiver"] = array( "id" => $row->kycto, "fullname" => $this->lib->getKyc($row->kycto) );
                    $tmp["showDate"] = $this->showDate($row->last_update);
                    $logs[] = $tmp;
                }
            }

            $result["response"] = "VALID";
            $result["data"] = array( "history" => $logs );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
        return NULL;
    }

    public function report($data)
    {
        $table = "request_view";
        $result = array(  );
        $limit = 10;
        $logs = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $type = $uRow->user_type;
            if( $type == 1 ) 
            {
                $type = "";
                $rsQl = "sender='" . $uRow->id . "'";
            }
            else
            {
                $rsQl = "(sender='" . $uRow->id . "' OR rs" . $type . "='" . $uRow->id . "')";
            }

            $q = $this->db->query("SELECT sum(amount) amount, sum(if( sender=" . $uRow->id . ", cost, cost" . $type . "))as cost, service_id FROM " . $table . " WHERE " . $rsQl . " AND status!=3 GROUP BY service_id, sender\n            UNION\n            SELECT sum(amount) amount, sum(if( sender='" . $uRow->id . "', cost, cost" . $type . "))as cost, 4 as service_id FROM banktransfer WHERE " . $rsQl . " AND status!=3 GROUP BY sender\n            UNION\n            SELECT count(id) as amount, sum(if( sender='" . $uRow->id . "', cost, cost" . $type . "))as cost, 1 as service_id FROM sms_req WHERE " . $rsQl . " GROUP BY sender\n            UNION\n            SELECT sum(amount) amount, sum(if( sender='" . $uRow->id . "', cost, cost" . $type . "))as cost, 2 as service_id FROM card_history WHERE " . $rsQl . " GROUP BY sender\n            ");
            $tcost = 0;
            $tamount = 0;
            foreach( $q->result() as $row ) 
            {
                $tcost += $row->cost;
                $tamount += $row->amount;
                $logs[] = array( "uri" => $this->srvUri($row->service_id), "title" => $this->lib->serTtlById($row->service_id), "amount" => $row->amount, "cost" => $this->lib->viewAmount($row->cost, $uRow->currency) );
            }
            $result["response"] = "VALID";
            $result["data"] = array( "report" => $logs, "total" => $this->lib->viewAmount($tcost, $uRow->currency) );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
        return NULL;
    }

    public function payments($data)
    {
        $result = array(  );
        $logs = array(  );
        $limit = 10;
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $offset = $params->limit;
        if( !strlen($offset) ) 
        {
            $offset = 0;
        }

        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $query = $this->db->select("note, amount, type, logtime")->from("flexi_transfer_log")->limit($limit, $offset)->order_by("logtime", "desc")->where("bal_to", $uRow->id)->where("type !=", "Canceled")->get();
            foreach( $query->result() as $row ) 
            {
                $tmp = array(  );
                if( $row->type == "transfer" ) 
                {
                    $title = "Wallet Balance";
                }
                else
                {
                    $title = "Return Balance(-)";
                }

                $tmp["title"] = $title;
                $tmp["note"] = $row->note;
                $tmp["amount"] = $this->lib->viewAmount($row->amount, $uRow->currency);
                $tmp["showDate"] = $this->showDate($row->logtime);
                $logs[] = $tmp;
            }
            $pQ = $this->db->query("SELECT sum(amount) total FROM flexi_transfer_log WHERE bal_to='" . $uRow->id . "' AND type='transfer'");
            $rQ = $this->db->query("SELECT sum(amount) total FROM flexi_transfer_log WHERE bal_to='" . $uRow->id . "' AND type='return'");
            $pR = $pQ->row();
            $rR = $rQ->row();
            $total = $this->lib->viewAmount($pR->total - $rR->total, $uRow->currency);
            $result["response"] = "VALID";
            $result["data"] = array( "payments" => $logs, "total" => $total );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
        return NULL;
    }

    public function support($data)
    {
        $result = array(  );
        $limit = 10;
        $logs = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $method = $params->method;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            switch( $method ) 
            {
                case "list":
                    $offset = $params->limit;
                    if( !strlen($offset) ) 
                    {
                        $offset = 0;
                    }

                    $query = $this->db->select("id, title, message, status, last_update")->from("support_ticket")->limit($limit, $offset)->order_by("id", "desc")->order_by("status", "asc")->where("sender", $uRow->id)->get();
                    foreach( $query->result() as $row ) 
                    {
                        $tmp["id"] = $row->id;
                        $tmp["title"] = $row->title;
                        $tmp["message"] = $row->message;
                        $tmp["status"] = $this->ttSts($row->status);
                        $tmp["showDate"] = $this->showDate($row->last_update);
                        $logs[] = $tmp;
                    }
                    $result["response"] = "VALID";
                    $result["data"] = array( "list" => $logs );
                    break;
                case "new":
                    $title = $params->title;
                    $msg = $params->msg;
                    $ins = array( "title" => $title, "message" => $msg, "sender" => $uRow->id, "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "status" => 1 );
                    $this->db->insert("support_ticket", $ins);
                    $new_id = $this->db->insert_id();
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "Your message was received successfully.", "id" => $new_id );
                    break;
                case "view":
                    $id = $params->id;
                    $position = "left";
                    $row = $this->lib->getTicket($id);
                    $reply = $this->lib->getReplys($id);
                    if( $row->sender == $uRow->id ) 
                    {
                        $position = "right";
                    }

                    $logs[] = array( "sender" => $this->lib->thisUser($row->sender), "time" => $this->showDate($row->last_update), "msg" => $row->message, "position" => $position );
                    $position = "left";
                    foreach( $reply as $rp ) 
                    {
                        if( $rp->sender == $uRow->id ) 
                        {
                            $position = "right";
                        }

                        if( $rp->isadmin == 1 ) 
                        {
                            $position = "left";
                        }

                        $logs[] = array( "sender" => $this->lib->addedBy($rp->sender, $rp->isadmin), "time" => $this->showDate($rp->last_update), "msg" => $rp->message, "position" => $position );
                    }
                    $result["response"] = "VALID";
                    $result["data"] = array( "title" => $row->title, "logs" => $logs );
                    break;
                case "reply":
                    $id = $params->id;
                    $msg = $params->msg;
                    $ins = array( "tid" => $id, "message" => $msg, "sender" => $uRow->id, "is_read" => 0 );
                    $this->db->insert("support_reply", $ins);
                    $this->db->query("UPDATE support_ticket SET status='2' WHERE id='" . $id . "' LIMIT 1");
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "Your message was received successfully." );
                    break;
                default:
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "No Method found" );
            }
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function profile($data)
    {
        $result = array(  );
        $logs = array(  );
        $limit = 10;
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $profile = array( "Fullname" => $uRow->fullname, "Email Address" => $uRow->email, "Mobile Number" => $uRow->mobile, "SMS Masking" => ($uRow->mask == 1 ? "Allowed" : "Disabled") );
            if( $uRow->parent == "-1" ) 
            {
                $profile["Daily Limit"] = $uRow->dlimit;
            }

            $profile["Password Expire"] = date("d M y g:i A", strtotime($uRow->pass_expire)) . " (" . $this->lib->dateDiff($uRow->pass_expire) . " days)";
            if( $uRow->pin_expire != "0000-00-00" ) 
            {
                $profile["PIN Expire"] = date("d M y g:i A", strtotime($uRow->pin_expire)) . " (" . $this->lib->dateDiff($uRow->pin_expire) . " days)";
            }

            $profile["Created"] = date("d M y g:i A", strtotime($uRow->creationdate));
            $profile["Last Login"] = date("d M y g:i A", strtotime($uRow->last_login));
            $result["response"] = "VALID";
            $result["data"] = array( "profile" => $profile );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function pin($data)
    {
        $result = array(  );
        $logs = array(  );
        $limit = 10;
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $current = $params->current;
        $new = $params->new;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $len = $this->lib->getSet("pin_len");
            if( strlen($new) != $len ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Pin length must be " . $len . "." );
            }
            else
            {
                if( $current == $new ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "New pin must be different from current pin." );
                }
                else
                {
                    if( !password_verify($current . $this->lib->passKey(), $uRow->pin) ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Current pin dose not matched." );
                    }
                    else
                    {
                        $interval = $this->lib->getSet("pin_interval");
                        $today = date("Y-m-d");
                        $pin_expire = date("Y-m-d", strtotime($today . " + " . $interval . " days"));
                        $udata = array( "pin" => password_hash($new . $this->lib->passKey(), PASSWORD_BCRYPT), "pin_expire" => $pin_expire );
                        $this->db->where("id", $uRow->id);
                        $this->db->update("resellers", $udata);
                        $this->lib->SaveLogs("PIN", "User changed pin using android app", $uRow->username);
                        $result["response"] = "VALID";
                        $result["data"] = array( "msg" => "Your pin just changed successfully" );
                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function password($data)
    {
        $result = array(  );
        $logs = array(  );
        $limit = 10;
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $current = $params->current;
        $new = $params->new;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $complex = $this->_complex($new);
            if( strlen($complex) ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => $complex );
            }
            else
            {
                if( $current == $new ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "New password must be different from current password." );
                }
                else
                {
                    if( !password_verify($current . $this->lib->passKey(), $uRow->password) ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "Current password dose not matched." );
                    }
                    else
                    {
                        $today = date("Y-m-d");
                        $interval = $this->lib->getSet("pass_interval");
                        $pass_expire = date("Y-m-d", strtotime($today . " + " . $interval . " days"));
                        $password = password_hash($new . $this->lib->passKey(), PASSWORD_BCRYPT);
                        $udata = array( "password" => $password, "cookie" => uniqid("QA"), "pass_expire" => $pass_expire, "device_id" => "" );
                        $this->db->where("id", $uRow->id);
                        $this->db->update("resellers", $udata);
                        $this->lib->SaveLogs("Password", "User changed his password using android app", $uRow->username);
                        $result["response"] = "VALID";
                        $result["data"] = array( "msg" => "Your password just changed successfully. Please login again with your new password" );
                    }

                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function voucher($data)
    {
        $result = array(  );
        $logs = array(  );
        $limit = 10;
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $sl = $params->sl;
        $epin = $params->epin;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $result["response"] = "VALID";
            if( strlen($sl) != 8 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Invalid serial no length" );
            }

            if( strlen($epin) != 16 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Invalid epin number length" );
            }

            if( $result["response"] == "VALID" ) 
            {
                $verify = $this->_validePin($sl, $epin, $uRow->id);
                if( strlen($verify) ) 
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => $verify );
                }
                else
                {
                    $epin = str_replace(" ", "", $epin);
                    $today = date("Y-m-d H:i:s");
                    $pQ = $this->db->select("*")->from("epin_list")->where("epin", $epin)->where("serial", $sl)->where("status", 1)->where("expiredate >", $today)->limit(1)->get();
                    if( $pQ->num_rows() == 0 ) 
                    {
                        $result["response"] = "INVALID";
                        $result["data"] = array( "msg" => "INVALID EPIN OR SERIAL" );
                        $this->output($result);
                    }

                    $r = $pQ->row();
                    if( $uRow->parent != "-1" ) 
                    {
                        redirect("main?sk=access");
                    }

                    $this->lib->addBal($uRow->id, $r->amount);
                    $last_update = date("Y-m-d H:i:s");
                    $dataIns = array( "bal_from" => 1, "byadmin" => 1, "bal_to" => $uRow->id, "amount" => $r->amount, "actual" => $this->lib->getBal($uRow->id), "type" => "transfer", "logtime" => date("Y-m-d H:i:s"), "note" => "ePin serial: " . $r->serial );
                    $ins = $this->db->insert("flexi_transfer_log", $dataIns);
                    $this->db->query("UPDATE epin_list SET status='3',rsid='" . $uRow->id . "',lastupdate='" . $last_update . "' WHERE id='" . $r->id . "' LIMIT 1");
                    $msg = "Reseller: " . $uRow->username . "(" . $uRow->user_type . ") added balance amount: " . $r->amount . " using ePin serial no:" . $r->serial;
                    $this->lib->SaveLogs("Fund Add", $msg, $uRow->username);
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "ePin Voucher redeemed successfully" );
                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function forgot($data)
    {
        $result = array(  );
        $device_id = $data->device_id;
        $params = json_decode($data->params);
        $email = $params->email;
        $mobile = str_replace(array( "+", " " ), array( "", "" ), $params->mobile);
        if( strlen($email) && strlen($mobile) ) 
        {
            $q = $this->db->select("id,fullname,username,dlimit,rs5,rs4,rs3,rs2");
            $q->from("resellers");
            $q->where("mobile", $mobile);
            $q->where("email", $email);
            $q->where("device_id", $device_id);
            $q->where("status", "1");
            $q->limit(1);
            $query = $q->get();
            if( $query->num_rows() == 1 ) 
            {
                $r = $query->row();
                $dLimit = $this->lib->getSet("daylimit");
                if( $r->dlimit <= $dLimit ) 
                {
                    $passinterval = $this->lib->getSet("pass_interval");
                    $password = $this->randomPassword(10);
                    $upd["password"] = password_hash($password . $this->lib->passKey(), PASSWORD_BCRYPT);
                    $upd["cookie"] = uniqid("QA");
                    $upd["pass_expire"] = date("Y-m-d", strtotime(date("Y-m-d") . "+" . $passinterval . " days"));
                    $this->db->where("id", $r->id);
                    $this->db->update("resellers", $upd);
                    $this->lib->SaveLogs("PWReset", "Android: User reset his password using forgot password", $r->username);
                    $brand = $this->lib->getSet("brandname");
                    $msg = "Your new password for " . $brand . " is " . $password . " \r\nPlease change this password after first login";
                    $this->notify_sms($msg, $mobile);
                    $msg = "Hello " . $r->fullname . ",<br/>Your new password for " . $brand . " account login as bellow.<br/><br/><b>Password: " . $password . " <br/>Please change this password after first login.</b> <br/><br/>Thanks - " . $brand;
                    $this->notify_email($msg, $email, (string) $brand . ": Password reset successful");
                    $adminemail = $this->lib->getSet("email");
                    $this->notify_email("Android: " . $r->username . " reset his password using forgot password", $adminemail, (string) $brand . ": Password reset notification");
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "Password reset successful. Please check your sms & email inbox for new password." );
                }
                else
                {
                    $ins = array( "title" => "Password reset request", "message" => "Please reset my password. I just verified my mobile number: " . $mobile . " & email address: " . $email, "sender" => $r->id, "rs5" => $r->rs5, "rs4" => $r->rs4, "rs3" => $r->rs3, "rs2" => $r->rs2, "status" => 1 );
                    $this->db->insert("support_ticket", $ins);
                    $new_id = $this->db->insert_id();
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "We just received your password reset request. Please check back your inbox after a while." );
                }

            }
            else
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry no account was found with these information" );
            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => "Please provide valid email and mobile number" );
        }

        $this->output($result);
    }

    public function global_country($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $cid = $this->lib->getDefaultCountry();
            $r = $this->db->get_where("countries", array( "id" => $cid ))->row();
            $country = $this->db->select("id, name, phonecode, iso_alpha2 isocode")->from("countries")->get()->result();
            $result["response"] = "VALID";
            $result["data"] = array( "code" => $r->phonecode, "country" => $country );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function global_opt($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $cid = $params->cid;
        $number = $params->number;
        $number = str_replace(array( "+", "-", " " ), array( "", "", "" ), $number);
        $cRow = $this->db->get_where("countries", array( "id" => $cid ))->row();
        $country = $cRow->iso_alpha2;
        $packtype = "top up";
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            if( strlen($number) && strlen($country) ) 
            {
                $url = $this->lib->globalSet("api_url") . "web/api/check-number/" . $number . "/" . $country;
                $opres = $this->lib->curl_get($url, array(  ));
                $op = json_decode($opres);
                if( $op->status == "valid" ) 
                {
                    $opt = $this->db->query("SELECT code,title FROM operatorlist WHERE country='" . $cid . "' ORDER BY title ASC")->result();
                    $pQ = $this->db->select("id,title")->from("global_package");
                    $pQ->where("country", $cid);
                    $pQ->where("operator", $op->opcode);
                    $pQ->like("title", $packtype);
                    if( strlen($op->city) && $packtype == "internet" ) 
                    {
                        $pQ->where("city", $op->city);
                    }

                    $pack = $pQ->get()->result();
                    $result["response"] = "VALID";
                    $result["data"] = array( "operators" => $opt, "default" => $op->opcode, "city" => $op->city, "package" => $pack );
                }
                else
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "This is not a valid mobile number." );
                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function global_pack($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $cid = $params->cid;
        $number = $params->number;
        $operator = $params->operator;
        $packtype = $params->packtype;
        $city = $params->city;
        $number = str_replace(array( "+", "-", " " ), array( "", "", "" ), $number);
        $cRow = $this->db->get_where("countries", array( "id" => $cid ))->row();
        $country = $cRow->iso_alpha2;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $pQ = $this->db->select("id,title")->from("global_package");
            $pQ->where("country", $cid);
            $pQ->where("operator", $operator);
            $pQ->like("title", $packtype);
            if( strlen($city) && $packtype == "internet" ) 
            {
                $pQ->where("city", $city);
            }

            $pack = $pQ->get()->result();
            $result["response"] = "VALID";
            $result["data"] = array( "package" => $pack );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function card_opt($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $result["response"] = "VALID";
            $result["data"] = array( "operator" => $this->lib->getOptList() );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function card_amount($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $opt = $params->opt;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $amounts = $this->db->select("id,amount")->from("card_amount")->where("opt", $opt)->order_by("amount", "asc")->get()->result();
            $result["response"] = "VALID";
            $result["data"] = array( "amounts" => $amounts );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function bill_opt($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $result["response"] = "VALID";
            $result["data"] = array( "provider" => $this->lib->getBillOpt() );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function reissue($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $newtoken = $this->genToken($uRow, 1);
            $this->db->query("UPDATE app_token SET token_key='" . $newtoken . "' WHERE token_key='" . $auth_token . "'");
            $result["response"] = "VALID";
            $result["data"] = array( "auth_token" => $newtoken );
        }
        else
        {
            echo "HUNGRY";
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function kyc_add($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $kyctype = $params->kyctype;
        $fullname = $params->fullname;
        $address = $params->address;
        $city = $params->city;
        $zip = $params->zip;
        $country = $params->country;
        $mobile = $params->mobile;
        $email = $params->email;
        $photoid = $params->photoid;
        $photofile = $params->photofile;
        if( strlen($photofile) ) 
        {
            $filename = md5(time()) . "." . explode(":", $photofile)[0];
            $ifp = fopen("../photoid/" . $filename, "wb");
            fwrite($ifp, base64_decode(explode(":", $photofile)[1]));
            fclose($ifp);
            $photofile = $filename;
        }

        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $ins = array( "rid" => $uRow->id, "fullname" => $fullname, "address" => $address, "city" => $city, "zipcode" => $zip, "country" => $country, "mobile" => $mobile, "email" => $email, "photoid" => $photoid, "photofile" => $photofile, "type" => $kyctype );
            $this->db->insert("bankprofile", $ins);
            $id = $this->db->insert_id();
            if( strlen($id) ) 
            {
                $result["response"] = "VALID";
                $result["data"] = array( "id" => $id, "fullname" => $fullname );
            }
            else
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! Something went wrong." );
            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function kyc_edit($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $kycid = $params->kycid;
        $kyctype = $params->kyctype;
        $fullname = $params->fullname;
        $address = $params->address;
        $city = $params->city;
        $zip = $params->zip;
        $country = $params->country;
        $mobile = $params->mobile;
        $email = $params->email;
        $photoid = $params->photoid;
        $photofile = $params->photofile;
        if( strlen($photofile) ) 
        {
            $filename = md5(time()) . "." . explode(":", $photofile)[0];
            $ifp = fopen("../photoid/" . $filename, "wb");
            fwrite($ifp, base64_decode(explode(":", $photofile)[1]));
            fclose($ifp);
            $photofile = $filename;
        }

        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $ins = array( "rid" => $uRow->id, "fullname" => $fullname, "address" => $address, "city" => $city, "zipcode" => $zip, "country" => $country, "mobile" => $mobile, "email" => $email, "photoid" => $photoid, "type" => $kyctype );
            if( strlen($photofile) ) 
            {
                $ins["photofile"] = $photofile;
            }

            $this->db->where("id", $kycid);
            $this->db->update("bankprofile", $ins);
            $result["response"] = "VALID";
            $result["data"] = array( "msg" => "KYC Updated successfylly" );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function kyc_list($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $kyctype = $params->kyctype;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $kycList = $this->db->select("id,fullname,email")->from("bankprofile")->where(array( "rid" => $uRow->id, "type" => $kyctype ))->get()->result();
            $result["response"] = "VALID";
            $result["data"] = array( "kyclist" => $kycList );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function kyc_view($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $kyctype = $params->kyctype;
        $kycid = $params->kycid;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $kRow = $this->db->select("*")->from("bankprofile")->where(array( "id" => $kycid, "type" => $kyctype ))->get()->row();
            $result["response"] = "VALID";
            $result["data"] = array( "fullname" => $kRow->fullname, "address" => $kRow->address, "city" => $kRow->city, "zip" => $kRow->zipcode, "country" => $kRow->country, "mobile" => $kRow->mobile, "email" => $kRow->email, "photoid" => $kRow->photoid, "photofile" => $this->myURL() . $kRow->photofile . "/xyz" );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function country_list($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $countries = $this->db->select("id,name, iso_alpha2 isocode, phonecode")->from("countries")->get()->result();
            $result["response"] = "VALID";
            $result["data"] = array( "countries" => $countries );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function bank_list($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $country = $params->country;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $banklist = $this->db->query("SELECT id,bankname FROM banklist WHERE cid='" . $country . "' ORDER BY bankname ASC")->result();
            $cRow = $this->db->query("SELECT r.exchange_rate, r.currency_code FROM countries c, currency r WHERE c.currency_code=r.currency_code AND c.id='" . $country . "'")->row();
            $result["response"] = "VALID";
            $result["data"] = array( "banklist" => $banklist, "ex_rate" => $cRow->exchange_rate, "currency_code" => $cRow->currency_code );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function branch_list($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $bankid = $params->bankid;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $branchlist = $this->db->query("SELECT * FROM bankbranch WHERE bid='" . $bankid . "' ORDER BY title ASC")->result();
            $result["response"] = "VALID";
            $result["data"] = array( "banklist" => $branchlist );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function pin_rate($data)
    {
        $result = array(  );
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $country = $params->country;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $cRow = $this->db->query("SELECT r.exchange_rate, r.currency_code FROM countries c, currency r WHERE c.currency_code=r.currency_code AND c.id='" . $country . "'")->row();
            $result["response"] = "VALID";
            $result["data"] = array( "ex_rate" => $cRow->exchange_rate, "currency_code" => $cRow->currency_code );
        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function banktransfer($data)
    {
        $result = array(  );
        $result["response"] = "VALID";
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $country = $params->country;
        $bank = $params->bank;
        $branch = $params->branch;
        $sender = $params->sender;
        $receiver = $params->receiver;
        $account_name = $params->account_name;
        $account_no = $params->account_no;
        $amount = $params->amount;
        $note = $params->note;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $var = $this->lib->verify_bank($bank, $amount, $uRow->id, $uRow->user_type);
            if( $var["verify_dst"] == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! You are not allowed use this service." );
            }

            if( $var["verify_bal"] == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! Not enough balance." );
            }

            if( $var["verify_cst"] == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
            }

            if( $result["response"] == "VALID" ) 
            {
                $insert_id = $this->lib->banktransfer($country, $bank, $branch, $sender, $receiver, $account_name, $account_no, $amount, $note, $uRow->id, $uRow->user_type);
                if( strlen($insert_id) ) 
                {
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "Request processed successfully" );
                }
                else
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! Something went wrong with server" );
                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function pintransfer($data)
    {
        $result = array(  );
        $result["response"] = "VALID";
        $auth_token = $data->auth_token;
        $params = json_decode($data->params);
        $country = $params->country;
        $sender = $params->sender;
        $receiver = $params->receiver;
        $amount = $params->amount;
        $note = $params->note;
        $tk = $this->verifyToken($auth_token);
        if( $tk["var"] == true ) 
        {
            $uRow = $tk["uRow"];
            $var = $this->lib->verify_pintransfer($country, $amount, $uRow->id, $uRow->user_type);
            if( $var["verify_dst"] == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! You are not allowed use this service." );
            }

            if( $var["verify_bal"] == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! Not enough balance." );
            }

            if( $var["verify_cst"] == 0 ) 
            {
                $result["response"] = "INVALID";
                $result["data"] = array( "msg" => "Sorry! No rate was found for this service." );
            }

            if( $result["response"] == "VALID" ) 
            {
                $insert_id = $this->lib->pintransfer($country, $sender, $receiver, $amount, $note, $uRow->id, $uRow->user_type);
                if( strlen($insert_id) ) 
                {
                    $result["response"] = "VALID";
                    $result["data"] = array( "msg" => "Request processed successfully" );
                }
                else
                {
                    $result["response"] = "INVALID";
                    $result["data"] = array( "msg" => "Sorry! Something went wrong with server" );
                }

            }

        }
        else
        {
            $result["response"] = "INVALID";
            $result["data"] = array( "msg" => $tk["msg"] );
        }

        $this->output($result);
    }

    public function genToken($r, $ch)
    {
        $AUTHID = $this->lib->ePinGen(6);
        $USERNAME = $r->username;
        $COOKIE = $r->cookie;
        $UNIQKEY = uniqid("A");
        $TIME = time();
        $TOKEN = (string) $AUTHID . ";" . $USERNAME . ";" . $COOKIE . ";" . $UNIQKEY . ";" . $TIME . ";";
        $token_key = $this->encrypt($TOKEN);
        $insert = array( "token_id" => $AUTHID, "token_key" => $token_key, "challange" => $ch, "attempt" => 3 );
        $this->db->insert("app_token", $insert);
        $this->db->query("DELETE FROM app_token WHERE last_used < NOW() - INTERVAL 24 HOUR");
        return $token_key;
    }

    public function verifyToken($token, $ch = 1)
    {
        $response = array(  );
        $string = $this->decrypt($token);
        $str = explode(";", $string);
        if( count($str) == 6 ) 
        {
            list($authid, $username, $cookie, , $time, $device_id) = $str;
            $time_check = time() - $time;
            if( $ch == 1 ) 
            {
                $dev = $device_id;
            }
            else
            {
                $dev = "";
            }

            if( $time_check < 31536000 ) 
            {
                $tQuery = $this->db->get_where("app_token", array( "token_id" => $authid, "challange" => $ch ));
                $uQuery = $this->db->select("*")->from("resellers")->where(array( "username" => $username, "cookie" => $cookie, "status" => 1 ));
                if( strlen($dev) ) 
                {
                    $uQuery->where("device_id", $dev);
                }

                $uQuery = $uQuery->get();
                if( $uQuery->num_rows() == 1 && $tQuery->num_rows() == 1 ) 
                {
                    $tR = $tQuery->row();
                    $response["var"] = true;
                    $response["attempt"] = $tR->attempt;
                    $response["uRow"] = $uQuery->row();
                    $response["device_id"] = $device_id;
                    $response["token_id"] = $authid;
                }
                else
                {
                    $response["var"] = false;
                    $response["msg"] = "Token Invalid.";
                }

            }
            else
            {
                $response["var"] = false;
                $response["msg"] = "Token expired.";
            }

        }
        else
        {
            $response["var"] = false;
            $response["msg"] = "Token error.";
        }

        return $response;
    }

    public function output($result)
    {
        echo json_encode($result);
        exit();
    }

    public function encrypt($str, $isBinary = false)
    {
        $iv = $this->iv;
        $str = ($isBinary ? $str : utf8_decode($str));
        $td = mcrypt_module_open("rijndael-128", " ", "cbc", $iv);
        mcrypt_generic_init($td, $this->key, $iv);
        $encrypted = mcrypt_generic($td, $str);
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        return ($isBinary ? $encrypted : bin2hex($encrypted));
    }

    public function decrypt($code, $isBinary = false)
    {
        $code = ($isBinary ? $code : $this->hex2bin($code));
        $iv = $this->iv;
        $td = mcrypt_module_open("rijndael-128", " ", "cbc", $iv);
        mcrypt_generic_init($td, $this->key, $iv);
        $decrypted = mdecrypt_generic($td, $code);
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        return ($isBinary ? trim($decrypted) : utf8_encode(trim($decrypted)));
    }

    protected function hex2bin($hexdata)
    {
        $bindata = "";
        $i = 0;
        while( $i < strlen($hexdata) ) 
        {
            $bindata .= chr(hexdec(substr($hexdata, $i, 2)));
            $i += 2;
        }
        return $bindata;
    }

    public function sendOtp($uRow)
    {
        $send = array(  );
        $otp_route = $this->lib->getSet("otp_route");
        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $senderid = $this->lib->getSet("brandname");
        $brandname = $this->lib->getSet("brandname");
        $newCode = $this->randomCode();
        $this->db->where("id", $uRow->id)->update("resellers", array( "pin" => password_hash($newCode . $this->lib->passKey(), PASSWORD_BCRYPT) ));
        $this->session->set_userdata("verify_session", time());
        if( strlen($uRow->mobile) ) 
        {
            $send[] = "mobile";
            $api = $this->lib->smsApi();
            if( $otp_route == 1 && $api->found == 1 ) 
            {
                $msg = "Use " . $newCode . " as one time password for Android login at " . $domain;
                $msg = urlencode($msg);
                $senderid = substr($senderid, 0, 11);
                $senderid = urlencode($senderid);
                $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
                $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $uRow->mobile, (string) $msg, "0" );
                $link = str_replace($uData, $sData, $api->url);
                $fdata = array(  );
                $this->lib->curl_get($link, $fdata);
                $route = $api->id;
            }
            else
            {
                $outbox = array( "rid" => "-1", "receiver" => $uRow->mobile, "message" => "Use " . $newCode . " as one time password for Android login at " . $domain, "status" => 0 );
                $this->db->insert("outbox", $outbox);
                $route = "-1";
            }

            $otp_cost = $this->lib->getSet("otp_cost");
            if( 0 < $otp_cost ) 
            {
                $cost["main"] = $otp_cost;
                $cost["rs5"] = $otp_cost;
                $cost["rs4"] = $otp_cost;
                $cost["rs3"] = $otp_cost;
                $cost["rs2"] = $otp_cost;
                $this->lib->dedBal_all($uRow->id, $uRow->user_type, $cost);
                $smsLogs = array( "sender" => $uRow->id, "sender_id" => $senderid, "receiver" => $uRow->mobile, "sms" => "Reseller login OTP was sent via sms", "rs5" => $uRow->rs5, "rs4" => $uRow->rs4, "rs3" => $uRow->rs3, "rs2" => $uRow->rs2, "cost" => $cost["main"], "cost5" => $cost["rs5"], "cost4" => $cost["rs4"], "cost3" => $cost["rs3"], "cost2" => $cost["rs2"], "bal" => $this->lib->getBal($uRow->id), "bal5" => $this->lib->getBal($uRow->rs5), "bal4" => $this->lib->getBal($uRow->rs4), "bal3" => $this->lib->getBal($uRow->rs3), "bal2" => $this->lib->getBal($uRow->rs2), "api" => $route, "status" => 4, "send_time" => date("Y-m-d H:i:s"), "ip" => $this->lib->RemoteIP() );
                $this->db->insert("sms_req", $smsLogs);
            }

        }

        return count($send);
    }

    public function randomCode()
    {
        $alphabet = "ABCDEFHKNQRSUVXYZ123456789";
        $pass = array(  );
        $alphaLength = strlen($alphabet) - 1;
        $i = 0;
        while( $i < 6 ) 
        {
            $n = mt_rand(1, $alphaLength);
            $pass[] = $alphabet[$n];
            $i++;
        }
        return implode($pass);
    }

    public function escape_str($str)
    {
        return $str;
    }

    public function randomPassword($len)
    {
        $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        $pass = array(  );
        $alphaLength = strlen($alphabet) - 1;
        $i = 0;
        while( $i < $len ) 
        {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
            $i++;
        }
        return implode($pass);
    }

    public function myServices($type)
    {
        $data = array(  );
        $otp = $this->lib->getSet("reseller_otp");
        $module = $this->lib->getType($type);
        $q = $this->db->select("*")->from("services")->where("type !=", "16")->where("type >", "4");
        $result = $q->get()->result();
        foreach( $result as $row ) 
        {
            if( in_array($row->type, $module) ) 
            {
                $tmp = new stdClass();
                $tmp->id = $row->id;
                $tmp->title = $row->title;
                $tmp->spaceuri = $row->spaceuri;
                $tmp->type = $row->type;
                $tmp->enable = $row->enable;
                $tmp->min_amnt = $row->min_amnt;
                $tmp->max_amnt = $row->max_amnt;
                $tmp->min_length = $row->min_length;
                $tmp->max_length = $row->max_length;
                $tmp->risk_amount = $row->risk_amount;
                $tmp->short = $row->short;
                $tmp->require_pin = 0;
                $tmp->nid_freeamount = $row->nid_freeamount;
                $tmp->require_pid = $row->require_pid;
                $tmp->require_sender = $row->require_sender;
                $tmp->require_receiver = $row->require_receiver;
                $tmp->require_file = $row->require_file;
                $tmp->currency = $row->currency;
                $tmp->logo = $this->myURL() . ((strlen($row->logo) ? $row->logo . "/xyz" : (string) $row->spaceuri . ".png/org"));
                $data[] = $tmp;
            }

        }
        if( in_array(2, $module) ) 
        {
            $q = $this->db->select("*")->from("services")->where("type", "2");
            $row = $q->get()->row();
            if( $otp == 0 ) 
            {
                $row->require_pin = $row->require_pin;
            }

            if( $otp == 1 ) 
            {
                $row->require_pin = 0;
            }

            $row->logo = $this->myURL() . ((strlen($row->logo) ? $row->logo : (string) $row->spaceuri . ".png/org"));
            $data[] = $row;
        }

        if( in_array(4, $module) ) 
        {
            $q = $this->db->select("*")->from("services")->where("type", "4");
            $row = $q->get()->row();
            if( $otp == 0 ) 
            {
                $row->require_pin = $row->require_pin;
            }

            if( $otp == 1 ) 
            {
                $row->require_pin = 0;
            }

            $row->logo = $this->myURL() . ((strlen($row->logo) ? $row->logo : (string) $row->spaceuri . ".png/org"));
            $data[] = $row;
        }

        if( in_array(1, $module) ) 
        {
            $q = $this->db->select("*")->from("services")->where("type", "1");
            $row = $q->get()->row();
            if( $otp == 0 ) 
            {
                $row->require_pin = $row->require_pin;
            }

            if( $otp == 1 ) 
            {
                $row->require_pin = 0;
            }

            $row->logo = $this->myURL() . ((strlen($row->logo) ? $row->logo : (string) $row->spaceuri . ".png/org"));
            $data[] = $row;
        }

        return $data;
    }

    public function srvUri($type)
    {
        $sQ = $this->db->select("spaceuri")->from("services")->where("type", $type)->get();
        $sR = $sQ->row();
        return $sR->spaceuri;
    }

    public function fStatus($status)
    {
        if( $status == 0 ) 
        {
            $title = "Pending";
        }

        if( $status == 1 ) 
        {
            $title = "Processed";
        }

        if( $status == 2 ) 
        {
            $title = "Failed";
        }

        if( $status == 3 ) 
        {
            $title = "Cancelled";
        }

        if( $status == 4 ) 
        {
            $title = "Success";
        }

        return strtoupper($title);
    }

    public function ttSts($type)
    {
        $txt = NULL;
        if( $type == 1 ) 
        {
            $txt = "Open";
        }

        if( $type == 2 ) 
        {
            $txt = "Answered";
        }

        if( $type == 3 ) 
        {
            $txt = "In Progress";
        }

        if( $type == 4 ) 
        {
            $txt = "On Hold";
        }

        if( $type == 5 ) 
        {
            $txt = "Close";
        }

        return $txt;
    }

    public function showDate($last_update)
    {
        $istoday = date("d-m-y", strtotime($last_update));
        $today = date("d-m-y");
        $stryear = date("Y", strtotime($last_update));
        $thisyear = date("Y");
        if( $istoday == $today ) 
        {
            return date("g:i A", strtotime($last_update));
        }

        if( $stryear != $thisyear ) 
        {
            return date("M Y", strtotime($last_update));
        }

        return date("M d", strtotime($last_update));
    }

    public function _complex($str)
    {
        $msg = "";
        $len = $this->lib->getSet("complex_pass");
        if( 0 < $len ) 
        {
            if( strlen($str) < $len ) 
            {
                $msg = "Minimum Password length is 9";
            }
            else
            {
                if( !preg_match("#[0-9]+#", $str) ) 
                {
                    $msg = "Password must include at least one number!";
                }
                else
                {
                    if( !preg_match("#[A-Z]+#", $str) ) 
                    {
                        $msg = "Password must include at least one uppercase!";
                    }
                    else
                    {
                        if( !preg_match("#[a-z]+#", $str) ) 
                        {
                            $msg = "Password must include at least one lowercase!";
                        }
                        else
                        {
                            if( !preg_match("/['\\/~`\\!@#\\\$%\\^&\\*\\(\\)_\\-\\+=\\{\\}\\[\\]\\|;:\"\\<\\>,\\.\\?\\\\]/", $str) ) 
                            {
                                $msg = "Password must include at least one symbol!";
                            }
                            else
                            {
                                $msg = "";
                            }

                        }

                    }

                }

            }

        }
        else
        {
            $msg = "";
        }

        return $msg;
    }

    public function _validePin($serial, $epin, $res_id)
    {
        $msg = "";
        $epin = str_replace(" ", "", $epin);
        $today = date("Y-m-d H:i:s");
        $pQ = $this->db->select("*")->from("epin_list")->where("epin", $epin)->where("serial", $serial)->where("status", 1)->where("expiredate >", $today)->limit(1)->get();
        $cR = $this->db->select("count(*) c")->from("epin_list")->where("rsid", $res_id)->where("date(lastupdate)", date("Y-m-d"))->get()->row();
        if( 3 < $cR->c ) 
        {
            $msg = "Sorry! Daily redeem limit exceeded.";
        }
        else
        {
            if( $pQ->num_rows() == 0 ) 
            {
                $msg = "Sorry! Invalid voucher pin and serial";
            }

        }

        return $msg;
    }

    public function notify_sms($msg, $number)
    {
        $send = "";
        $senderid = $this->lib->getSet("brandname");
        $api = $this->lib->smsApi();
        if( $api->found == 1 ) 
        {
            $send = "api";
            $txtmsg = urlencode($msg);
            $senderid = substr($senderid, 0, 11);
            $senderid = urlencode($senderid);
            $uData = array( "!LOGIN!", "!PASS!", "!FROM!", "!TO!", "!TEXT!", "!ID!" );
            $sData = array( (string) $api->user, (string) $api->apikey, (string) $senderid, (string) $number, (string) $txtmsg, "0" );
            $link = str_replace($uData, $sData, $api->url);
            $fdata = array(  );
            $this->lib->curl_get($link, $fdata);
            $route = $api->id;
        }
        else
        {
            $send = "modem";
            $outbox = array( "rid" => "-1", "receiver" => $number, "message" => $msg, "status" => 0 );
            $this->db->insert("outbox", $outbox);
            $route = "-1";
        }

        return $send;
    }

    public function notify_email($msg, $email, $subject)
    {
        $domain = str_replace("www.", "", $_SERVER["HTTP_HOST"]);
        $brandname = $this->lib->getSet("brandname");
        $mail = $this->lib->mail();
        $mail->AddReplyTo("no-reply@" . $domain, $brandname);
        $mail->SetFrom("no-reply@" . $domain, $brandname);
        $mail->AddAddress($email, "");
        $mail->Subject = $subject;
        $mail->MsgHTML($msg);
        return $mail->Send();
    }

    public function myURL()
    {
        $domain = $_SERVER["HTTP_HOST"];
        $domain = str_replace("www.", "", $domain);
        $domain = str_replace("https://", "", $domain);
        $domain = str_replace("http://", "", $domain);
        $domain = str_replace("/", "", $domain);
        $domain = str_replace(" ", "", $domain);
        $ssl = $this->lib->getSet("ssl");
        if( $ssl == 1 ) 
        {
            $h = "https://";
        }
        else
        {
            $h = "http://";
        }

        return $url = $h . $domain . "/mVersions/img/";
    }

    public function _viewBal($bal, $currency)
    {
        $balArray = explode(",", $bal);
        $bal1 = $this->lib->viewAmount($balArray[0], $currency);
        $bal2 = $this->lib->viewAmount($balArray[1], $currency);
        return $bal1 . "," . $bal2;
    }

}


