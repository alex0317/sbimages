<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['data'] = "SBLoadSecurityKey2019";
