<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0", false);
        $this->output->set_header("Pragma: no-cache");
        $this->load->model('Ezzeload', 'lib');
        $this->load->model('Page', 'page');
        $this->load->model('Filter', "flt");
        $this->load->model('Module', "mod");
        $this->lib->isLogin();
    }

    public function index()
    {
        $this->load->view('header');
        $this->load->view('dashboard');
        $this->load->view('footer');
    }

    public function req($srv, $parm = "")
    {
        $sRow = $this->lib->serviceByUri($srv);
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $data["sRow"] = $sRow;
        $data["srv"] = $srv;
        if ($sRow->type != 512)
            $len = "|min_length[" . $sRow->min_length . "]|max_length[" . $sRow->max_length . "]";

        $this->load->helper('file');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');

        if ($srv == "flexiload" && $parm == "package") {
            $this->form_validation->set_rules('package', 'Package', 'trim|required');
            $this->form_validation->set_rules('operator', 'Operator', 'trim|numeric|required');
        }

        if ($sRow->type == 512) {
            $this->form_validation->set_rules('country', 'Country', 'trim|numeric|required');
            $this->form_validation->set_rules('operator', 'Operator', 'trim|numeric|required');
            $this->form_validation->set_rules('phonecode', 'Phonecode', 'trim|numeric|required');
            $this->form_validation->set_rules('number', 'Number', 'trim|numeric|required');
            $this->form_validation->set_rules('length', 'length', "callback__validLength");
        } else {
            $this->form_validation->set_rules('number', 'Number', 'trim|numeric|required' . $len);
        }

        $this->form_validation->set_rules('amount', 'Amount', 'trim|numeric|required');
        $this->form_validation->set_rules('valid', 'valid', "callback__valid[$srv]");

        $this->form_validation->set_message('min_length', "Minimum %s length %s.");
        $this->form_validation->set_message('max_length', "Maximum %s length %s.");

        $amt = $this->input->post("amount");
        if ($amt > $sRow->nid_freeamount) {
            if ($sRow->require_pid == 1) $this->form_validation->set_rules('photoid', 'NID/PhotoID', 'trim|numeric|required');
            if ($sRow->require_file == 1) $this->form_validation->set_rules('photofile', 'NID/PhotoID File', 'trim|callback_file_check');
            if ($sRow->require_sender == 1) $this->form_validation->set_rules('sendername', 'Sender Name', 'trim|required');
            if ($sRow->require_receiver == 1) $this->form_validation->set_rules('receivername', 'Receiver Name', 'trim|required');
        }

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');

            if ($srv == "flexiload" && $parm == "package") $this->load->view("package", $data);
            else if ($sRow->type <= 512) {
                $this->load->view($srv, $data);
            } else {
                $this->load->view('custom', $data);
            }
            $this->load->view('footer');
        } else {

            $data['photofile'] = "";
            $config['upload_path'] = '../photoid';
            $config['allowed_types'] = 'jpg|png|pdf';
            $config['max_size'] = 1024;
            $config['encrypt_name'] = TRUE;
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('photofile')) {
                $uploadData = $this->upload->data();
                $photofile = $uploadData['file_name'];
                $data['photofile'] = $photofile;
            }

            if ($sRow->require_pin == 1) {
                $this->load->view('header');
                $this->load->view("verify_pin", $data);
                $this->load->view('footer');
            } else {
                $country = '-1';
                $operator = '-1';
                $id = $this->session->userdata("id");
                $level = $this->session->userdata("user_type");
                $number = $this->input->post("number", TRUE);
                $amount = $this->input->post("amount", TRUE);
                $type = $this->input->post("type", TRUE);

                if ($sRow->type == 512) {
                    $country = $this->input->post("country", TRUE);
                    $operator = $this->input->post("operator", TRUE);
                    $phonecode = $this->input->post("phonecode", TRUE);
                    $number = $phonecode . $number;
                }

                $photoid = $this->input->post("photoid", TRUE);
                $sendername = $this->input->post("sendername", TRUE);
                $receivername = $this->input->post("receivername", TRUE);

                $id = $this->lib->request($sRow->type, $number, $amount, $type, $id, $level, $country, $operator, $photoid, $sendername, $receivername, $photofile);

                if (strlen($id)) {
                    $this->session->set_flashdata("send", "1");
                    if ($srv == "flexiload" && $parm == "package") redirect("main/req/flexiload/package", "location");
                    else redirect("main/req/$srv/$id", "location");
                }
            }
        }
    }

    public function global_topup($srv = "intopup")
    {
        $sRow = $this->lib->serviceByUri($srv);
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array("512", $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $data["sRow"] = $sRow;
        $data["srv"] = $srv;
        //if ($sRow->type!=512) $len="|min_length[".$sRow->min_length."]|max_length[".$sRow->max_length."]";

        $this->load->helper('file');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');

        $this->form_validation->set_rules('country', 'Country', 'trim|numeric|required');
        $this->form_validation->set_rules('operator', 'Operator', 'trim|numeric|required');
        $this->form_validation->set_rules('phonecode', 'Phonecode', 'trim|numeric|required');
        $this->form_validation->set_rules('number', 'Number', 'trim|numeric|required');
        $this->form_validation->set_rules('type', 'Type', 'trim|numeric|required');
        $this->form_validation->set_rules('length', 'length', "callback__validLength");

        $this->form_validation->set_rules('package', 'Package', 'trim|numeric|required');
        $this->form_validation->set_rules('valid', 'valid', "callback__valid_global[$srv]");

        $this->form_validation->set_message('min_length', "Minimum %s length %s.");
        $this->form_validation->set_message('max_length', "Maximum %s length %s.");


        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("intopup", $data);
            $this->load->view('footer');
        } else {
            if ($sRow->require_pin == 1) {
                $this->load->view('header');
                $this->load->view("verify_pin_intopup", $data);
                $this->load->view('footer');
            } else {
                $id = $this->session->userdata("id");
                $level = $this->session->userdata("user_type");

                $phonecode = $this->input->post("phonecode", TRUE);
                $number = $this->input->post("number", TRUE);
                $package = $this->input->post("package", TRUE);
                $number = $phonecode . $number;
                $type = $this->input->post("type", TRUE);


                $id = $this->lib->request_global(512, $package, $number, $type, $id, $level);
                if (strlen($id)) {
                    $this->session->set_flashdata("send", "1");
                    redirect("main/global_topup/", "location");
                }
            }
        }
    }

    public function viewfile($file)
    {
        echo $this->lib->viewFile($file);
        //echo $path=file_get_contents("../photoid/$file");
    }

    public function file_check($str)
    {
        $allowed_mime_type_arr = array('application/pdf', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
        $mime = get_mime_by_extension($_FILES['photofile']['name']);
        if (isset($_FILES['photofile']['name']) && $_FILES['photofile']['name'] != "") {
            if (in_array($mime, $allowed_mime_type_arr)) {
                return true;
            } else {
                $this->form_validation->set_message('file_check', 'Please select only pdf/gif/jpg/png file.');
                return false;
            }
        } else {
            $this->form_validation->set_message('file_check', 'Please choose a file to upload.');
            return false;
        }
    }

    function _validLength()
    {
        $number = $this->input->post("number", TRUE);
        $phonecode = $this->input->post("phonecode", TRUE);
        $number = $phonecode . $number;
        $length = $this->lib->countryLength($this->input->post('country'));
        if ($length != 0) {
            if (strlen($number) != $length) {
                $this->form_validation->set_message('_validLength', "Number must be $length characters.");
                return FALSE;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public function verifyPin($srv)
    {
        if (!$_POST) redirect("main/req/" . $srv);
        //$otp =$this->session->userdata("enable_otp");
        $sRow = $this->lib->serviceByUri($srv);
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $data["sRow"] = $sRow;
        $data["srv"] = $srv;

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('pin', '2Step verification', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', "callback__valid[$srv]");
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("verify_pin", $data);
            $this->load->view('footer');
        } else {
            $this->session->set_userdata("otp_sent", "0");
            $country = '-1';
            $operator = '-1';
            $id = $this->session->userdata("id");
            $level = $this->session->userdata("user_type");
            $number = $this->input->post("number", TRUE);
            $amount = $this->input->post("amount", TRUE);
            $type = $this->input->post("type", TRUE);

            if ($sRow->type == 512) {
                $country = $this->input->post("country", TRUE);
                $operator = $this->input->post("operator", TRUE);
                $phonecode = $this->input->post("phonecode", TRUE);
                $number = $phonecode . $number;
            }

            $photoid = $this->input->post("photoid", TRUE);
            $sendername = $this->input->post("sendername", TRUE);
            $receivername = $this->input->post("receivername", TRUE);
            $photofile = $this->input->post("photofile", TRUE);

            $id = $this->lib->request($sRow->type, $number, $amount, $type, $id, $level, $country, $operator, $photoid, $sendername, $receivername, $photofile);
            if (strlen($id)) redirect("main/req/$srv/$id", "location");
        }
    }

    function _valid($str, $srv)
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $sRow = $this->lib->serviceByUri($srv);
        $number = $this->input->post("number", TRUE);
        $amount = $this->input->post("amount", TRUE);
        $type = $this->input->post("type", TRUE);

        if ($sRow->type == 512) {
            $phonecode = $this->input->post("phonecode", TRUE);
            $number = $phonecode . $number;
        }

        if ($amount < $sRow->min_amnt || $amount > $sRow->max_amnt) {
            $this->form_validation->set_message('_valid', "Amount must between $sRow->min_amnt & $sRow->max_amnt.");
            return FALSE;
        }

        $dailyLimit = $this->lib->dailyLimit($id, $amount);
        if ($dailyLimit == false) {
            $this->form_validation->set_message('_valid', "Reseller daily limit exceeded.");
            return FALSE;
        }

        $interbal = $this->lib->getSet("req_interval");
        $time = $this->lib->inTime($number, $sRow->type, $interbal, $amount);

        if (!$time) {
            $this->form_validation->set_message('_valid', "Can't process! Please try after $interbal minute.");
            return FALSE;
        }

        //Verify Cost + Number
        if ($sRow->type == 32) {
            $var = $this->lib->verify_destination($sRow->type, $number, $amount, $type, $id, $level, 1);
        } else {
            $var = $this->lib->verify_destination($sRow->type, $number, $amount, $type, $id, $level);
        }
        if ($var['verify_dst'] == 0) {
            $this->form_validation->set_message('_valid', "Sorry! Rate prefix was not found.");
            return FALSE;
        }
        if ($var['verify_bal'] == 0) {
            $this->form_validation->set_message('_valid', "Sorry! Not enough balance.");
            return FALSE;
        }
        if ($var['verify_cst'] == 0) {
            $this->form_validation->set_message('_valid', "Sorry! rate was not found");
            return FALSE;
        }
    }

    function _valid_global($str, $srv)
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $sRow = $this->lib->serviceByUri($srv);
        $number = $this->input->post("number", TRUE);
        $package = $this->input->post("package", TRUE);
        $type = $this->input->post("type", TRUE);

        $pack = $this->lib->getIntPack($package);

        $phonecode = $this->input->post("phonecode", TRUE);
        $number = $phonecode . $number;

        $cost = $pack->cost;
        $amount = $pack->amount;

        $dailyLimit = $this->lib->dailyLimit($id, $cost);
        if ($dailyLimit == false) {
            $this->form_validation->set_message('_valid_global', "Reseller daily limit exceeded.");
            return FALSE;
        }

        $interbal = $this->lib->getSet("req_interval");
        $time = $this->lib->inTime($number, $sRow->type, $interbal, $amount);

        if (!$time) {
            $this->form_validation->set_message('_valid_global', "Can't process! Please try after $interbal minute.");
            return FALSE;
        }


        $var = $this->lib->verify_global($number, $pack, $type, $id, $level);

        if ($var['verify_dst'] == 0) {
            $this->form_validation->set_message('_valid_global', "Sorry! Rate prefix was not found.");
            return FALSE;
        }
        if ($var['verify_bal'] == 0) {
            $this->form_validation->set_message('_valid_global', "Sorry! Not enough balance.");
            return FALSE;
        }
        if ($var['verify_cst'] == 0) {
            $this->form_validation->set_message('_valid_global', "Sorry! rate was not found");
            return FALSE;
        }
    }

    public function verifyInt($srv = "intopup")
    {
        if (!$_POST) redirect("main/global_topup/" . $srv);
        $sRow = $this->lib->serviceByUri($srv);
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $data["sRow"] = $sRow;
        $data["srv"] = $srv;

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('pin', '2Step verification', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', "callback__valid_global[$srv]");
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("verify_pin_intopup", $data);
            $this->load->view('footer');
        } else {
            $this->session->set_userdata("otp_sent", "0");
            $id = $this->session->userdata("id");
            $level = $this->session->userdata("user_type");

            $phonecode = $this->input->post("phonecode", TRUE);
            $number = $this->input->post("number", TRUE);
            $package = $this->input->post("package", TRUE);
            $number = $phonecode . $number;
            $type = $this->input->post("type", TRUE);

            $id = $this->lib->request_global(512, $package, $number, $type, $id, $level);
            if (strlen($id)) {
                $this->session->set_flashdata("send", "1");
                redirect("main/global_topup/", "location");
            }
        }
    }

    public function global_rates($sort_by = 'id', $sort_order = 'asc')
    {
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['fields'] = array(
            'title' => 'Package',
            'amount' => 'Amount',
            'cost' => 'Cost',
            'country' => 'Country',
            'operator' => 'Operator'
        );

        $oid = $this->input->post("operator");
        $cid = $this->input->post("country");

        $q = $this->db->select("*")->from("global_package")->order_by($sort_by, $sort_order);
        if (strlen($oid)) $q->where("operator", $oid);
        if (strlen($cid)) $q->where("country", $cid);

        $data['results'] = $q->get()->result();

        $this->load->view('header');
        $this->load->view('global_rates', $data);
        $this->load->view('footer');
    }

    public function banktransfer()
    {
        $sRow = $this->lib->serviceByUri("remittance");
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('country', 'Country', 'trim|required|numeric');
        $this->form_validation->set_rules('bank', 'Bank Name', 'trim|required|numeric');
        $this->form_validation->set_rules('branch', 'Branch Name', 'trim|required|numeric');
        $this->form_validation->set_rules('sender', 'Sender', 'trim|required|numeric');
        $this->form_validation->set_rules('receiver', 'Receiver', 'trim|required|numeric');

        $this->form_validation->set_rules('account', 'Account', 'trim|required|numeric');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric|callback__banktransfer_valid');
        $this->form_validation->set_rules('note', 'Description', '');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("banktransfer");
            $this->load->view('footer');
        } else {
            if ($sRow->require_pin == 1) {
                $this->load->view('header');
                $this->load->view("banktransfer_pin");
                $this->load->view('footer');
            } else {
                $id = $this->session->userdata("id");
                $level = $this->session->userdata("user_type");
                $country = $this->input->post("country", TRUE);
                $bank = $this->input->post("bank", TRUE);
                $branch = $this->input->post("branch", TRUE);
                $sender = $this->input->post("sender", TRUE);
                $receiver = $this->input->post("receiver", TRUE);
                $account = $this->input->post("account", TRUE);
                $amount = $this->input->post("amount", TRUE);
                $note = $this->input->post("note", TRUE);
                $newid = $this->lib->banktransfer($country, $bank, $branch, $sender, $receiver, $account, $amount, $note, $id, $level);
                if (strlen($newid)) {
                    $this->session->set_flashdata("msg", "Bank Transfer Request Received Successfully");
                    redirect("main/banktransfer/$newid", "location");
                }
            }
        }
    }

    public function getBanks()
    {
        $this->load->view("getBanks");
    }

    public function getBanks_filter()
    {
        $this->load->view("getBanks_filter");
    }

    public function getBranch()
    {
        $this->load->view("getBranch");
    }

    public function addkyc($type = "receiver")
    {
        $this->load->helper('file');
        $config['upload_path'] = '../photoid';
        $config['allowed_types'] = 'jpg|png';
        $config['max_size'] = 1024;
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);
        $var['type'] = $type;
        $this->load->view("addkyc", $var);
    }

    public function viewkyc($id)
    {
        $data['kid'] = $id;
        $this->load->view("viewkyc", $data);
    }

    public function banktransfer_pin()
    {
        $sRow = $this->lib->serviceByUri("remittance");
        $type = $this->session->userdata("type");
        $otp = $this->session->userdata("enable_otp");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('pin', '2Step verification', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', "callback__banktransfer_valid");

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("banktransfer_pin");
            $this->load->view('footer');
        } else {
            $id = $this->session->userdata("id");
            $level = $this->session->userdata("user_type");
            $country = $this->input->post("country", TRUE);
            $bank = $this->input->post("bank", TRUE);
            $branch = $this->input->post("branch", TRUE);
            $sender = $this->input->post("sender", TRUE);
            $receiver = $this->input->post("receiver", TRUE);
            $account = $this->input->post("account", TRUE);
            $amount = $this->input->post("amount", TRUE);
            $note = $this->input->post("note", TRUE);
            $newid = $this->lib->banktransfer($country, $bank, $branch, $sender, $receiver, $account, $amount, $note, $id, $level);
            if (strlen($newid)) {
                $this->session->set_flashdata("msg", "Bank Transfer Request Received Successfully");
                redirect("main/banktransfer/$newid", "location");
            }
        }
    }

    function _banktransfer_valid()
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");

        $country = $this->input->post("country", TRUE);
        $bank = $this->input->post("bank", TRUE);
        $branch = $this->input->post("branch", TRUE);
        $sender = $this->input->post("sender", TRUE);
        $receiver = $this->input->post("receiver", TRUE);
        $account = $this->input->post("account", TRUE);
        $amount = $this->input->post("amount", TRUE);
        $note = $this->input->post("note", TRUE);

        //Check Destination, Cost, Balance
        $var = $this->lib->verify_bank($bank, $amount, $id, $level);

        if ($var['verify_dst'] == 0) {
            $this->form_validation->set_message('_banktransfer_valid', "Sorry! You are not allowed use this service.");
            return FALSE;
        }
        if ($var['verify_bal'] == 0) {
            $this->form_validation->set_message('_banktransfer_valid', "Sorry! Not enough balance.");
            return FALSE;
        }
        if ($var['verify_cst'] == 0) {
            $this->form_validation->set_message('_banktransfer_valid', "Sorry! rate was not found");
            return FALSE;
        }
    }


    public function pintransfer()
    {
        $sRow = $this->lib->serviceByUri("remittance");
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('country', 'Country', 'trim|required|numeric');
        $this->form_validation->set_rules('sender', 'Sender', 'trim|required|numeric');
        $this->form_validation->set_rules('receiver', 'Receiver', 'trim|required|numeric');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric|callback__pintransfer_valid');
        $this->form_validation->set_rules('note', 'Description', '');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("pintransfer");
            $this->load->view('footer');
        } else {
            if ($sRow->require_pin == 1) {
                $this->load->view('header');
                $this->load->view("pintransfer_pin");
                $this->load->view('footer');
            } else {
                $id = $this->session->userdata("id");
                $level = $this->session->userdata("user_type");
                $country = $this->input->post("country", TRUE);
                $sender = $this->input->post("sender", TRUE);
                $receiver = $this->input->post("receiver", TRUE);
                $amount = $this->input->post("amount", TRUE);
                $note = $this->input->post("note", TRUE);
                $newid = $this->lib->pintransfer($country, $sender, $receiver, $amount, $note, $id, $level);
                if (strlen($newid)) {
                    $this->session->set_flashdata("msg", "PIN Transfer Received Successfully");
                    redirect("main/pintransfers/$newid", "location");
                }
            }
        }
    }

    public function pintransfer_pin()
    {
        $sRow = $this->lib->serviceByUri("remittance");
        $type = $this->session->userdata("type");
        $otp = $this->session->userdata("enable_otp");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('pin', '2Step verification', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', "callback__pintransfer_valid");

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("pintransfer_pin");
            $this->load->view('footer');
        } else {
            $id = $this->session->userdata("id");
            $level = $this->session->userdata("user_type");
            $country = $this->input->post("country", TRUE);
            $sender = $this->input->post("sender", TRUE);
            $receiver = $this->input->post("receiver", TRUE);
            $amount = $this->input->post("amount", TRUE);
            $note = $this->input->post("note", TRUE);
            $newid = $this->lib->pintransfer($country, $sender, $receiver, $amount, $note, $id, $level);
            if (strlen($newid)) {
                $this->session->set_flashdata("msg", "PIN Transfer Received Successfully");
                redirect("main/pintransfers/$newid", "location");
            }
        }
    }

    public function pintransfers($id)
    {
        //$data['id']
        $this->load->view('header');
        $this->load->view("pintransfer_success", compact('id'));
        $this->load->view('footer');
    }

    function _pintransfer_valid()
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");

        $country = $this->input->post("country", TRUE);
        $sender = $this->input->post("sender", TRUE);
        $receiver = $this->input->post("receiver", TRUE);
        $amount = $this->input->post("amount", TRUE);
        $note = $this->input->post("note", TRUE);

        //Check Destination, Cost, Balance
        $var = $this->lib->verify_pintransfer($country, $amount, $id, $level);

        if ($var['verify_dst'] == 0) {
            $this->form_validation->set_message('_pintransfer_valid', "Sorry! You are not allowed use this service.");
            return FALSE;
        }
        if ($var['verify_bal'] == 0) {
            $this->form_validation->set_message('_pintransfer_valid', "Sorry! Not enough balance.");
            return FALSE;
        }
        if ($var['verify_cst'] == 0) {
            $this->form_validation->set_message('_pintransfer_valid', "Sorry! rate was not found");
            return FALSE;
        }
    }

    public function sendsms()
    {
        $id = $this->session->userdata('id');
        $level = $this->session->userdata('user_type');
        $sRow = $this->lib->serviceByUri("sms");
        $type = $this->session->userdata("type");
        $mask = $this->lib->isMask($id);
        $cnf["mask"] = $mask;
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('receiver', 'Number', 'trim|required');
        if ($mask == 1) {
            $this->form_validation->set_rules('from', 'From', 'trim|required|max_length[11]');
        }
        $this->form_validation->set_rules('message', 'message', 'trim|required|callback__sms_valid');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("sendsms", $cnf);
            $this->load->view('footer');
        } else {
            $from = $this->input->post("from", TRUE);
            $msg = $this->input->post("message", TRUE);
            $number = $this->input->post("receiver", TRUE);

            if ($mask == 0) {
                $from = $this->session->userdata('fullname');
                $from = substr($from, 0, 11);
            }

            //Process here
            $response = $this->lib->sendSMS($number, $from, $msg, $id, $level);
            redirect("main/sendsms?sk=$response", 'location');
        }
    }


    function _sms_valid()
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $sRow = $this->lib->serviceByUri("sms");
        $number = $this->input->post("receiver", TRUE);
        $message = $this->input->post("message", TRUE);
        $amount = ceil(strlen(utf8_decode($message)) / 160);

        //Check is api exist
        $api = $this->lib->smsApi();
        if ($api->found == 0) {
            $this->form_validation->set_message('_sms_valid', "No active SMS API found.");
            return FALSE;
        }

        //Verify Cost + Number
        $var = $this->lib->verify_destination($sRow->type, $number, $amount, 0, $id, $level);

        if ($var['verify_dst'] == 0) {
            $this->form_validation->set_message('_sms_valid', "Sorry! Rate prefix was not found.");
            return FALSE;
        }
        if ($var['verify_bal'] == 0) {
            $this->form_validation->set_message('_sms_valid', "Sorry! Not enough balance.");
            return FALSE;
        }
        if ($var['verify_cst'] == 0) {
            $this->form_validation->set_message('_sms_valid', "Sorry! rate was not found");
            return FALSE;
        }
    }


    public function buycard()
    {
        $sRow = $this->lib->serviceByUri("prepaidcard");
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('operator', 'Operator', 'trim|required');
        $this->form_validation->set_rules('receiver', 'Receiver', 'trim');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|callback__card_valid');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("buycard");
            $this->load->view('footer');
        } else {
            if ($sRow->require_pin == 1) {
                $this->load->view('header');
                $this->load->view("buycard_pin");
                $this->load->view('footer');
            } else {
                $operator = $this->input->post("operator", TRUE);
                $amount = $this->input->post("amount", TRUE);
                $type = $this->input->post("type", TRUE);
                $receiver = $this->input->post("receiver", TRUE);
                $newid = $this->lib->buycard($operator, $amount, $type, $receiver);
                if (strlen($newid)) redirect("main/cardHistory/$newid", "location");
            }
        }
    }

    public function buycard_pin()
    {
        $sRow = $this->lib->serviceByUri("prepaidcard");
        $type = $this->session->userdata("type");
        $otp = $this->session->userdata("enable_otp");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        if ($otp == 3) $this->form_validation->set_rules('pin', 'PIN', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', 'callback__card_valid');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("buycard_pin");
            $this->load->view('footer');
        } else {
            $operator = $this->input->post("operator", TRUE);
            $amount = $this->input->post("amount", TRUE);
            $type = $this->input->post("type", TRUE);
            $receiver = $this->input->post("receiver", TRUE);
            $newid = $this->lib->buycard($operator, $amount, $type, $receiver);
            if (strlen($newid)) redirect("main/cardHistory/$newid", "location");
        }
    }

    public function chooseamount()
    {
        $this->load->view("chooseamount");
    }

    public function chooseamount_filter()
    {
        $this->load->view("chooseamount_filter");
    }

    function _card_valid()
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $operator = $this->input->post("operator", TRUE);
        $amount = $this->input->post("amount", TRUE);
        $type = $this->input->post("type", TRUE);
        //Check is Available
        $is = $this->lib->isAvailable($operator, $amount, $type);
        if ($is < 1) {
            $this->form_validation->set_message('_card_valid', "Sorry! Your requested card is not available.");
            return FALSE;
        }

        //Check Destination, Cost, Balance
        $var = $this->lib->verify_card($operator, $amount, $id, $level);

        if ($var['verify_dst'] == 0) {
            $this->form_validation->set_message('_card_valid', "Sorry! You are not allowed to buy card.");
            return FALSE;
        }
        if ($var['verify_bal'] == 0) {
            $this->form_validation->set_message('_card_valid', "Sorry! Not enough balance.");
            return FALSE;
        }
        if ($var['verify_cst'] == 0) {
            $this->form_validation->set_message('_card_valid', "Sorry! rate was not found");
            return FALSE;
        }
    }

    public function bulkflexi()
    {
        $this->session->unset_userdata('duplicate');
        $this->session->unset_userdata('flag');
        $sRow = $this->lib->serviceByUri("bulkflexi");
        $type = $this->session->userdata("type");
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $data["sRow"] = $sRow;
        $data["srv"] = "bulkflexi";

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('list', 'List', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view("header");
            $this->load->view("bulkflexi", $data);
            $this->load->view("footer");
        } else {
            $list = $this->input->post("list", TRUE);
            $data['lid'] = $list;
            $data["title"] = $this->lib->isMyList($list);
            $data["list"] = $this->lib->getBulkList($list, 'exe');
            $this->load->view("header");
            $this->load->view("bulkflexi_2", $data);
            $this->load->view("footer");
        }
    }

    public function bulkflexi_submit()
    {
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        $otp = $this->session->userdata("enable_otp");
        $this->session->unset_userdata('duplicate');
        $this->session->unset_userdata('flag');

        $list = $this->input->post("list", TRUE);
        $data['lid'] = $list;
        $data["title"] = $this->lib->isMyList($list);
        $data["list"] = $this->lib->getBulkList($list, "exe");

        $amount = $this->input->post("amount", TRUE);
        if (strlen($amount)) $this->db->where('lid', $list)->where("rid", $id)->update('flexi_bulk_numbers', array('amount' => $amount));

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        if ($otp == 3) $this->form_validation->set_rules('pin', 'PIN', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', "callback__bulk_valid");
        if ($this->form_validation->run() == FALSE) {
            $this->load->view("header");
            $this->load->view("bulkflexi_2", $data);
            $this->load->view("footer");
        } else {
            //Execute
            $where = array("lid" => $list, 'rid' => $id, "enable" => 1);
            $q = $this->db->select("*")->from("flexi_bulk_numbers")->where($where);
            $result = $q->get()->result();
            foreach ($result as $row):
                //$var=$this->lib->verify_destination(8,$row->number,$row->amount,$row->type,$id,$level);
                $this->lib->bulk_request(8, $row->number, $row->amount, $row->type, $id, $level);
            endforeach;
            $this->lib->SaveLogs('BulkRequest', "Bulk request list (" . $data["title"] . ") executed.");
            redirect("main/req/bulkflexi?sk=1", "location");
        }
    }


    function _bulk_valid()
    {
        $id = $this->session->userdata("id");
        $this->session->unset_userdata('duplicate');
        $this->session->unset_userdata('flag');
        $list = $this->input->post("list", TRUE);
        $ret = $this->lib->bulk_verify($list);

        //print_r($ret['flag']);exit;
        $aR = $this->db->select("sum(amount) amount")->from("flexi_bulk_numbers")->where('lid', $list)->where("rid", $id)->get()->row();
        $dailyLimit = $this->lib->dailyLimit($id, $aR->amount);
        if ($dailyLimit == false) {
            $this->form_validation->set_message('_bulk_valid', "Reseller daily limit exceeded.");
            return FALSE;
        }

        if ($ret['verify_bal'] == 0) {
            $this->form_validation->set_message('_bulk_valid', "Sorry! not enough balance.");
            return FALSE;
        }

        if (isset($ret['duplicate']) && count($ret['duplicate']) > 0) {
            $this->session->set_userdata("duplicate", $ret['duplicate']);
            $this->form_validation->set_message('_bulk_valid', "Can't Process! Duplicate number found on list.");
            return FALSE;
        }

        if (isset($ret['flag']) && count($ret['flag']) > 0) {
            $this->session->set_userdata("flag", $ret['flag']);
            $this->form_validation->set_message('_bulk_valid', "Can't Process! Please check your list for error");
            return FALSE;
        }
    }

    public function bulkflexi_add()
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(16, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('title', 'Name', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('bulkflexi_add');
            $this->load->view('footer');
        } else {
            $data = array(
                'res_id' => $this->session->userdata("id"),
                'title' => $this->input->post('title', TRUE)
            );
            $this->db->insert("flexi_bulk_list", $data);
            $id = $this->db->insert_id();
            redirect("main/bulkflexi_view/$id", 'location');
        }
    }

    public function bulkflexi_copy()
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(16, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('list', 'List', 'trim|required');
        $this->form_validation->set_rules('title', 'Name', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('bulkflexi_copy');
            $this->load->view('footer');
        } else {
            $res_id = $this->session->userdata("id");
            $data = array(
                'res_id' => $res_id,
                'title' => $this->input->post('title', TRUE)
            );
            $this->db->insert("flexi_bulk_list", $data);
            $nid = $this->db->insert_id();

            $list = $this->input->post('list', TRUE);
            $numbers = $this->db->get_where("flexi_bulk_numbers", array("lid" => $list, "rid" => $res_id))->result();

            foreach ($numbers as $num):
                $ins = array(
                    "lid" => $nid,
                    "rid" => $res_id,
                    "number" => $num->number,
                    "amount" => $num->amount,
                    "type" => $num->type
                );
                $this->db->insert("flexi_bulk_numbers", $ins);
            endforeach;

            redirect("main/bulkflexi_view/$nid?sk=copy", 'location');
        }
    }


    public function bulkflexi_view($lid)
    {

        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(16, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $data['lid'] = $lid;
        $data["title"] = $this->lib->isMyList($lid);
        $data["list"] = $this->lib->getBulkList($lid);
        $rid = $this->session->userdata('id');

        if ($_POST) {
            $update = $this->input->post("update", TRUE);
            $new = $this->input->post("new", TRUE);

            if (is_array($update)) {
                foreach ($update as $id => $var):
                    $number = $var['number'];
                    $amount = $var['amount'];
                    if (!isset($var['enable'])) $var['enable'] = 0; else $var['enable'] = 1;
                    if (!strlen($number) || !strlen($amount)) {
                        $this->db->delete('flexi_bulk_numbers', array('id' => $id, "rid" => $rid));
                    } else {
                        $this->db->where('id', $id);
                        $this->db->where('rid', $rid);
                        $this->db->update("flexi_bulk_numbers", $var);
                    }
                endforeach;
            }

            if (is_array($new)) {
                foreach ($new as $var):
                    $number = $var['number'];
                    $amount = $var['amount'];
                    $var['lid'] = $lid;
                    $var['rid'] = $rid;
                    if (!isset($var['enable'])) $var['enable'] = 0; else $var['enable'] = 1;
                    if (strlen($number) && strlen($amount)) {
                        $this->db->insert("flexi_bulk_numbers", $var);
                    }
                endforeach;
            }
            redirect("main/bulkflexi_view/$lid?sk=1", 'location');
        }
        $this->load->view('header');
        $this->load->view('bulkflexi_view', $data);
        $this->load->view('footer');
    }

    public function bulkflexi_manageList($limit = 50, $sort_by = 'id', $sort_order = 'asc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(16, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['limit'] = $limit;


        $data['fields'] = array(
            'id' => 'ID',
            'title' => 'Name'
        );
        $results = $this->flt->bulkList($limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/bulkflexi_manageList/$limit/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 6);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('bulkflexi_manageList', $data);
        $this->load->view('footer');

    }

    public function resellers($rs = 'all', $limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'asc', $offset = 0)
    {
        $level = $this->session->userdata('user_type');
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        if ($_POST) {
            $action = $this->input->post('action');
            $ids = $this->input->post('id');
            $this->lib->rsAction($action, $ids);
            redirect("main/resellers/$rs/$limit/$query_id?sk=3", "location");
        }


        $this->input->load_query($query_id);
        $query_array = array(
            'rs' => $rs,
            'username' => $this->input->get('username'),
            'name' => $this->input->get('name'),
            'mobile' => $this->input->get('mobile'),
            'email' => $this->input->get('email'),
        );

        $data['fields'] = array(
            'user_id' => 'Username',
            'password' => 'Password',
            'mobile' => 'Mobile',
            'balance' => 'Balance',
            'last_login' => 'Last Login',
            'creationdate' => 'Created',
            'status' => 'Status',
        );

        if ($level == 5) $data['fields']['parent'] = 'Parent';

        $results = $this->flt->myReseller($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/resellers/$rs/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 8);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);


        $this->load->view('header');
        $this->load->view('resellers', $data);
        $this->load->view('footer');
    }

    public function addreseller()
    {
        $otp = $this->session->userdata("enable_otp");
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        if ($level == 1) redirect("main", "location");
        $pin_len = $this->lib->getSet("pin_len");
        $interval = $this->lib->getSet("pin_interval");
        $passinterval = $this->lib->getSet("pass_interval");

        if ($otp == 3) $required = "required|"; else $required = "";

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[4]|is_unique[resellers.username]|callback__space');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|callback__complex');
        $this->form_validation->set_rules('name', 'Full name', $required . 'trim');
        $this->form_validation->set_rules('mobile', 'Mobile Number', $required . 'numeric|is_unique[resellers.mobile]');
        $this->form_validation->set_rules('email', 'Email', $required . 'valid_email|is_unique[resellers.email]');
        $this->form_validation->set_rules('note', 'Note');
        $this->form_validation->set_rules('per[]', 'Permision', 'required');
        $this->form_validation->set_rules('balance', 'Balance', 'numeric');

        if ($otp == 3) {

            $this->form_validation->set_rules('pin', 'PIN', 'required|numeric|min_length[' . $pin_len . ']');
        }

        $this->form_validation->set_message('is_unique', 'This %s already may exist in database');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('addreseller');
            $this->load->view('footer');
        } else {
            $ins = $this->lib->getRelation($id, $level - 1);
            $ins["username"] = $this->input->post("username", TRUE);
            $ins["password"] = password_hash($this->input->post("password", TRUE) . $this->lib->passKey(), PASSWORD_BCRYPT);
            $ins["pass_expire"] = date('Y-m-d', strtotime(date("Y-m-d") . "+$passinterval days"));
            $ins["fullname"] = $this->input->post("name", TRUE);
            $ins["mobile"] = $this->input->post("mobile", TRUE);
            $ins["email"] = $this->input->post("email", TRUE);
            $ins["note"] = $this->input->post("note", TRUE);
            $ins["balance"] = "0";
            $ins["device_id"] = "";

            $ins["status"] = $this->input->post("active", TRUE);
            $ins["user_type"] = $level - 1;
            $ins["creationdate"] = date('Y-m-d');
            $ins["cookie"] = uniqid("QA");
            $ins["currency"] = $this->session->userdata("currency");

            if ($otp == 3) {
                $ins["pin"] = password_hash($this->input->post("pin", TRUE) . $this->lib->passKey(), PASSWORD_BCRYPT);
                $ins["pin_expire"] = date('Y-m-d', strtotime(date("Y-m-d") . "+$interval days"));
            }

            //Permision
            $pType = 0;
            $per = $this->input->post('per', TRUE);
            foreach ($per as $i):
                $pType += $i;
            endforeach;
            $ins['type'] = $pType;
            //End Permision

            //Lets insert into database
            $this->db->insert("resellers", $ins);
            $new_id = $this->db->insert_id();
            $this->lib->SaveLogs('AddReseller', "New reseller added with username: $ins[username]");

            //Process starting balance
            $balance = $this->input->post("balance", TRUE);
            $limit = $this->lib->isBalLimit($balance, 1);
            if ($balance > 0 && $limit == true) {
                $this->lib->addBal($new_id, $balance);
                $pdata = array(
                    'bal_from' => $id,
                    'bal_to' => $new_id,
                    'amount' => $balance,
                    'actual' => $this->lib->getBal($new_id),
                    'type' => 'transfer',
                    'logtime' => date('Y-m-d H:i:s'),
                    'note' => 'Starting balance',
                );
                $this->db->insert('flexi_transfer_log', $pdata);
                $this->lib->SaveLogs('Payments', "Payment amount: $balance added as starting balance to $ins[username].");
            }

            //Lets copy Template
            $q = $this->db->get("ratestable");
            foreach ($q->result() as $row):
                $rData = array(
                    'res_id' => $new_id,
                    'service_id' => $row->service_id,
                    'type' => $row->type,
                    'prefix' => $row->prefix,
                    'rate' => $row->rate,
                    'commision' => $row->commision,
                    'charge' => $row->charge,
                    'enable' => 1
                );
                $this->db->insert("rates", $rData);
            endforeach;
            //Now go to rate management
            redirect("main/rates/$new_id?sk=new", "location");
        }
    }


    public function editreseller($rid)
    {
        $otp = $this->session->userdata("enable_otp");
        $id = $this->session->userdata("id");
        $level = $this->session->userdata("user_type");
        if ($level == 1) redirect("main", "location");

        $rRow = $this->lib->getUser($rid);
        if ($level < 5) {
            if ($rRow->parent != $id) redirect("main", "location");
        } else if ($level == 5) {
            if ($rRow->rs5 != $id) redirect("main", "location");
        }

        $pin_len = $this->lib->getSet("pin_len");
        $interval = $this->lib->getSet("pin_interval");
        $passinterval = $this->lib->getSet("pass_interval");

        $fakepin = "";
        for ($i = 0; $i < $pin_len; $i++):
            $fakepin = $fakepin . "*";
        endfor;

        $data["rRow"] = $rRow;
        $data["id"] = $id;
        $data["rid"] = $rid;
        $data["level"] = $level;
        $data["fakepin"] = $fakepin;

        if ($otp == 3) $required = "required|"; else $required = "";

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $iPassword = $this->input->post("password", TRUE);
        $iPin = $this->input->post("pin", TRUE);
        if ($iPassword != "********") $this->form_validation->set_rules('password', 'Password', 'trim|required|callback__complex');
        $this->form_validation->set_rules('name', 'Full name', $required . 'trim');
        $this->form_validation->set_rules('mobile', 'Mobile Number', $required . 'numeric|edit_unique[resellers.mobile.' . $rid . ']');
        $this->form_validation->set_rules('email', 'Email', $required . 'valid_email|edit_unique[resellers.email.' . $rid . ']');
        $this->form_validation->set_rules('note', 'Note');
        $this->form_validation->set_rules('per[]', 'Permision', 'required');
        $this->form_validation->set_rules('balance', 'Balance', 'numeric');


        if ($otp == 3) {
            if ($iPin != $fakepin) {
                $this->form_validation->set_rules('pin', 'PIN', 'required|numeric|min_length[' . $pin_len . ']');
            }
        }

        $this->form_validation->set_message('is_unique', 'This %s already may exist in database');


        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('editreseller', $data);
            $this->load->view('footer');
        } else {
            //Populate Data
            $ins["fullname"] = $this->input->post("name", TRUE);
            $ins["mobile"] = $this->input->post("mobile", TRUE);
            $ins["email"] = $this->input->post("email", TRUE);
            $ins["note"] = $this->input->post("note", TRUE);

            //Permision
            $pType = 0;
            $per = $this->input->post('per', TRUE);
            foreach ($per as $i):
                $pType += $i;
            endforeach;
            $ins['type'] = $pType;
            //End Permision

            if ($iPassword != "********") {
                $ins["password"] = password_hash($this->input->post("password", TRUE) . $this->lib->passKey(), PASSWORD_BCRYPT);
                $ins["cookie"] = uniqid("QA");
                $ins["pass_expire"] = date('Y-m-d', strtotime(date("Y-m-d") . "+$passinterval days"));
                $ins["device_id"] = "";
            }

            if ($otp == 3) {
                if ($iPin != $fakepin) {
                    $ins["pin"] = password_hash($this->input->post("pin", TRUE) . $this->lib->passKey(), PASSWORD_BCRYPT);
                    $ins["pin_expire"] = date('Y-m-d', strtotime(date("Y-m-d") . "+$interval days"));
                    $ins["cookie"] = uniqid("QA");
                    $ins["device_id"] = "";
                }
            }

            $ins["status"] = $this->input->post("active", TRUE);

            $this->db->where("id", $rid);
            $this->db->update("resellers", $ins);
            if ($rRow->user_type != 1 && $rRow->status != $ins["status"]) {
                $this->db->query("UPDATE resellers SET status='" . $ins['status'] . "' WHERE rs" . $rRow->user_type . "='" . $rid . "' AND status!=3");
            }

            //Disable/Enable Rates
            $rMod = $this->lib->getType($pType);
            $this->db->query("UPDATE rates SET enable='0' WHERE res_id='$rid'");
            foreach ($rMod as $srv):
                $this->db->query("UPDATE rates SET enable='1' WHERE res_id='$rid' AND service_id='$srv'");
            endforeach;

            $this->lib->SaveLogs('EditReseller', "OldData: $rRow->username,$rRow->fullname,$rRow->mobile,$rRow->email,$rRow->type,****,$rRow->status NewValue: $ins[fullname],$ins[mobile],$ins[email],$ins[type],$iPin,$ins[status]");
            //Oky We are done

            if ($level == 5) $back = "/" . $rRow->user_type;
            else $back = null;
            redirect("main/resellers" . $back . "?sk=1", "location");
        }
    }


    function _space($str_in = '')
    {
        if (!preg_match("/^[a-zA-Z0-9_.@-]+$/", $str_in)) {
            $this->form_validation->set_message('_space', 'Only alphanumeric characters allowed');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function _verify_pin()
    {
        $checkpoint = 1;
        $otp = $this->lib->getSet("reseller_otp");
        $attmp = $this->session->userdata('attmp');
        if (!strlen($attmp)) $attmp = 3;
        $id = $this->session->userdata('id');
        $type = $this->session->userdata('user_type');

        $pin = $this->input->post("pin", TRUE);
        $row = $this->lib->getUser($id);
        $expire = $this->lib->dateDiff($row->pin_expire);
        $interval = $this->lib->getSet("pin_interval");

        //print_r($_POST); exit;

        if ($otp == 1) {
            //APP
            $totp = $this->lib->totp();
            $otp_key = $this->session->userdata("otp_key");
            $checkResult = $totp->verifyCode($otp_key, $pin, 0);
            if (!$checkResult) {
                $attmp = $attmp - 1;
                if ($attmp < 1) {
                    $this->lib->inActive_all($id, $type);
                    $this->lib->SaveLogs('2Step', 'User has been deactivated due to invalid OTP');
                    $this->session->sess_destroy();
                    redirect('login?sk=inActive', 'location');
                }
                $this->session->set_userdata('attmp', $attmp);
                $this->form_validation->set_message('_verify_pin', "Invalid OTP Code, $attmp attempt left.");
                $this->lib->SaveLogs('2Step', 'Login attempt via Invalid OTP');
                RETURN FALSE;
            } else {
                //echo "RIGHT";
                RETURN TRUE;
            }

        } else if ($otp == 2) {
            //SMS Code
            $row = $this->lib->getUser($id);
            if (password_verify($pin . $this->lib->passKey(), $row->sms_code)) {
                return TRUE;
            } else {
                $attmp = $attmp - 1;
                if ($attmp < 1) {
                    $this->lib->inActive_all($id, $type);
                    $this->lib->SaveLogs('2Step', 'User has been deactivated due to invalid SMS Code');
                    redirect('login?sk=inActive', 'location');
                }
                $this->session->set_userdata('attmp', $attmp);
                $this->form_validation->set_message('_verify_pin', "Your SMS Code is invalid, $attmp attempt left.");
                $this->lib->SaveLogs('2Step', 'User entered Invalid SMS Code');
                return FALSE;
            }

        } else if ($otp == 3) {
            if (password_verify($pin . $this->lib->passKey(), $row->pin)) {
                if ($expire > $interval) {
                    $checkpoint = 0;
                    $this->form_validation->set_message('_verify_pin', "Your pin has expired. Please contact with your provider");
                    return FALSE;
                }
            } else {
                $attmp = $attmp - 1;
                if ($attmp < 1) {
                    $this->lib->inActive_all($id, $type);
                    redirect('login?sk=inActive', 'location');
                }
                $this->session->set_userdata('attmp', $attmp);
                $this->form_validation->set_message('_verify_pin', "Your pin is invalid, $attmp attempt left.");
                return FALSE;
            }
        }


    }

    public function paymentAdd()
    {
        $data = $this->input->get('data', true);
        $get = $this->lib->getVal($data);
        if (!isset($get['id']) || !isset($get['action'])) exit;
        $rid = $get['id'];
        $rRow = $this->lib->getUser($rid);
        $id = $this->session->userdata("id");
        $lbl = $this->session->userdata("user_type");
        if ($lbl < 5) {
            if ($rRow->parent != $id) exit("Invalid Token");
        } else if ($lbl == 5) {
            if ($rRow->rs5 != $id) exit("Invalid Token");
        }

        $var["rRow"] = $rRow;
        $var["data"] = $data;

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('paymentAdd', $var);
        } else {
            $sk = $this->input->post('sk', TRUE);
            if ($sk == 'confirm') {
                $amount = $this->input->post('amount', true);
                $type = $this->input->post('type', true);
                $date = $this->input->post('date', true);
                $desc = $this->input->post('desc', true);
                $addeddBy = $this->session->userdata("fullname");


                $usd = round($amount / $this->lib->exRate($rRow->currency), 4);

                //OverDraft
                $limit = $this->lib->isBalLimit($usd, $type);
                if ($limit == false) redirect("main/paymentAdd?data=$data&sk=false", 'location');

                if (strlen($desc)) {
                    $desc = $desc . " | By " . $addeddBy;
                } else {
                    $desc = "By " . $addeddBy;
                }
                $bal_from = $id;
                $bal_to = $rRow->id;
                $this->lib->SaveLogs('Payment', "User:$rRow->username,Current:$rRow->balance,New:$amount,Type:$type");

                if ($type == 1) {
                    $this->lib->addBal($rRow->id, $usd);
                    $typew = 'transfer';
                }
                if ($type == 3) {
                    $this->lib->dedBal($rRow->id, $usd);
                    $typew = 'return';
                }

                $dataIns = array(
                    'bal_from' => $bal_from,
                    'bal_to' => $bal_to,
                    'bal_currency' => $rRow->currency,
                    'amount' => $usd,
                    'actual' => $this->lib->getBal($rRow->id),
                    'type' => $typew,
                    'logtime' => date('Y-m-d H:i:s'),
                    'note' => $desc
                );
                $Ins = $this->db->insert('flexi_transfer_log', $dataIns);
                if ($Ins) redirect("main/paymentAdd?data=$data&sk=$type", 'location');
            } else {
                $this->load->view('paymentConfirm', $var);
            }
        }
    }

    public function rsHistory($id)
    {
        $data['id'] = $id;
        $this->load->view('rsHistory', $data);
    }


    public function rates($rid)
    {
        $otp = $this->session->userdata("enable_otp");
        $id = $this->session->userdata("id");
        $rRow = $this->lib->getUser($rid);
        if ($rRow->parent != $id) redirect("main", "location");

        $data['rRow'] = $rRow;
        $data['rid'] = $rid;
        $data['rates'] = $this->lib->getRates($rid);

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
//	$this->form_validation->set_rules('pin', 'PIN', 'trim|required|numeric|callback__verify_pin');
        $this->form_validation->set_rules('valid', 'valid', 'trim');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('rates', $data);
            $this->load->view('footer');
        } else {
            $update = $this->input->post("update", TRUE);
            $new = $this->input->post("new", TRUE);
            $exRate = $this->lib->exRate($this->session->userdata("currency"));

            foreach ($update as $id => $var):
                $upd = array(
                    "commision" => $var['comm'],
                    "charge" => $var['charge'],
                    "enable" => $var['enable']
                );
                $this->db->where('id', $id);
                $this->db->update("rates", $upd);
            endforeach;

            //Global
            $gcomission = $this->input->post("gcomission");
            $gcharge = $this->input->post("gcharge");
            $q = $this->db->get_where("rates_global", array("rid" => $rid));
            if ($q->num_rows() > 0) {
                $this->db->where("rid", $rid)->update("rates_global", array("charge" => $gcharge, "comission" => $gcomission));
            } else {
                $this->db->insert("rates_global", array("rid" => $rid, "charge" => $gcharge, "comission" => $gcomission));
            }

            $this->lib->SaveLogs('RateUpdate', "User: $rRow->username rates updated");
            redirect("main/rates/$rid?sk=1", "location");
        }
    }

    public function rates_sync($rid)
    {
        $id = $this->session->userdata("id");
        $rRow = $this->lib->getUser($rid);
        if ($rRow->parent != $id) redirect("main", "location");

        $q = $this->db->get("ratestable");
        foreach ($q->result() as $row):
            $rData = array(
                'res_id' => $rid,
                'service_id' => $row->service_id,
                'type' => $row->type,
                'prefix' => $row->prefix,
                'rate' => $row->rate,
                'commision' => $row->commision,
                'charge' => $row->charge,
                'enable' => 1
            );
            //Precheck
            $chk = $this->lib->iSync($rData);
            if ($chk == 0) {
                $this->db->insert("rates", $rData);
            }
        endforeach;
        $this->lib->SaveLogs('RateSynchronize', "User: $rRow->username Rate Synchronize");
        redirect("main/rates/$rid?sk=3", "location");
    }

    public function pending($limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);
        $rsId = $this->input->get('reseller');

        $query_array = array(
            'number' => $this->input->get('number'),
            'reseller' => $this->input->get('reseller'),
            'service' => $this->input->get('service'),
            'status' => $this->input->get('status')
        );

        $data['fields'] = array(
            'id' => 'ID',
            'receiver' => 'Number',
            'amount' => 'Amount',
            'cost' => 'Cost',
            'type' => 'Type',
            'service_id' => 'Service',
            'sender' => 'Sender',
            'last_update' => 'Update Time',
            'status' => 'Status'
        );
        $results = $this->flt->myPending($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/pending/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('pending', $data);
        $this->load->view('footer');
    }

    public function history($srv = 'all', $limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        $this->input->load_query($query_id);
        $from = $this->input->get('from');
        if (!strlen($from)) $from = date("Y-m-d");
        $to = $this->input->get('to');
        if (!strlen($to)) $to = date("Y-m-d");
        $query_array = array(
            'id' => $this->input->get('id'),
            'logic' => $this->input->get('logic'),
            'number' => $this->input->get('number'),
            'reseller' => $this->input->get('reseller'),
            'modem' => $this->input->get('modem'),
            'status' => $this->input->get('status'),
            'from' => $from,
            'to' => $to,
        );

        if ($srv != 'all') {
            $sRow = $this->lib->serviceByUri($srv);
            $type = $this->session->userdata("type");
            $mod = $this->lib->getType($type);
            if (!in_array($sRow->type, $mod)) {
                redirect("main?ref=permision", 'location');
            }
            if ($sRow->enable != 1) {
                redirect("main?ref=permision", 'location');
            }
            $data['title'] = $sRow->title;
            $data['service'] = $sRow->type;
            $query_array['service'] = $sRow->type;
        } else {
            $data['title'] = "All";
            $data['service'] = "all";
            $query_array['service'] = "all";
        }

        $data['srv'] = $srv;
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $data['fields'] = array(
            'id' => 'ID',
            'receiver' => 'Number',
            'amount' => 'Amount',
            'cost' => 'Cost',
            'type' => 'Type',
            'service_id' => 'Service',
            'sender' => 'Sender',
            'last_update' => 'Update Time',
            'status' => 'Status',
            'transactionid' => 'Trans.ID',
            'bal' => 'Last Balance',
        );
        $results = $this->flt->myHistory($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/history/$srv/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 8);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('history', $data);
        $this->load->view('footer');
    }

    public function cardHistory($limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(2, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);
        $rsId = $this->input->get('reseller');
        $from = $this->input->get('from');
        if (!strlen($from)) $from = date("Y-m-d");
        $to = $this->input->get('to');
        if (!strlen($to)) $to = date("Y-m-d");

        $query_array = array(
            'operator' => $this->input->get('operator'),
            'type' => $this->input->get('type'),
            'amount' => $this->input->get('amount'),
            'reseller' => $this->input->get('reseller'),
            'from' => $from,
            'to' => $to
        );

        $data['fields'] = array(
            'id' => 'ID',
            'opt_id' => 'Operator',
            'type' => 'Type',
            'amnt_id' => 'Amount',
            'receiver' => 'Receiver',
            'mycost' => 'Cost',
            'sender' => 'Reseller',
            'date_update' => 'Date',
            'bal' => 'Last Balance'
        );
        $results = $this->flt->cardHistory($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/cardHistory/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('cardHistory', $data);
        $this->load->view('footer');
    }

    public function remithistory($limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(4, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);
        $rsId = $this->input->get('reseller');
        $from = $this->input->get('from');
        if (!strlen($from)) $from = date("Y-m-d");
        $to = $this->input->get('to');
        if (!strlen($to)) $to = date("Y-m-d");

        $query_array = array(
            'receiver' => $this->input->get('receiver'),
            'country' => $this->input->get('country'),
            'bank' => $this->input->get('bank'),
            'reseller' => $this->input->get('reseller'),
            'status' => $this->input->get('status'),
            'from' => $from,
            'to' => $to
        );

        $data['fields'] = array(
            'id' => 'ID',
            'receiver' => 'Account ID',
            'amount' => 'Amount',
            'mycost' => 'Cost',
            'bank' => 'Bank Name',
            'reseller' => 'Reseller',
            'transactionid' => 'Transaction ID',
            'status' => 'Status',
            'bal' => 'Last Balance',
            'last_update' => 'Last Update'
        );
        $results = $this->flt->bankHistory($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/remithistory/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('remithistory', $data);
        $this->load->view('footer');
    }

    public function pintransferhistory($limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(4, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);
        $rsId = $this->input->get('reseller');
        $from = $this->input->get('from');
        if (!strlen($from)) $from = date("Y-m-d");
        $to = $this->input->get('to');
        if (!strlen($to)) $to = date("Y-m-d");

        $query_array = array(
            'receiver' => $this->input->get('receiver'),
            'country' => $this->input->get('country'),
            'reseller' => $this->input->get('reseller'),
            'status' => $this->input->get('status'),
            'from' => $from,
            'to' => $to
        );

        $data['fields'] = array(
            'id' => 'ID',
            'receiver' => 'PIN',
            'amount' => 'Amount',
            'mycost' => 'Cost',
            'reseller' => 'Reseller',
            'transactionid' => 'Transaction ID',
            'status' => 'Status',
            'bal' => 'Last Balance',
            'last_update' => 'Last Update'
        );
        $results = $this->flt->pinHistory($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/pintransferhistory/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('pintransferhistory', $data);
        $this->load->view('footer');
    }

    public function bankdetails()
    {
        $rid = $this->session->userdata("id");
        $data = $this->input->get('data', true);
        $get = $this->lib->getVal($data);
        if (!isset($get['id']) || !isset($get['action'])) exit;
        $view['id'] = $get['id'];
        $this->load->view('bankdetails', $view);
    }

    public function pindetails()
    {
        $rid = $this->session->userdata("id");
        $data = $this->input->get('data', true);
        $get = $this->lib->getVal($data);
        if (!isset($get['id']) || !isset($get['action'])) exit;
        $view['id'] = $get['id'];
        $this->load->view('pindetails', $view);
    }

    public function viewCard()
    {
        $myId = $this->session->userdata("id");
        $data = $this->input->get('data', true);
        $get = $this->lib->getVal($data);
        if (!isset($get['id']) || !isset($get['card_id']) || !isset($get['rid'])) exit;
        $rid = $get['rid'];
        $card_id = $get['card_id'];
        if ($myId != $rid) echo "<p style='color:red'>You are not allowed to view this card</p>";
        $view['row'] = $this->lib->myCard($get['card_id']);
        $this->load->view('myCard', $view);
    }

    public function viewSMS()
    {
        $myId = $this->session->userdata("id");
        $data = $this->input->get('data', true);
        $get = $this->lib->getVal($data);
        if (!isset($get['id']) || !isset($get['sender'])) exit;
        $id = $get['id'];
        $rid = $get['sender'];
        if ($myId != $rid) echo "<p style='color:red'>You are not allowed to view this SMS content</p>";
        $d = $this->db->select("*")->from("sms_req")->where("id", $id);
        $view["row"] = $d->get()->row();
        $this->load->view('viewSMS', $view);
    }

    public function details()
    {
        $data = $this->input->get('data', true);
        $get = $this->lib->getVal($data);
        if (!isset($get['id']) || !isset($get['action'])) exit;
        $id = $get['id'];
        $str = $get['str'];
        $view['row'] = $this->lib->getReq($id, $str);
        $this->load->view('details', $view);
    }


    public function payments($id = "all", $limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        $data['id'] = $id;
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);
        $rsId = $this->input->get('reseller');
        if (strlen($rsId)) $data['id'] = $rsId;

        $from = $this->input->get('from');
        if (!strlen($from)) $from = date("Y-m-d");
        $to = $this->input->get('to');
        if (!strlen($to)) $to = date("Y-m-d");

        $query_array = array(
            'id' => $data['id'],
            'type' => $this->input->get('type'),
            'from' => $from,
            'to' => $to
        );

        $data['fields'] = array(
            'id' => 'ID',
            'logtime' => 'Time',
            'bal_to' => 'Reseller',
            'note' => 'Note',
            'type' => 'Type',
            'amount' => 'Amount',
            'actual' => 'Balance'
        );
        $results = $this->flt->myPaymnets($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];
        $data['canceled'] = $results['canceled'];
        $data['transfer'] = $results['transfer'];
        $data['refund'] = $results['refund'];

        $url = "main/payments/$data[id]/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 8);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('payments', $data);
        $this->load->view('footer');
    }

    public function receivedInitial($type = null)
    {
        $data = array("type" => '');
        $query_id = $this->input->save_query($data);
        redirect("main/received/50/$query_id");
    }

    public function received($limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {

        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);

        $query_array = array(
            'type' => $this->input->get('type'),
            'from' => $this->input->get('from'),
            'to' => $this->input->get('to')
        );

        $data['fields'] = array(
            'logtime' => 'Time',
            'bal_from' => 'From',
            'note' => 'Note',
            'type' => 'Type',
            'amount' => 'Amount',
            'actual' => 'Balance'
        );
        $results = $this->flt->myReveived($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['canceled'] = $results['canceled'];
        $data['transfer'] = $results['transfer'];
        $data['refund'] = $results['refund'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/received/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 8);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('received', $data);
        $this->load->view('footer');
    }


    public function search($id = null)
    {
        $plc = null;
        if ($id != null) $plc = "$id/";
        $query_id = $this->input->save_query($_POST);
        $url = $this->input->post("uri", TRUE);
        $rows = $this->input->post('rows', TRUE);
        redirect("$url/$plc$rows/$query_id");
    }

    public function servicesearch()
    {
        $type = $this->input->post('service', TRUE);
        if ($type != 'all') {
            $q = $this->db->select("spaceuri")->from("services")->where('type', $type)->limit(1);
            $r = $q->get()->row();
            $spaceuri = $r->spaceuri;
        } else {
            $spaceuri = "all";
        }
        $query_id = $this->input->save_query($_POST);
        $url = $this->input->post("uri", TRUE);
        $rows = $this->input->post('rows', TRUE);
        redirect("main/history/$spaceuri/$rows/$query_id");
    }

    public function bulkflexi_delist($id)
    {
        $rid = $this->session->userdata('id');
        $lid = $id;
        $this->db->delete('flexi_bulk_list', array('id' => $lid, 'res_id' => $rid));
        $this->db->delete('flexi_bulk_numbers', array('lid' => $lid, 'rid' => $rid));
    }

    public function bulkflexi_delnumber($id)
    {
        $rid = $this->session->userdata('id');
        $id = $id;
        $this->db->delete('flexi_bulk_numbers', array('id' => $id, 'rid' => $rid));
    }

    public function addressbook($limit = 50, $sort_by = 'id', $sort_order = 'asc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(1, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['limit'] = $limit;

        $data['fields'] = array(
            'id' => 'ID',
            'title' => 'Name'
        );

        $results = $this->flt->addressbook($limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/addressbook/$limit/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 6);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('addressbook', $data);
        $this->load->view('footer');

    }

    public function number_add($id)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(1, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $data["title"] = $this->lib->isSmsList($id);
        $data["id"] = $id;

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('number', 'Number', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('number_add', $data);
            $this->load->view('footer');
        } else {
            $data = array(
                'lid' => $id,
                'uid' => $this->session->userdata("id"),
                'number' => $this->input->post('number', TRUE),
                'firstname' => $this->input->post('firstname', TRUE),
                'lastname' => $this->input->post('lastname', TRUE)
            );
            $this->db->insert("sms_contacts", $data);
            redirect("main/addressbook_view/$id?sk=add", 'location');
        }
    }

    public function addressbook_add()
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(1, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('title', 'Name', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('addressbook_add');
            $this->load->view('footer');
        } else {
            $data = array(
                'res_id' => $this->session->userdata("id"),
                'title' => $this->input->post('title', TRUE)
            );
            $this->db->insert("sms_list", $data);
            $id = $this->db->insert_id();
            redirect("main/addressbook_view/$id?sk=new", 'location');
        }
    }

    public function addressbook_edit($id)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(1, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $rid = $this->session->userdata('id');

        //verify id
        $q = $this->db->select()->from("sms_contacts")->where('id', $id)->limit(1);
        $d = $q->get();
        if ($d->num_rows() == 1) {
            $r = $d->row();
            if ($rid != $r->uid) redirect("main", "location");
        } else {
            redirect("main", "location");
        }
        $data['row'] = $r;
        $data['id'] = $id;
        $data['lid'] = $r->lid;

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('number', 'Number', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('addressbook_edit', $data);
            $this->load->view('footer');
        } else {
            $update = array(
                'number' => $this->input->post('number', TRUE),
                'firstname' => $this->input->post('firstname', TRUE),
                'lastname' => $this->input->post('lastname', TRUE),
            );
            $this->db->where("id", $id);
            $this->db->update("sms_contacts", $update);
            redirect("main/addressbook_view/$r->lid?sk=1", 'location');
        }
    }

    public function addressbook_view($id, $limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'asc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(1, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        //Is My List
        $data["title"] = $this->lib->isSmsList($id);

        $data['id'] = $id;
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);

        $query_array = array(
            'id' => $id,
            'firstname' => $this->input->get('firstname'),
            'lastname' => $this->input->get('lastname'),
            'number' => $this->input->get('number')
        );

        $data['fields'] = array(
            'number' => 'Number',
            'firstname' => 'First Name',
            'lastname' => 'Last Name'
        );
        $results = $this->flt->myListNumber($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/addressbook_view/$data[id]/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 8);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('addressbook_view', $data);
        $this->load->view('footer');
    }

    public function del_sms_number($id)
    {
        $uid = $this->session->userdata("id");
        $where = array('id' => $id, 'uid' => $uid);
        $this->db->delete('sms_contacts', $where);
    }

    public function del_sms_list($id)
    {
        $uid = $this->session->userdata("id");
        //Delete List
        $this->db->delete('sms_list', array("res_id" => $uid, "id" => $id));
        //Delete Contacts
        $where = array('lid' => $id, 'uid' => $uid);
        $this->db->delete('sms_contacts', $where);
    }

    function _issmsApi()
    {
        //Check is api exist
        $api = $this->lib->smsApi();
        if ($api->found == 0) {
            $this->form_validation->set_message('_issmsApi', "No active SMS API found.");
            return FALSE;
        } else {
            return true;
        }

    }

    public function bulksms()
    {
        $sRow = $this->lib->serviceByUri("sms");
        $type = $this->session->userdata("type");
        $id = $this->session->userdata('id');
        $level = $this->session->userdata('user_type');
        $mask = $this->lib->isMask($id);
        $cnf["mask"] = $mask;
        //Validate Service
        $mod = $this->lib->getType($type);
        if (!in_array($sRow->type, $mod)) {
            redirect("main?ref=permision", 'location');
        }
        if ($sRow->enable != 1) {
            redirect("main?ref=permision", 'location');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('list', 'List', 'required');
        if ($mask == 1) {
            $this->form_validation->set_rules('from', 'From', 'trim|required|max_length[11]');
        }
        $this->form_validation->set_rules('message', 'message', 'trim|required');
        $this->form_validation->set_rules('valid', 'valid', 'callback__issmsApi');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view("bulksms", $cnf);
            $this->load->view('footer');
        } else {
            $response = array();
            $error = array();
            $list = $this->input->post("list", TRUE);
            $message = $this->input->post("message", TRUE);
            $from = $this->input->post("from", TRUE);

            if ($mask == 0) {
                $from = $this->session->userdata('fullname');
                $from = substr($from, 0, 11);
            }
            //Process here
            $myList = $this->lib->getSMSList($list);

            foreach ($myList as $row):
                $message = str_replace("#FIRSTNAME#", $row->firstname, $message);
                $message = str_replace("#LASTNAME#", $row->lastname, $message);
                $amount = ceil(strlen(utf8_decode($message)) / 160);
                //Verify Cost + Number
                $var = $this->lib->verify_destination($sRow->type, $row->number, $amount, 0, $id, $level);
                if ($var['verify_dst'] == 0) {
                    $error[$row->id] = "Sorry! Rate prefix was not found.";
                }
                if ($var['verify_bal'] == 0) {
                    $error[$row->id] = "Sorry! Not enough balance.";
                }
                if ($var['verify_cst'] == 0) {
                    $error[$row->id] = "Sorry! rate was not found";
                }

                if (!isset($error[$row->id])) {
                    $response[$row->id] = $this->lib->sendSMS($row->number, $from, $message, $id, $level);
                }
            endforeach;
            $send['error'] = $error;
            $send['response'] = $response;
            $this->load->view('header');
            $this->load->view("bulksms_result", $send);
            $this->load->view('footer');
        }
    }


    public function smsHistory($limit = 50, $query_id = 0, $sort_by = 'id', $sort_order = 'desc', $offset = 0)
    {
        //Validate Service
        $type = $this->session->userdata("type");
        $mod = $this->lib->getType($type);
        if (!in_array(1, $mod)) {
            redirect("main?ref=permision", 'location');
        }

        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);
        $rsId = $this->input->get('reseller');
        $from = $this->input->get('from');
        if (!strlen($from)) $from = date("Y-m-d");
        $to = $this->input->get('to');
        if (!strlen($to)) $to = date("Y-m-d");

        $query_array = array(
            'number' => $this->input->get('number'),
            'sender' => $this->input->get('sender'),
            'reseller' => $this->input->get('reseller'),
            'from' => $from,
            'to' => $to
        );

        $data['fields'] = array(
            'id' => 'ID',
            'sender_id' => 'Sender',
            'receiver' => 'Receiver',
            'mycost' => 'Cost',
            'sender' => 'Reseller',
            'status' => 'Status',
            'send_time' => 'Date',
            'bal' => 'Last Balance'
        );
        $results = $this->flt->smsHistory($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/smsHistory/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('smsHistory', $data);
        $this->load->view('footer');
    }

    public function profit()
    {
        $this->load->view('header');
        $this->load->view('profit');
        $this->load->view('footer');
    }

    public function balance()
    {
        $this->load->view('header');
        $this->load->view('balance');
        $this->load->view('footer');
    }

    public function report()
    {
        $this->load->view('header');
        $this->load->view('report');
        $this->load->view('footer');
    }

    public function accesslogs()
    {
        $this->load->view('header');
        $this->load->view('accesslogs');
        $this->load->view('footer');
    }

    public function openticket()
    {
        $alw = $this->lib->getSet('allow_ticket');
        if ($alw == 0) redirect('main?sk=noaccess', 'location');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('subject', 'Subject', 'trim|required');
        $this->form_validation->set_rules('details', 'Message', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('openticket');
            $this->load->view('footer');
        } else {
            $id = $this->session->userdata('id');
            $rRow = $this->lib->getUser($id);
            $ins = array(
                'title' => $this->input->post('subject', TRUE),
                'message' => $this->input->post('details', TRUE),
                'sender' => $rRow->id,
                'rs5' => $rRow->rs5,
                'rs4' => $rRow->rs4,
                'rs3' => $rRow->rs3,
                'rs2' => $rRow->rs2,
                'status' => 1,
            );
            $this->db->insert("support_ticket", $ins);

            $adminemail = $this->lib->getSet('email');
            if (strlen($adminemail)) {
                $msg = $this->input->post('details', TRUE);
                $headers = '"MIME-Version: 1.0' . PHP_EOL;
                $headers .= 'Content-Type: text/plain; charset=ISO-8859-1' . PHP_EOL;
                $headers .= 'From: ' . $this->lib->getSet('brandname') . '<' . $rRow->email . '>' . PHP_EOL;
                $send = mail($adminemail, $this->input->post('subject', TRUE), $msg, $headers);
            }

            redirect("main/viewtickets?sk=new", 'location');
        }
    }

    public function replyticket($id = null)
    {
        $alw = $this->lib->getSet('allow_ticket');
        if ($alw == 0) redirect('main?sk=noaccess', 'location');
        if (!strlen($id)) redirect('main', 'location');
        $is = $this->lib->isMyTT($id);
        if ($is == 0) redirect('main', 'location');

        $data['row'] = $this->lib->getTicket($id);
        $data['reply'] = $this->lib->getReplys($id);
        $data['id'] = $id;
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('details', 'Message', 'trim');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('replyticket', $data);
            $this->load->view('footer');
        } else {
            $status = $this->input->post("status", TRUE);
            $details = $this->input->post("details", TRUE);
            $rid = $this->session->userdata('id');
            $ins = array(
                'tid' => $id,
                'message' => $this->input->post('details', TRUE),
                'sender' => $rid,
                'is_read' => 0
            );
            if (strlen($details)) $this->db->insert("support_reply", $ins);
            $this->db->query("UPDATE support_ticket SET status='$status' WHERE id='$id' LIMIT 1");
            redirect("main/replyticket/$id?sk=1", 'location');
        }
    }


    public function viewtickets($limit = 50, $query_id = 0, $sort_by = 'last_update', $sort_order = 'desc', $offset = 0)
    {
        $alw = $this->lib->getSet('allow_ticket');
        if ($alw == 0) redirect('main?sk=noaccess', 'location');
        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;

        $this->input->load_query($query_id);

        $query_array = array(
            'id' => $this->input->get('id'),
            'text' => $this->input->get('text'),
            'status' => $this->input->get('status')
        );

        $data['fields'] = array(
            'id' => 'ID',
            'title' => 'Subject',
            'sender' => 'Sender',
            'status' => 'Status',
            'last_update' => 'Last Update',
        );
        $results = $this->flt->myTicket($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/viewtickets/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('viewtickets', $data);
        $this->load->view('footer');
    }

    public function pin()
    {
        $otp = $this->session->userdata("enable_otp");
        if ($otp == 1) redirect("main");
        $pin_len = $this->lib->getSet("pin_len");
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('pin', 'Current Pin', 'trim|required|numeric|callback__verify_pin|callback__same_pin');
        $this->form_validation->set_rules('npin', 'New Pin', 'trim|required|numeric|min_length[' . $pin_len . ']|matches[cpin]');
        $this->form_validation->set_rules('cpin', 'Confirm Pin', 'trim|required|min_length[' . $pin_len . ']|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('pin');
            $this->load->view('footer');
        } else {
            $interval = $this->lib->getSet("pin_interval");
            $today = date('Y-m-d');
            $pin_expire = date('Y-m-d', strtotime($today . " + $interval days"));
            $npin = $this->input->post('npin', TRUE);
            $rid = $this->session->userdata('id');
            $udata = array("pin" => password_hash($npin . $this->lib->passKey(), PASSWORD_BCRYPT), 'pin_expire' => $pin_expire);
            $this->db->where("id", $rid);
            $this->db->update("resellers", $udata);
            $this->lib->SaveLogs('PIN', "User changed pin");
            $this->session->set_userdata('pin_expire', $pin_expire);
            redirect("main/pin?sk=1", 'location');
        }
    }

    public function _same_pin($str)
    {
        $current = $this->input->post("pin", TRUE);
        $new = $this->input->post("npin", TRUE);
        if ($current == $new) {
            $this->form_validation->set_message('_same_pin', "Current and new pin can not be same!");
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function password()
    {
        $pin_len = $this->lib->getSet("pin_len");
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('current', 'Current Password', 'trim|required|callback__verify_pass|callback__same_pass');
        $this->form_validation->set_rules('new', 'New Password', 'trim|required|matches[confirm]|callback__complex');
        $this->form_validation->set_rules('confirm', 'Confirm Password', 'trim|required|min_length[6]');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('password');
            $this->load->view('footer');
        } else {
            $today = date('Y-m-d');
            $interval = $this->lib->getSet("pass_interval");
            $pass_expire = date('Y-m-d', strtotime($today . " + $interval days"));
            $new = $this->input->post('new', TRUE);
            $rid = $this->session->userdata('id');
            $password = password_hash($new . $this->lib->passKey(), PASSWORD_BCRYPT);
            $udata = array("password" => $password, 'cookie' => uniqid("QA"), 'pass_expire' => $pass_expire, "device_id" => "");
            $this->db->where("id", $rid);
            $this->db->update("resellers", $udata);
            $this->lib->SaveLogs('Password', "User changed his password");
            redirect("main/password?sk=1", 'location');
        }
    }

    public function _same_pass($str)
    {
        $current = $this->input->post("current", TRUE);
        $new = $this->input->post("new", TRUE);
        if ($current == $new) {
            $this->form_validation->set_message('_same_pass', "Current and new password can not be same!");
            return FALSE;
        } else {
            return true;
        }
    }

    public function _verify_pass()
    {
        $id = $this->session->userdata('id');
        $current = $this->input->post("current", TRUE);
        $row = $this->lib->getUser($id);
        if (!password_verify($current . $this->lib->passKey(), $row->password)) {
            $this->form_validation->set_message('_verify_pass', "Current password dose not matched.");
            return FALSE;
        } else {
            return true;
        }
    }


    public function apikey($nr = null)
    {
        $id = $this->session->userdata('id');
        $api_verify = $this->session->userdata('api_verify');
        $u = $this->lib->getUser($id);
        if ($u->api_enable == 0) {
            redirect("main?sk=noaccess", 'location');
        }
        $data['key'] = $u->api_key;

        //if Blank
        if (!strlen($u->api_key)) {
            $key = strtoupper(sha1(md5($u->username) . md5($u->cookie . uniqid("KYE"))) . uniqid());
            $this->db->where('id', $id);
            $this->db->where('api_key', "");
            $this->db->update('resellers', array('api_key' => $key));
            $this->lib->SaveLogs('APIKEY', "User generate his API Key");
            $data['key'] = $key;
        }

        if ($nr == "reset" && $api_verify == 1) {
            $key = strtoupper(sha1(md5($u->username) . md5($u->cookie . uniqid("KYE"))) . uniqid());
            $this->db->where('id', $id);
            $this->db->update('resellers', array('api_key' => $key));
            $this->lib->SaveLogs('APIKEY', "User reset his apikey");
            redirect('main/apikey?sk=1', 'location');
        }

        //Verify on Post
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('current', 'Password', 'trim|required|callback__verify_pass');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            if ($api_verify == 1) $this->load->view('apikey_2', $data);
            else $this->load->view('apikey_1', $data);
            $this->load->view('footer');
        } else {
            $this->session->set_userdata('api_verify', 1);
            $this->load->view('header');
            $this->load->view('apikey_2', $data);
            $this->load->view('footer');
        }
    }

    public function api_ip($action, $data)
    {
        $api_verify = $this->session->userdata('api_verify');
        if ($api_verify != 1) exit(0);
        $id = $this->session->userdata('id');

        if ($action == "add") {

            $ex = $this->db->select("count(*) c")->from("api_whitelist")->where("uid", $id)->where("ip", $data)->get()->row();
            if ($ex->c == 0) {
                $ins = array('ip' => $data, 'uid' => $id);
                $this->db->insert("api_whitelist", $ins);
                echo 1;
            } else {
                echo 3;
            }
        }
        if ($action == "del") {
            $del = array('id' => $data, 'uid' => $id);
            $this->db->where($del);
            $this->db->delete("api_whitelist");
            //$this->db->query("DELETE FROM api_whitelist WHERE id='$data' AND uid='$id' LIMIT 1");
            //echo $this->db->last_query();
            echo 1;
        }
    }

    public function myrates($limit = 50, $query_id = 0, $sort_by = 'service_id', $sort_order = 'asc', $offset = 0)
    {

        $data['sort_by'] = $sort_by;
        $data['sort_order'] = $sort_order;
        $data['query_id'] = $query_id;
        $data['limit'] = $limit;
        $currency = $this->session->userdata("currency");
        $ccode = $this->lib->cCode($currency);

        $this->input->load_query($query_id);

        $query_array = array(
            'prefix' => $this->input->get('prefix'),
            'service' => $this->input->get('service')
        );

        $data['fields'] = array(
            'service_id' => 'Service',
            'prefix' => 'Prefix',
            'rate' => 'Rate' . " <small>($ccode)</small>",
            'commision' => 'Commision',
            'charge' => 'Charge',
            'enable' => 'Status',
        );
        $results = $this->flt->myRates($query_array, $limit, $offset, $sort_by, $sort_order);

        $data['results'] = $results['rows'];
        $data['num_results'] = $results['num_rows'];

        $url = "main/myrates/$limit/$query_id/$sort_by/$sort_order";
        $data['page'] = $this->page->links($url, $data['num_results'], $limit, 7);
        $data['showing'] = $this->lib->showing($limit, $offset, $data['num_results']);

        $this->load->view('header');
        $this->load->view('myrates', $data);
        $this->load->view('footer');
    }

    public function branding()
    {
        $var = $this->lib->islevel5();
        if ($var == false) redirect('main?sk');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('brandname', 'Brandname', 'trim|required');
        $this->form_validation->set_rules('toptitle', 'Top Title', 'trim|required');
        $this->form_validation->set_rules('footer', 'Footer Link', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('branding');
            $this->load->view('footer');
        } else {

            $data = array(
                'brandname' => $this->input->post("brandname", TRUE),
                'footer' => $this->input->post("footer", TRUE),
                'email' => $this->input->post("email", TRUE),
                'metatag' => $this->input->post("metatag", TRUE),
                'keywords' => $this->input->post("keywords", TRUE),
                'logo' => $this->input->post("logo", TRUE),
                'custom_script' => base64_encode($_REQUEST["custom_script"])
            );
            $this->db->where("uid", $var)->update("subadmin", $data);
            redirect("main/branding?sk=1", 'location');
        }
    }

    public function theme()
    {
        $var = $this->lib->islevel5();
        if ($var == false) redirect('main?sk');
        $this->load->view('header');
        $this->load->view('theme');
        $this->load->view('footer');
    }

    public function themechange($color)
    {
        $var = $this->lib->islevel5();
        $this->db->where("uid", $var)->update("subadmin", array('login_theme' => $color));
    }


    public function latestupdates()
    {
        $var = $this->lib->islevel5();
        if ($var == false) redirect('main');

        if ($_POST) {
            $updates = $this->input->post("updates", TRUE);
            $this->db->where("uid", $var)->update("subadmin", array('newsScroll' => $updates));
            redirect("main/latestupdates?sk=1", 'location');
        }

        $this->load->view('header');
        $this->load->view('latestupdates');
        $this->load->view('footer');
    }

    public function loginotice()
    {
        $var = $this->lib->islevel5();
        if ($var == false) redirect('main');
        $this->load->view("header");
        $this->load->view("loginotice");
        $this->load->view("footer");
    }

    public function noticeframe()
    {
        $this->load->view("noticeframe");
    }

    function logo_upload()
    {
        $this->load->view('logo_upload');
    }


    public function fillBill($number = "")
    {
        $sender = $this->session->userdata("id");
        $q = $this->db->select('ac_title,ac_area,type')->from('billpay_req')->limit(1, 0)->order_by('id', 'desc')->where(array('sender' => $sender, 'receiver' => $number));
        $query = $q->get();
        if ($query->num_rows() == 1) {
            $r = $query->row();
            echo json_encode($r);
        }
    }

    public function getOperators()
    {
        $this->load->view('getOperators');
    }

    public function profile()
    {
        $this->load->view('header');
        $this->load->view('profile');
        $this->load->view('footer');
    }

    function _complex($str)
    {

        $len = $this->lib->getSet("complex_pass");
        if ($len > 0) {
            if (strlen($str) < $len) {
                $this->form_validation->set_message("_complex", "Minimum Password length is 9");
                return false;
            } else if (!preg_match("#[0-9]+#", $str)) {
                $this->form_validation->set_message("_complex", "Password must include at least one number!");
                return false;
            } else if (!preg_match("#[A-Z]+#", $str)) {
                $this->form_validation->set_message("_complex", "Password must include at least one uppercase!");
                return false;
            } else if (!preg_match("#[a-z]+#", $str)) {
                $this->form_validation->set_message("_complex", "Password must include at least one lowercase!");
                return false;
            } else if (!preg_match('/[\'\/~`\!@#\$%\^&\*\(\)_\-\+=\{\}\[\]\|;:"\<\>,\.\?\\\]/', $str)) {
                $this->form_validation->set_message("_complex", "Password must include at least one symbol!");
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }

    }

    public function getPackage()
    {
        $this->load->view("getPackage");
    }

    public function getIntPack()
    {
        $this->load->view("getIntPack");
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */