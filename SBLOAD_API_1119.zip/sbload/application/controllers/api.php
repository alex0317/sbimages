<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Api Controller
 */

class Api extends CI_Controller {
    const DEBUG = false;
    
    const ADMIN_SECRET_KEY = "helpini_backend";
    
    const STATUS__SUCCESS = 0;
    
    const MESSAGE__SUCCESS = 'Success';
    const MESSAGE__SUCCESS_REQUEST = 'Successfully sent request';
    const MESSAGE__SUCCESS_UPLOAD = 'Successfully Uploaded';
    const MESSAGE__SUCCESS_SAVE = 'Successfully Saved';
    
    const STATUS__BAD_CREDENTIALS = -9;
    const MESSAGE__BAD_CREDENTIALS = "Bad Credentials";

    const STATUS__BAD_REQUEST = -8;
    const MESSAGE__BAD_REQUEST = "Bad Request";
    

    private $STATUSES = array(
        array('code'=>-1, 'message'=>'Failed'),
        array('code'=>1, 'message'=>'No User'),
        array('code'=>2, 'message'=>'Wrong Password'),
        array('code'=>3, 'message'=>'Please Activate Your Account'),
        array('code'=>4, 'message'=>'Already exist same username'),
        array('code'=>5, 'message'=>'Already exist same email'),
        array('code'=>6, 'message'=>'Wrong pin number'),
        array('code'=>7, 'message'=>'Already exist same phone number'),
        array('code'=>8, 'message'=>'Already exist same topic'),
        array('code'=>9, 'message'=>'You have already reported spam'),
        array('code'=>10, 'message'=>'You have already voted'),
        array('code'=>11, 'message'=>'You have already liked'),
        array('code'=>12, 'message'=>'You have never liked'),
        array('code'=>13, 'message'=>'This email or user name does not exist'),
        array('code'=>14, 'message'=>'Invalid Verification Code or Expired'),
        array('code'=>15, 'message'=>'Failed to convert to text from audio'),
        array('code'=>16, 'message'=>'Balance is insufficient'),
        array('code'=>17, 'message'=>'Amount is out of range'),
        array('code'=>18, 'message'=>'No rate for this number'),
        array('code'=>19, 'message'=>'Can not create child reseller because the user type of parent reseller is 1.'),
    );
    
    const RESOURCE_PATH = "resource/";

    
    
    public function __construct() {
        parent::__construct();
        $this->load->model('datatable_model');
        $this->load->model('utility_model');
        $this->load->model('request_model');
        $this->load->model('table_schema_model');
        $this->load->model('filter_model');
    }

    public function v1($method='', $param='', $additional='') {
        $response_status = $this->get_response_status(self::STATUS__BAD_CREDENTIALS, self::MESSAGE__BAD_CREDENTIALS);
        $response_data = array('req'=>$method);

        if ($method=='user') {
            $device_id = $this->input->get_post('device_id');
            $device_id = $this->utility_model->get_default_value($device_id);

            $domain = $this->input->get_post('domain');
            $domain = $this->utility_model->get_default_value($domain);

            $username = $this->input->get_post('username');
            $username = $this->utility_model->get_default_value($username);

            $password = $this->input->get_post('password');
            $password = $this->utility_model->get_default_value($password);

            $email = $this->input->get_post('email');
            $email = $this->utility_model->get_default_value($email);

            $mobile = $this->input->get_post('mobile');
            $mobile = $this->utility_model->get_default_value($mobile);

            if ($param == "domain") {
                if ($domain == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $xData = array( "domain" => $domain, "brand" => $this->utility_model->getSet("brandname") );
                    $ret = $this->utility_model->curl_get("", $xData);
                    if( $ret == 1 )
                    {
                        $response_data = array( "brand" => $this->utility_model->getSet("brandname"),
                            "ssl" => $this->utility_model->getSet("ssl") );
                        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                    }
                    else
                    {
                        $response_data = array( "brand" => $this->utility_model->getSet("brandname"),
                            "ssl" => $this->utility_model->getSet("ssl") );
                        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                    }
                }
            }
            else if ($param == "add_reseller") {
                $user_id = $this->input->get_post('user_id');
                $user_id = $this->utility_model->get_default_value($user_id);
                $note = $this->input->get_post('note');
                $note = $this->utility_model->get_default_value($note);
                $pin = $this->input->get_post('pin');
                $pin = $this->utility_model->get_default_value($pin);
                $pType = $this->input->get_post('ptype');
                $pType = $this->utility_model->get_default_value($pType);
                $active = $this->input->get_post('active');
                $active = $this->utility_model->get_default_value($active);
                if ($user_id=="" || $username=="" || $password=="" || $mobile=="" || $email==""
                    || $note==""|| $pin=="" || $pType=="" || $active=="") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $user = $this->utility_model->get('resellers', array('id'=>$user_id));
                    $level = $user["user_type"];

                    if ($level == 1) {
                        $response_status = $this->STATUSES[19];
                    }
                    else {

                        $passinterval = $this->utility_model->getSet("pass_interval");
                        $interval = $this->utility_model->getSet("pin_interval");

                        $ins = $this->utility_model->getRelation($user_id, $level - 1);
                        $ins["username"] = $username;
                        $ins["password"] = password_hash($password . $this->utility_model->passKey(), PASSWORD_BCRYPT);
                        $ins["pass_expire"] = date('Y-m-d', strtotime(date("Y-m-d") . "+ $passinterval days"));
                        $ins["fullname"] = $username;
                        $ins["mobile"] = $mobile;
                        $ins["email"] = $email;
                        $ins["note"] = $note;
                        $ins["balance"] = "0";
                        $ins["device_id"] = "";
                        $ins["parent"] = $user_id;
                        $ins["status"] = $active;
                        $ins["user_type"] = $level - 1;
                        $ins["creationdate"] = date('Y-m-d');
                        $ins["cookie"] = uniqid("QA");

                        $ins["pin"] = password_hash($pin . $this->utility_model->passKey(), PASSWORD_BCRYPT);
                        $ins["pin_expire"] = date('Y-m-d', strtotime(date("Y-m-d") . "+$interval days"));
                        $ins['type'] = $pType;

                        //Lets insert into database
                        $this->utility_model->insert("resellers", $ins);
                        $new_id = $this->utility_model->new_id();
                        $this->utility_model->SaveLogs('AddReseller', "New reseller added with username: $ins[username]",
                            $user_id, $level);

                        //Process starting balance
//                $balance = $this->input->post("balance", TRUE);
//                $limit = $this->lib->isBalLimit($balance, 1);
//                if ($balance > 0 && $limit == true) {
//                    $this->lib->addBal($new_id, $balance);
//                    $pdata = array(
//                        'bal_from' => $user_id,
//                        'bal_to' => $new_id,
//                        'amount' => $balance,
//                        'actual' => $this->utility_model->getBal($new_id),
//                        'type' => 'transfer',
//                        'logtime' => date('Y-m-d H:i:s'),
//                        'note' => 'Starting balance',
//                    );
//                    $this->db->insert('flexi_transfer_log', $pdata);
//                    $this->lib->SaveLogs('Payments', "Payment amount: $balance added as starting balance to $ins[username].");
//                }

                        //Lets copy Template
                        $q = $this->utility_model->get_list("ratestable");
                        foreach ($q as $row):
                            $rData = array(
                                'res_id' => $new_id,
                                'service_id' => $row["service_id"],
                                'type' => $row["type"],
                                'prefix' => $row["prefix"],
                                'rate' => $row["rate"],
                                'commision' => $row["commision"],
                                'charge' => $row["charge"],
                                'enable' => 1
                            );
                            $this->utility_model->insert("rates", $rData);
                        endforeach;

                        $response_data = $this->utility_model->get('resellers', array('id'=>$new_id));;
                        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                    }
                }
            }
            else if ($param == "get_resellers") {
                $user_id = $this->input->get_post('user_id');
                $user_id = $this->utility_model->get_default_value($user_id);
                if ($user_id == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $response_data = $this->utility_model->get_list('resellers', array('parent'=>$user_id));;
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "view_amount") {
                $user_id = $this->input->get_post('user_id');
                $user_id = $this->utility_model->get_default_value($user_id);
                $user = $this->utility_model->get_row('resellers', array('id'=>$user_id));
                $response_data = $this->utility_model->view_amount($user->balance, "");
                $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
            }
            else if ($param == "get_reseller") {
                $user_id = $this->input->get_post('user_id');
                $user_id = $this->utility_model->get_default_value($user_id);
                if ($user_id == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $response_data = $this->utility_model->get('resellers', array('id'=>$user_id));
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "edit_reseller") {
                $user_id = $this->input->get_post('user_id');
                $user_id = $this->utility_model->get_default_value($user_id);
                $note = $this->input->get_post('note');
                $note = $this->utility_model->get_default_value($note);
                $new_password = $this->input->get_post('new_password');
                $new_password = $this->utility_model->get_default_value($new_password);
                $pin = $this->input->get_post('pin');
                $pin = $this->utility_model->get_default_value($pin);
                $new_pin = $this->input->get_post('new_pin');
                $new_pin = $this->utility_model->get_default_value($new_pin);
                $pType = $this->input->get_post('ptype');
                $pType = $this->utility_model->get_default_value($pType);
                $active = $this->input->get_post('active');
                $active = $this->utility_model->get_default_value($active);
                if ($user_id=="" || $username=="" || ($password!="" && $new_password=="")  || $mobile=="" || $email==""
                    || $note==""|| ($pin!="" && $new_pin=="") || $pType=="" || $active=="") {

                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $user = $this->utility_model->get('resellers', array('id'=>$user_id));
                    if (($password != "" && $new_password != "")
                        && !password_verify($password . $this->utility_model->passKey(), $user["password"])) {

                        $response_status = $this->STATUSES[2];
                    }
                    else if (($pin != "" && $new_pin != "")
                        && !password_verify($pin . $this->utility_model->passKey(), $user["pin"])) {

                        $response_status = $this->STATUSES[6];
                    }
                    else {
                        $upd["username"] = $username;
                        if ($password != "" && $new_password != "") {
                            $upd["password"] = password_hash($new_password . $this->utility_model->passKey(), PASSWORD_BCRYPT);
                        }
                        $upd["fullname"] = $username;
                        $upd["mobile"] = $mobile;
                        $upd["email"] = $email;
                        $upd["note"] = $note;
                        $upd["status"] = $active;
                        if ($pin != "" && $new_pin != "") {
                            $upd["pin"] = password_hash($new_pin . $this->utility_model->passKey(), PASSWORD_BCRYPT);
                        }
                        $upd['type'] = $pType;

                        //Update database
                        $this->utility_model->update("resellers", $upd, array('id'=>$user_id));
//                        $this->utility_model->SaveLogs('EditReseller', "Reseller changed",
//                            $user_id, $user["user_type"]);

                        $response_data = $this->utility_model->get('resellers', array('id'=>$user_id));
                        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                    }
                }
            }
            else if ($param == "login") {
                if ($device_id=="" || $username=="" || $password=="") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $user = $this->utility_model->get_or('resellers',
                        array(array('field'=>'username=', 'val'=>$username),
                            array('field'=>'email=', 'val'=>$username)));
                    if ($user) {
                        if( password_verify($password . $this->utility_model->passKey(), $user["password"]) )
                        {
                            if ($user['status']==0) {
                                $response_status = $this->STATUSES[3];
                            }
                            else {
                                $response_data = $this->get_user_response($user['id']);
                                $response_data["2step_require"] = "1";
                                if ($device_id == $user['device_id']) {
                                    $response_data["2step_require"] = "0";
                                }
                                $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                            }
                        }
                        else {
                            $response_status = $this->STATUSES[2];
                        }
                    } else {
                        $response_status = $this->STATUSES[1];
                    }
                }
            }
            else if ($param == "verify_pin") {
                $user_id = $this->input->get_post('user_id');
                $pin = $this->input->get_post('pin');
                if ($device_id=="" || $user_id=="" || $pin=="") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $user = $this->utility_model->get('resellers', array('id'=>$user_id));
                    if( password_verify($pin . $this->utility_model->passKey(), $user["pin"]) )
                    {
                        if ($this->utility_model->update('resellers', array('device_id'=>$device_id), array('id'=>$user['id']) )) {
                            $response_data = $this->get_user_response($user['id']);
                            $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                        } else {
                            $response_status = $this->STATUSES[0];
                        }
                    }
                    else {
                        $response_status = $this->STATUSES[6];
                    }
                }

            }
            else if ($param == "register") {
                if ($device_id == "" || $username=="" || $email=="" || $mobile=="") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $t = mdate('%Y%m%d%H%i%s', time());

                    $user = $this->utility_model->get('resellers', array('username'=>$username));
                    if ($user) {
                        $response_status = $this->STATUSES[4];
                    }
                    else {
                        $user = $this->utility_model->get('resellers', array('email'=>$email));
                        if ($user) {
                            $response_status = $this->STATUSES[5];
                        }
                        else {
                            $user = $this->utility_model->get('resellers', array('mobile'=>$email));
                            if ($user) {
                                $response_status = $this->STATUSES[5];
                            }
                            else {
                                $passinterval = $this->utility_model->getSet("pass_interval");
                                $password = $this->randomPassword(10);
                                $interval = $this->utility_model->getSet("pin_interval");
                                $pin_len = $this->utility_model->getSet("pin_len");
                                $genPin = $this->utility_model->random_numbers($pin_len);
                                $serviceSumRow = $this->db->query("SELECT sum(type) type FROM services WHERE enable=1")->row();
                                $data = array(
                                    'username'=>$username, 'fullname'=>$username, 'mobile'=>$mobile,
                                    'email'=>$email, 'note'=>"Automatically created through Android App",
                                    'mobile'=>$mobile, 'balance'=>"0", 'status'=>"1", 'creationdate'=>$t,
                                    'dlimit'=>$this->utility_model->getSet("daylimit"),
                                    'password'=>password_hash($password . $this->utility_model->passKey(), PASSWORD_BCRYPT),
                                    'cookie'=>uniqid("QA"),
                                    'pass_expire'=>date("Y-m-d", strtotime(date("Y-m-d") . "+" . $passinterval . " days")),
                                    'pin_expire'=>date("Y-m-d", strtotime(date("Y-m-d") . "+" . $interval . " days")),
                                    'pin'=>password_hash($genPin . $this->utility_model->passKey(), PASSWORD_BCRYPT),
                                    'type'=>$serviceSumRow->type, 'admin'=>"1", 'parent'=>"-1", 'rs5'=>"-1", 'rs4'=>"-1",
                                    'rs3'=>"-1", 'rs2'=>"-1", 'user_type'=>"1", 'device_id'=>''
                                );

                                if ($this->utility_model->insert('resellers', $data)) {
                                    $reseller_id = $this->utility_model->new_id();
                                    $q = $this->utility_model->get_list("ratestable");
                                    foreach( $q as $row )
                                    {
                                        $rData = array( "res_id" => $reseller_id, "service_id" => $row["service_id"],
                                            "type" => $row["type"], "prefix" => $row["prefix"], "rate" => $row["rate"],
                                            "commision" => $row["commision"], "charge" => $row["charge"], "enable" => 1 );
                                        $this->db->insert("rates", $rData);
                                    }
                                    $brandname = $this->utility_model->getBrand("brandname");
                                    $pintxt = "\r\nPIN: " . $genPin;

                                    $msg = "Welcome to " . $brandname . ", Your new account details as\r\nLogin ID: " . $username . "\r\nPassword: " . $password . $pintxt;
                                    $outbox = array( "rid" => "-1", "receiver" => $mobile, "message" => $msg, "status" => 0 );
                                    $this->db->insert("outbox", $outbox);

                                    if( strlen($email) )
                                    {
                                        $pintxt = "<br/>PIN: " . $genPin;

                                        $msg = "Hello " . $username . ", <br/>Thanks for creating account with <b>" . $brandname . "</b><br/> Please find your new account details as following: <br/><br/>Username: " . $username . "<br/>Password: " . $password . $pintxt . "<br/><br/>With Thanks<br/>" . $brandname . " Team";
                                        $this->send_mail($email, "Welcome to " . $brandname, $msg);
                                    }

                                    $adminEmail = $this->utility_model->getSet("email");
                                    $this->send_mail($adminEmail, "New customer has signed up successfully!", $msg);

                                    $response_data = array("secret_key" => $password, "PIN" => $genPin);
                                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                                }
                            }
                        }
                    }
                }
            }
            else if ($param == "forgot_password") {
                $user = $this->utility_model->get_or('resellers',
                    array(array('field'=>'username=', 'val'=>$username),
                        array('field'=>'email=', 'val'=>$username)));

                if ($user) {
                    $password = $this->randomPassword(10);
                    if ($this->utility_model->update('resellers',
                        array('password'=>password_hash($password . $this->utility_model->passKey(), PASSWORD_BCRYPT)),
                        array('id'=>$user['id']))) {

                        $msg = "Password has been reset as following\r\nNew Password: " . $password;
                        $outbox = array( "rid" => "-1", "receiver" => $user["mobile"], "message" => $msg, "status" => 0 );
                        $this->db->insert("outbox", $outbox);

                        $this->send_mail($user[], "Password Reset", $msg);
                        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                    } else {
                        $response_status = $this->STATUSES[0];
                    }
                }
                else {
                    $response_status = $this->STATUSES[13];
                }
            }
            else if ($param == "change_password") {
                $new_password = $this->input->get_post('new_password');
                $user = $this->utility_model->get_or('resellers',
                    array(array('field'=>'username=', 'val'=>$username),
                        array('field'=>'email=', 'val'=>$username)));

                if ($user) {
                    if(password_verify($password . $this->utility_model->passKey(), $user["password"]) )
                    {
                        if ($this->utility_model->update('resellers',
                            array('password'=>password_hash($new_password . $this->utility_model->passKey(), PASSWORD_BCRYPT)),
                            array('id'=>$user['id']))) {

                            $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                        } else {
                            $response_status = $this->STATUSES[0];
                        }
                    }
                    else {
                        $response_status = $this->STATUSES[2];
                    }
                }
                else {
                    $response_status = $this->STATUSES[13];
                }
            }
            else if ($param == "change_pin") {
                $new_pin = $this->input->get_post('new_pin');
                $user = $this->utility_model->get_or('resellers',
                    array(array('field'=>'username=', 'val'=>$username),
                        array('field'=>'email=', 'val'=>$username)));

                if ($user) {
                    if(password_verify($password . $this->utility_model->passKey(), $user["password"]) )
                    {
                        if ($this->utility_model->update('resellers',
                            array('pin'=>password_hash($new_pin . $this->utility_model->passKey(), PASSWORD_BCRYPT)),
                            array('id'=>$user['id']))) {

                            $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                        } else {
                            $response_status = $this->STATUSES[0];
                        }
                    }
                    else {
                        $response_status = $this->STATUSES[2];
                    }
                }
                else {
                    $response_status = $this->STATUSES[13];
                }
            }
            else if ($param == "test") {
                $tmp = new stdClass();
                $tmp->id = 1;
                $tmp->title = "title";
                $data[] = $tmp;
                print_r($tmp);
            }
            else {
                $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
            }
        }
        else if ($method=="payment") {
            $user_id = $this->input->get_post('user_id');
            $user_id = $this->utility_model->get_default_value($user_id);
            if ($param == "services") {
                if ($user_id=="") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $user = $this->utility_model->get('resellers', array('id'=>$user_id));
                    if ($user) {
                        $response_data = $this->utility_model->myServices($user["type"]);
                        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                    } else {
                        $response_status = $this->STATUSES[1];
                    }
                }
            }
            else if ($param == "get_countries") {
                $response_data = $this->utility_model->get_list("countries");
                $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
            }
            else if ($param == "get_operators") {
                $country_id = $this->input->get_post('country_id');
                $country_id = $this->utility_model->get_default_value($country_id);
                if ($country_id == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $response_data = $this->utility_model->get_list("operatorlist", array('country'=>$country_id));
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "get_package_operators") {
                $response_data = $this->utility_model->get_list("packotp", array());
                $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
            }
            else if ($param == "get_packages") {
                $operator_id = $this->input->get_post('operator_id');
                $operator_id = $this->utility_model->get_default_value($operator_id);
                if ($operator_id == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $response_data = $this->utility_model->get_list("package", array('opt'=>$operator_id));
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "request_service") {
                $service_id = $this->input->get_post('service_id');
                $service_id = $this->utility_model->get_default_value($service_id);
                $number = $this->input->get_post('number');
                $number = $this->utility_model->get_default_value($number);
                $amount = $this->input->get_post('amount');
                $amount = $this->utility_model->get_default_value($amount);
                $type = $this->input->get_post('type');
                $type = $this->utility_model->get_default_value($type);
                $country = $this->input->get_post('country');
                $country = $this->utility_model->get_default_value($country);
                $operator = $this->input->get_post('operator');
                $operator = $this->utility_model->get_default_value($operator);
                $is_package = $this->input->get_post('is_package');
                $is_package = $this->utility_model->get_default_value($is_package);
                $package_id = $this->input->get_post('package_id');
                $package_id = $this->utility_model->get_default_value($package_id);

                $sRow = $this->utility_model->get_row('services', array('id'=>$service_id));

                if ($user_id == "" || $service_id == "" || $number == "" || $amount == "" || $type == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $uRow = $this->utility_model->get_row('resellers', array('id'=>$user_id));
                    $level = $uRow->user_type;

                    if ($sRow->type == 512 && ($country == "" || $operator == "") && $is_package != 1) {
                        $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                    }
                    else {
                        if ($country == "") {
                            $country = '-1';
                        }
                        if ($operator == "") {
                            $operator = '-1';
                        }
                        $photoid = "";
                        $sendername = "";
                        $receivername = "";

                        if ($uRow->balance < $amount) {
                            $response_status = $this->STATUSES[16];
                        }
                        else {
                            if( $amount < $sRow->min_amnt || $sRow->max_amnt < $amount )
                            {
                                $response_status = $this->get_response_status(17,
                                    "Amount must between " . $sRow->min_amnt . " and " . $sRow->max_amnt);
                            }
                            else {
                                $request = $this->request_model->request($sRow->type, $number, $amount, $type, $user_id,
                                    $level, $country, $operator, $photoid, $sendername, $receivername, "");

                                if ($request["code"] == 0) {
                                    $response_data = $request["data"];
                                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                                }
                                else {
                                    $response_status = $this->STATUSES[18];;
                                }
                            }
                        }
                    }
                }
            }
            else if ($param == "service_history") {
                if ($user_id == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $response_data = $this->filter_model->myLatestHistory($user_id);
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "payment_history") {
                if ($user_id == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $response_data = $this->filter_model->myLatestPayments($user_id);
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "service_history_with_range") {
                $from = $this->input->get_post('from');
                $from = $this->utility_model->get_default_value($from);
                $to = $this->input->get_post('to');
                $to = $this->utility_model->get_default_value($to);

                if ($user_id == "" || $from == "" || $to == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    if (!strlen($from)) $from = date("Y-m-d");
                    if (!strlen($to)) $to = date("Y-m-d");
                    $query_array = array(
                        'reseller' => $user_id,
                        'from' => $from,
                        'to' => $to,
                    );

                    $response_data = $this->filter_model->myHistory($query_array);
                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param == "add_payment") {
                if ($user_id=="") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $amount = $this->input->get_post('amount');
                    $amount = $this->utility_model->get_default_value($amount);
                    $to_id = $this->input->get_post('to_id');
                    $to_id = $this->utility_model->get_default_value($to_id);
                    $type = $this->input->get_post('type');
                    $type = $this->utility_model->get_default_value($type);
                    $pin = $this->input->get_post('pin');
                    $pin = $this->utility_model->get_default_value($pin);
                    $user = $this->utility_model->get_row('resellers', array('id'=>$to_id));
                    $from_user = $this->utility_model->get_row('resellers', array('id'=>$user_id));

                    if ($user_id == "" || $to_id == "" || $amount == "" || $type == "" || $pin == "") {
                        $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                    }
                    else {
                        if( password_verify($pin . $this->utility_model->passKey(), $from_user->pin) )
                        {
                            $added_by = $from_user->username;

                            $desc = "By " . $added_by;

                            $bal_from = $user_id;
                            $bal_to = $to_id;
                            $this->utility_model->SaveLogs('Payment',
                                "User:$user->username,Current:$user->balance,New:$amount,Type:$type");

                            $typew = "";
                            if ($type == 0) {
                                $this->utility_model->addBal($user->id, $amount);
                                $typew = 'transfer';
                            }
                            if ($type == 1) {
                                $this->utility_model->dedBal($user->id, $amount);
                                $typew = 'return';
                            }

                            $dataIns = array(
                                'bal_from' => $bal_from,
                                'bal_to' => $bal_to,
                                'amount' => $amount,
                                'actual' => $this->utility_model->getBalance($user->id),
                                'type' => $typew,
                                'logtime' => date('Y-m-d H:i:s'),
                                'note' => $desc
                            );
                            if ($this->utility_model->insert('flexi_transfer_log', $dataIns)) {
                                $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                            }
                            else {
                                $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST, self::MESSAGE__BAD_REQUEST);
                            }
                        }
                        else {
                            $response_status = $this->STATUSES[6];
                        }
                    }
                }
            }
        }
        else if ($method=="support") {
            $user_id = $this->input->get_post('user_id');
            $user_id = $this->utility_model->get_default_value($user_id);
            if ($param=="open_tickets") {
                $subject = $this->input->get_post('subject');
                $subject = $this->utility_model->get_default_value($subject);
                $details = $this->input->get_post('details');
                $details = $this->utility_model->get_default_value($details);

                if ($user_id == "" || $subject == "" || $details == "") {
                    $response_status = $this->get_response_status(self::STATUS__BAD_REQUEST,
                        self::MESSAGE__BAD_REQUEST);
                }
                else {
                    $user = $this->utility_model->get('resellers', array('id'=>$user_id));
                    $ins = array(
                        'title' => $subject,
                        'message' => $details,
                        'sender' => $user["id"],
                        'rs5' => $user["rs5"],
                        'rs4' => $user["rs4"],
                        'rs3' => $user["rs3"],
                        'rs2' => $user["rs2"],
                        'status' => 1,
                    );
                    $this->db->insert("support_ticket", $ins);

                    $admin_email = $this->utility_model->getSet('email');
                    if (strlen($admin_email)) {
                        $this->send_mail($admin_email, $subject, $details);
                    }

                    $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
                }
            }
            else if ($param=="view_tickets") {

            }
        }
        else {
        }

        print_r(json_encode(array(
            'status' => $response_status,
            'response' => $response_data,
        ), JSON_HEX_QUOT | JSON_HEX_APOS | JSON_UNESCAPED_SLASHES));
    }
    
    private function optimize_resource() {
        $current_time = time();
        $files = scandir(self::RESOURCE_PATH);
        if (is_array($files)) {
            foreach ($files as $file) {
                $full_path = self::RESOURCE_PATH . $file;
                if (is_file($full_path)) {
                    $ago = $current_time - filemtime($full_path);
                    if ($ago >= 3 * 24 * 60 * 60 && $ago <= 30 * 24 * 60 * 60) {
                        $sql = ""
                                . " ( select u.id from hr_user u where u.photo like '%$full_path%' or u.note_voice like '%$full_path%' ) "
                                . " union "
                                . " ( select q.id from hr_question q where q.picture like '%$full_path%' or q.voice_audio like '%$full_path%' ) "
                                . " union "
                                . " ( select a.id from hr_answer a where a.voice_audio like '%$full_path%' ) "
                                . " union "
                                . " ( select c.id from hr_comment c where c.voice_audio like '%$full_path%' ) "
                             . "";

                        $count = $this->utility_model->get_count__by_sql($sql);
                        if ($count==0) {
                            unlink($full_path);
                        }
                    }
                }
            }
        }
    }
    
    
    private function optimize() {
        $success_files = 0;
        $failed_files = 0;
        
        $current_time = time();
        $files = scandir(self::RESOURCE_PATH);
        if (is_array($files)) {
            foreach ($files as $file) {
                $full_path = self::RESOURCE_PATH . $file;
                if (is_file($full_path)) {
                    $ago = $current_time - filemtime($full_path);
                    if ($ago >= 3 * 24 * 60 * 60) {
                        $count1 = $this->utility_model->get_count__by_sql(" select u.id from hr_user u where u.photo like '%$full_path%' ");
                        $count2 = $this->utility_model->get_count__by_sql(" select u.id from hr_user u where u.note_voice like '%$full_path%' ");
                        $count3 = $this->utility_model->get_count__by_sql(" select q.id from hr_question q where q.picture like '%$full_path%' ");
                        $count4 = $this->utility_model->get_count__by_sql(" select q.id from hr_question q where q.voice_audio like '%$full_path%' ");
                        $count5 = $this->utility_model->get_count__by_sql(" select a.id from hr_answer a where a.voice_audio like '%$full_path%' ");
                        $count6 = $this->utility_model->get_count__by_sql(" select c.id from hr_comment c where c.voice_audio like '%$full_path%' ");
                        
                        if ($count1>0) {
                            $a_picture = $this->upload_amazon($full_path);
                            if ($a_picture!==false) {
                                if ($this->utility_model->update__by_sql(" update hr_user set hr_user.photo='$a_picture' where hr_user.photo like '%$full_path%' ")) {
                                    unlink($full_path);
                                    $success_files++;
                                } else {
                                    $failed_files++;
                                }
                            } else {
                                $failed_files++;
                            }
                        }
                        else if ($count2>0) {
                            $a_voice = $this->upload_amazon($full_path);
                            if ($a_voice!==false) {
                                if ($this->utility_model->update__by_sql(" update hr_user set hr_user.note_voice='$a_voice' where hr_user.note_voice like '%$full_path%' ")) {
                                    unlink($full_path);
                                    $success_files++;
                                } else {
                                    $failed_files++;
                                }
                            } else {
                                $failed_files++;
                            }
                        }
                        else if ($count3>0) {
                            $a_picture = $this->upload_amazon($full_path);
                            if ($a_picture!==false) {
                                if ($this->utility_model->update__by_sql(" update hr_question set hr_question.picture='$a_picture' where hr_question.picture like '%$full_path%' ")) {
                                    unlink($full_path);
                                    $success_files++;
                                } else {
                                    $failed_files++;
                                }
                            } else {
                                $failed_files++;
                            }
                        }
                        else if ($count4>0) {
//                            $object = $this->utility_model->get__by_sql(" select q.* from hr_question q where q.voice_audio like '%$full_path%' ");

                            $a_voice = $this->upload_amazon($full_path);
                            if ($a_voice!==false) {
                                if ($this->utility_model->update__by_sql(" update hr_question set hr_question.voice_audio='$a_voice' where hr_question.voice_audio like '%$full_path%' ")) {
                                    unlink($full_path);
                                    $success_files++;
                                } else {
                                    $failed_files++;
                                }
                            } else {
                                $failed_files++;
                            }
                        }
                        else if ($count5>0) {
                            $a_voice = $this->upload_amazon($full_path);
                            if ($a_voice!==false) {
                                if ($this->utility_model->update__by_sql(" update hr_answer set hr_answer.voice_audio='$a_voice' where hr_answer.voice_audio like '%$full_path%' ")) {
                                    unlink($full_path);
                                    $success_files++;
                                } else {
                                    $failed_files++;
                                }
                            } else {
                                $failed_files++;
                            }
                        }
                        else if ($count6>0) {
                            $a_voice = $this->upload_amazon($full_path);
                            if ($a_voice!==false) {
                                if ($this->utility_model->update__by_sql(" update hr_comment set hr_comment.voice_audio='$a_voice' where hr_comment.voice_audio like '%$full_path%' ")) {
                                    unlink($full_path);
                                    $success_files++;
                                } else {
                                    $failed_files++;
                                }
                            } else {
                                $failed_files++;
                            }
                        }
                        
                        sleep(5);
                    }
                }
            }
        }
        
        return array('success'=>$success_files, 'failed'=>$failed_files);
    }

    
    
    private function upload_amazon($file) {
        $this->load->library('aws_s3');
        return $this->aws_s3->uploadFile($file);
    }
    
    public function test_get_text_from_audio($file="http://192.168.1.105/Helpini/resource/audio32KHz.raw", $sample_rate=44100, $language="en-US"){
        $this->load->library('speech/cloud_speech');
        
        $response_data = $this->cloud_speech->process_audio($file, $language, $sample_rate, 'LINEAR16');
        $response_status = $this->get_response_status(self::STATUS__SUCCESS, self::MESSAGE__SUCCESS);
        print_r(json_encode(array(
            'status' => $response_status,
            'response' => $response_data,
        ), JSON_HEX_QUOT | JSON_HEX_APOS | JSON_UNESCAPED_SLASHES));
    }
    
    public function get_text_from_audio_new($file, $language="en-US", $sample_rate=44100){
        $this->load->library('speech/cloud_speech');
        
        $response_data = $this->cloud_speech->process_audio($file, $language, $sample_rate, 'LINEAR16');
        return $response_data['transcript'];
    }
    
    private function get_text_from_voice($file, $sample_rate=44100, $language="de-DE") {
        $this->load->library('speech_to_text');
        return $this->speech_to_text->process($file, $sample_rate, $language);
    }
    
    private function get_question_list($start, $size, $where='') {
        $response = array();
        
        $sql = " select q.*, u.name as username, u.photo, "
                . " ( select count(*) from hr_answer where hr_answer.question_id=q.id ) as answer_count "
                . " from hr_user u, hr_question q "
                . " where u.id=q.user_id "
                . " ";
        
        if ($where!="") {
            $sql .= " and " . $where;
        }
        
        $count = $this->utility_model->get_count__by_sql($sql);
        
        $sql .= " order by q.updated_at desc ";
        $sql .= " limit $start, $size ";
        
        $list = $this->utility_model->get_list__by_sql($sql);

        $result = array();
        if (is_array($list) && count($list)>0) {
            $current_time = time();
            
            foreach ($list as $row) {
                $second = $current_time - strtotime($row['updated_at']);
                $row['ago'] = $second;
//                $row['ago'] = $this->get_time_ago($second);
                array_push($result, $row);
            }
        }
        
        $response['count'] = $count;
        $response['list'] = $result;
        
        return $response;
    }
    
    private function get_question_favorite_field_sql($user) {
        if ($user == null) {
            return "0";
        }
        
        return 
            "CASE WHEN q.id IN (SELECT question_id FROM hr_question_like WHERE question_id = q.id AND type=3 AND user_id=".$user['id'].") ".
            "THEN 1 ELSE 0 ".
            "END";
    }
    
    private function get_question_list_with_answer($start, $size, $where='', $user=null) {
        $response = array();
        $sql = 
        "select ".
                "q.*, u.name as username, u.photo, ". 
                "IFNULL(answer_group.count, 0) as answer_count, ".
                "IFNULL(answer_group.user_name, '') as answer_user_name, ".
                "IFNULL(answer_group.voice_audio, '') as answer_voice_audio, ".
                $this->get_question_favorite_field_sql($user)." AS favorite ".
        "from ". 
                "hr_user u, hr_question q ".
                "LEFT JOIN ( ".
                        "select ".
                                "question_id, ". 
                                "count(question_id) as count, ". 
                                "GROUP_CONCAT(hr_user.name) as user_name, ".
                                "GROUP_CONCAT(hr_answer.voice_audio) as voice_audio ".
                        "from ".
                                "hr_user, hr_answer ".
                        "where ".
                                "hr_user.id=hr_answer.user_id ".
                        "group by question_id) as answer_group ".
                "ON answer_group.question_id=q.id ".
        "where u.id=q.user_id ". " ";
        
        if ($where!="") {
            $sql .= " and " . $where;
        }
        
        $count = $this->utility_model->get_count__by_sql($sql);
        
        $sql .= " order by q.updated_at desc ";
        $sql .= " limit $start, $size ";
        
        $list = $this->utility_model->get_list__by_sql($sql);
        
        $likes = 0;

        $result = array();
        if (is_array($list) && count($list)>0) {
            $current_time = time();
            
            foreach ($list as $row) {
                $second = $current_time - strtotime($row['updated_at']);
                $row['ago'] = $second;
                $row['likes'] = $likes;
                array_push($result, $row);
            }
        }
        
        $response['count'] = $count;
        $response['list'] = $result;
        
        return $response;
    }
    
    private function get_answer_favorite_field_sql($user) {
        if ($user == null) {
            return "0";
        }
        
        return 
            "CASE WHEN a.id IN (SELECT answer_id FROM hr_answer_like WHERE answer_id = a.id AND type=3 AND user_id=".$user['id'].") ".
            "THEN 1 ELSE 0 ".
            "END";
    }

    private function get_answer_list($start, $size, $where='', $user=null) {
        $response = array();
        
        $sql = " select a.*, u.name as username, u.photo, q.title, q.keywords, "
                . " ( select count(*) from hr_comment where hr_comment.answer_id=a.id ) as comment_count, "
                .$this->get_answer_favorite_field_sql($user)." AS favorite "
                . " from hr_user u, hr_question q, hr_answer a "
                . " where u.id=a.user_id and q.id=a.question_id "
                . " ";
        
        if ($where!="") {
            $sql .= " and " . $where;
        }
        
        $count = $this->utility_model->get_count__by_sql($sql);
        
        $sql .= " order by a.updated_at desc ";
        $sql .= " limit $start, $size ";
        
        $list = $this->utility_model->get_list__by_sql($sql);
        
        $result = array();
        if (is_array($list) && count($list)>0) {
            $current_time = time();
            
            foreach ($list as $row) {
                $second = $current_time - strtotime($row['updated_at']);
                $row['ago'] = $second;
//                $row['ago'] = $this->get_time_ago($second);
                array_push($result, $row);
            }
        }
        
        $response['count'] = $count;
        $response['list'] = $result;
        
        return $response;
    }
    
    private function get_comment_favorite_field_sql($user) {
        if ($user == null) {
            return "0";
        }
        
        return 
            "CASE WHEN c.id IN (SELECT comment_id FROM hr_comment_like WHERE comment_id = c.id AND type=3 AND user_id=".$user['id'].") ".
            "THEN 1 ELSE 0 ".
            "END";
    }

    private function get_comment_list($start, $size, $where='', $user=null) {
        $response = array();
        
        $sql = " select c.*, u.name as username, u.photo, q.title, q.keywords, "
                .$this->get_comment_favorite_field_sql($user)." AS favorite "
                . " from hr_user u, hr_question q, hr_answer a, hr_comment c "
                . " where u.id=c.user_id and q.id=c.question_id and c.answer_id=a.id "
                . " ";
        
        if ($where!="") {
            $sql .= " and " . $where;
        }
        
        $count = $this->utility_model->get_count__by_sql($sql);
        
        $sql .= " order by c.updated_at desc ";
        $sql .= " limit $start, $size ";
        
        $list = $this->utility_model->get_list__by_sql($sql);
        
        $result = array();
        if (is_array($list) && count($list)>0) {
            $current_time = time();
            
            foreach ($list as $row) {
                $second = $current_time - strtotime($row['updated_at']);
                $row['ago'] = $second;
//                $row['ago'] = $this->get_time_ago($second);
                array_push($result, $row);
            }
        }
        
        $response['count'] = $count;
        $response['list'] = $result;
        
        return $response;
    }

    private function get_time_ago($second) {
        if ($second<60) {
            return 1; // less than 1 minutes
        }
        
        if ($second<60*5) {
            return 2; // less than 5 minutes
        }

        if ($second<60*10) {
            return 3; // less than 10 minutes
        }

        if ($second<60*20) {
            return 4; // less than 20 minutes
        }

        if ($second<60*30) {
            return 5; // less than 30 minutes
        }

        if ($second<60*60) {
            return 6; // less than 1 hours
        }
        
        if ($second<60*60*2) {
            return 7; // less than 2 hours
        }

        if ($second<60*60*6) {
            return 8; // less than 6 hours
        }

        if ($second<60*60*12) {
            return 9; // less than 12 hours
        }

        if ($second<60*60*24) {
            return 10; // less than 1 days
        }
        
        if ($second<60*60*24*2) {
            return 11; // less than 2 days
        }
        
        if ($second<60*60*24*3) {
            return 12; // less than 3 days
        }
        
        if ($second<60*60*24*7) {
            return 13; // less than 1 week
        }
        
        if ($second<60*60*24*7*2) {
            return 14; // less than 2 week
        }
        
        if ($second<60*60*24*30) {
            return 15; // less than 1 month
        }
        
        if ($second<60*60*24*30*2) {
            return 16; // less than 2 month
        }

        if ($second<60*60*24*30*6) {
            return 17; // less than 6 month
        }

        if ($second<60*60*24*365) {
            return 18; // less than 1 year
        }

        if ($second<60*60*24*365*2) {
            return 19; // less than 2 year
        }
        
        if ($second<60*60*24*365*3) {
            return 20; // less than 3 year
        }
        
        return 0;
    }

    
    private function get_user_response($user_id) {
        $response = array();
        
//        $topic = $this->utility_model->get__by_sql(" select a.name_en as en, a.name_de as de from hr_topic a where a.id='" . FAVOURITE_TOPIC . "' ");

//        $tags = array();
//        $keywords = $this->utility_model->get_list('hr_topic_keyword', array('topic_id'=>FAVOURITE_TOPIC));
//        if ($keywords) {
//            foreach ($keywords as $row) {
//                array_push($tags, $row['value']);
//            }
//        }
//        $topic['keyword'] = $tags;
        
//        $response['topic'] = $topic;
        
//        $faq = array(
//            'help' => $this->utility_model->get_list__by_sql(" select a.* from hr_faq a where a.status=1 and a.type=" . FAQ_HELP . " order by a.order "),
//            'how' => $this->utility_model->get_list__by_sql(" select a.* from hr_faq a where a.status=1 and a.type=" . FAQ_HOW . " order by a.order ")
//        );
//        $response['faq'] = $faq;
        
        $user = $this->utility_model->get('resellers', array('id'=>$user_id));
        if ($user) {
            $response['user'] = $user;
        }
        
        return $response;
    }

    
    
    private function send_push_android($devices, $data) {
        $headers = array(
            'Authorization: key=' . GOOGLE_KEY,
            'Content-Type: application/json'
        );

        $fields = array(
            'registration_ids' => $devices,
            'data' => $data,
        );

        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, "https://android.googleapis.com/gcm/send");

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Avoids problem with https certificate
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        // Execute post
        $result = curl_exec($ch);

        // Close connection
        curl_close($ch);

        return $result;
    }


    
    private function send_activation_mail($username, $email) {
        $t = mdate('%Y%m%d%H%i%s', time());
        $code = random_number(6);

        if ($this->utility_model->insert('hr_token', array('type'=>1, 'code'=>$code, 'username'=>$username, 'created_at'=>$t))) {
            $body = "Activation Code: " . $code . "\n";
            return $this->send_mail($email, "Activate Account", $body);
        }
        
        return false;
    }
    
    private function send_reset_password_mail($username, $email) {
        $t = mdate('%Y%m%d%H%i%s', time());
        $code = random_number(6);

        if ($this->utility_model->insert('hr_token', array('type'=>2, 'code'=>$code, 'username'=>$username, 'created_at'=>$t))) {
            $body = "Verification Code: " . $code . "\n";
            return $this->send_mail($email, "Use this verification code to reset password", $body);
        }
        
        return false;
    }
    
    public function send_push_test() {
        $response =
            $this->send_fcm("Helpini", 
                "Helpini Message", 
                array('eah0oEm0_fQ:APA91bFeqFoNVbzPyKXnhn0rDx7-AMJh46e4ECtBQ_XHDDB-r735lj-6vyvEDG9MH1qBGSRJGLgi-WTlDfFtQH6gBkGDkv-mVc0ku_Fca74O0ZfpztscjhJ5lTHtxV4AmNTg-68FGgNj'));
        echo "Response: \n";
        print_r($response);
    }
    
    private function send_fcm($title, $message, $regIds = array(), $payload = array()) {
        if (count($regIds) == 0) {
            return;
        }
        
        $this->load->library('push/push');
        $this->load->library('push/firebase');
        
        $firebase = new Firebase();
        $push = new Push();
        $push->setTitle($title);
        $push->setMessage($message);
        $image_path = base_url()."assets/base/images/logo.png";
        $push->setImage($image_path);
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        
        $json = $push->getPush();
        $response = $firebase->sendMultiple($regIds, $json);
    }
    
    private function send_mail($address, $subject, $body, $isHTML = false) {
        $this->load->library('mailer/phpmailerex');
        $mail = new PHPMailer;

        $mail->SMTPDebug = 0;                               // Enable verbose debug output
        $mail->Debugoutput = 'error_log';

        $mail->Timeout = 60;
        $mail->Timelimit = 60;

//        if (strpos(base_url(), "https://")===false) {
            $mail->isSMTP();                                      // Set mailer to use SMTP
//        } else {
//            $mail->isMail();                                      // Set mailer to use SMTP
//        }

        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )            
        );
        
        $mail->Host = SMTP_HOST;  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USER;                // SMTP username
        $mail->Password = SMTP_PASSWORD;                         // SMTP password
        $mail->SMTPSecure = '';
        $mail->Port = SMTP_PORT;                       // TCP port to connect to

        $mail->From = SMTP_FROM;
        $mail->FromName = SMTP_NAME;

        $mail->addAddress($address);     // Add a recipient

        $mail->isHTML($isHTML);                                  // Set email format to HTML

        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = "";

        if ($mail->send()) {
        } else {
            return $mail->ErrorInfo;
        }
        
        return true;
    }

    

    private function get_response_status($code, $message) {
        return array(
            'code' => $code,
            'message' => $message
        );
    }

    
    public function test() {
//        $crypt = new MagicCrypt("c8dd77826e244ffe227e4ddff8a0fe9c5878d0d9", 256, "c8dd77826e244ffe227e4ddff8a0fe9c5878d0d9");
//        $parameter = $crypt->decrypt("ez80p4pclF6bNVAy/AxEEw+ArU5Hzr/X2MZXvXupzfo=");
//        var_dump($parameter);
        var_dump($this->send_mail("cjh124@outlook.com", "Test", "this is a test"));
    }

    public function randomPassword($len)
    {
        $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        $pass = array(  );
        $alphaLength = strlen($alphabet) - 1;
        $i = 0;
        while( $i < $len )
        {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
            $i++;
        }
        return implode($pass);
    }
    
}
